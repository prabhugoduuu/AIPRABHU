package com.prabhu.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import kotlin.math.abs

private const val SMATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val SWRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private const val SCREEN_PROMPT =
    " The user is sharing a screenshot of their phone screen. Answer about what is visible, directly and briefly. " +
    "If it shows a quiz or MCQ question, solve it step by step and state the final answer clearly."

/**
 * Screen assist: a small floating "P" bubble. Tap it on any screen and Prabhu looks at that screen
 * and answers in a panel right there. Needs the screen-capture permission (asked every time it starts).
 */
class ScreenService : Service() {

    companion object {
        @Volatile var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val lock = Any()

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var last: Image? = null
    private var thread: HandlerThread? = null
    private var down = false

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var answer: TextView? = null
    private var answerScroll: ScrollView? = null
    private var input: EditText? = null
    private var modelTv: TextView? = null

    private var shotB64 = ""
    private val convo = ArrayList<Msg>()
    private var busy = false
    private var failedQ: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    // ---------------------------------------------------------------- start / stop

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { shutdown(); return START_NOT_STICKY }
        try { startFg() } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
        } catch (e: Exception) {
            projection = null
        }
        val p = projection
        if (p == null) {
            toast("Couldn't start screen capture")
            shutdown()
            return START_NOT_STICKY
        }
        val t = HandlerThread("prabhu-capture")
        t.start()
        thread = t
        val bg = Handler(t.looper)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, bg)
        try {
            setupCapture(p, bg)
        } catch (e: Exception) {
            toast("Couldn't start screen capture")
            shutdown()
            return START_NOT_STICKY
        }
        running = true
        main.post { showBubble() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("prabhu_screen", "Prabhu screen assist", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel)
        val n = Notification.Builder(this, "prabhu_screen")
            .setContentTitle("Prabhu screen assist is on")
            .setContentText("Tap the P bubble on any screen to ask about it")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2, n)
        }
    }

    private fun setupCapture(p: MediaProjection, bg: Handler) {
        val dm = resources.displayMetrics
        val big = maxOf(dm.widthPixels, dm.heightPixels)
        val scale = if (big > 1024) 1024f / big else 1f
        val cw = maxOf(2, (dm.widthPixels * scale).toInt())
        val ch = maxOf(2, (dm.heightPixels * scale).toInt())
        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                synchronized(lock) {
                    last?.close()
                    last = img
                }
            }
        }, bg)
        reader = r
        vd = p.createVirtualDisplay(
            "prabhu-screen", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg
        )
    }

    private fun shutdown() {
        if (down) return
        down = true
        running = false
        closePanel()
        try { bubble?.let { wm.removeView(it) } } catch (e: Exception) { }
        bubble = null
        try { vd?.release() } catch (e: Exception) { }
        vd = null
        synchronized(lock) {
            try { last?.close() } catch (e: Exception) { }
            last = null
        }
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        thread?.quitSafely()
        thread = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(s: CharSequence, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, r: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
    }

    /** The newest frame of the screen as a base64 JPEG, or null if nothing was captured yet. */
    private fun grab(): String? {
        synchronized(lock) {
            val img = last ?: return null
            return try {
                val pl = img.planes[0]
                val buf = pl.buffer
                buf.rewind()
                val w = pl.rowStride / pl.pixelStride
                val bmp = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf)
                val crop = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                val o = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 70, o)
                Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            } catch (e: Exception) {
                null
            }
        }
    }

    // ---------------------------------------------------------------- bubble

    private fun showBubble() {
        val size = dp(54)
        val b = TextView(this).apply {
            text = "P"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF8AA4FF.toInt(), 0xFF5566F0.toInt())
            ).apply { shape = GradientDrawable.OVAL }
            alpha = 0.92f
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(260)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx
                        val dy = e.rawY - ty
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onBubbleTap()
                }
                return true
            }
        })
        try {
            wm.addView(b, lp)
            bubble = b
        } catch (e: Exception) {
            toast("Allow 'Display over other apps' for Prabhu")
            shutdown()
        }
    }

    private fun onBubbleTap() {
        if (panel != null) return
        val b64 = grab()
        if (b64 == null) {
            toast("Screen not captured yet, try again")
            return
        }
        shotB64 = b64
        convo.clear()
        failedQ = null
        busy = false
        showPanel()
    }

    // ---------------------------------------------------------------- answer panel

    private fun showPanel() {
        bubble?.visibility = View.GONE
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(cSurface)
                val r = dp(22).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv("✦  Prabhu · this screen", 14f, cText, true), LinearLayout.LayoutParams(0, SWRAP, 1f))
        val mt = tv("", 12f, cAccent, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { cycleModel() }
        }
        modelTv = mt
        refreshModelLabel()
        top.addView(mt)
        top.addView(tv("✕", 20f, cText).apply {
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        })
        p.addView(top, LinearLayout.LayoutParams(SMATCH, SWRAP))

        val ans = tv("", 15f, cText).apply {
            setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
        }
        answer = ans
        val sc = ScrollView(this).apply { visibility = View.GONE; addView(ans) }
        answerScroll = sc
        p.addView(sc, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(8) })

        val chips = listOf(
            "Explain this" to "Explain what is on my screen simply.",
            "Solve this question" to "Solve the question shown on my screen step by step and give the final answer.",
            "Translate to Telugu" to "Translate the text on my screen to Telugu.",
            "Summarize" to "Summarize what is on my screen."
        )
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        chips.forEach { c ->
            chipRow.addView(tv(c.first, 13f, cText).apply {
                background = rounded(cSurface2, 16)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener { ask(c.second) }
            }, LinearLayout.LayoutParams(SWRAP, SWRAP).apply { rightMargin = dp(8) })
        }
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        p.addView(hs, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(10) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cSurface2, 26)
            setPadding(dp(14), dp(2), dp(6), dp(2))
        }
        val et = EditText(this).apply {
            hint = "Ask about this screen…"
            setHintTextColor(cMute)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setBackgroundColor(Color.TRANSPARENT)
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        input = et
        row.addView(et, LinearLayout.LayoutParams(0, SWRAP, 1f))
        row.addView(tv("↑", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(cAccent) }
            setOnClickListener { ask(et.text.toString()) }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        p.addView(row, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            SMATCH, SWRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            wm.addView(p, lp)
            panel = p
        } catch (e: Exception) {
            bubble?.visibility = View.VISIBLE
            toast("Couldn't open the panel")
        }
    }

    private fun closePanel() {
        val p = panel
        if (p != null) {
            try { wm.removeView(p) } catch (e: Exception) { }
        }
        panel = null
        answer = null
        answerScroll = null
        input = null
        modelTv = null
        bubble?.visibility = View.VISIBLE
    }

    private fun refreshModelLabel() {
        val ms = Store.models(this)
        modelTv?.text = "⇄  " + (ms.getOrNull(Store.active(this))?.name ?: "Add model")
    }

    /** Tap the model name to switch to the next model that has a key (and retry if the last try failed). */
    private fun cycleModel() {
        val ms = Store.models(this)
        if (ms.isEmpty()) return
        val cur = Store.active(this)
        for (k in 1..ms.size) {
            val j = (cur + k) % ms.size
            if (ms[j].key.isNotBlank()) {
                Store.setActive(this, j)
                break
            }
        }
        refreshModelLabel()
        val q = failedQ
        if (q != null && !busy) ask(q)
    }

    private fun setAnswer(text: CharSequence, err: Boolean, follow: Int = 0) {
        val a = answer ?: return
        val sc = answerScroll ?: return
        a.setTextColor(if (err) cErr else cText)
        a.text = text
        sc.visibility = View.VISIBLE
        val maxH = (resources.displayMetrics.heightPixels * 0.42f).toInt()
        a.post {
            val lp = sc.layoutParams
            lp.height = if (a.height > maxH) maxH else SWRAP
            sc.layoutParams = lp
            // follow: 0 = jump to top (new answer), 1 = follow the newest words while streaming, 2 = stay put
            if (follow == 0) sc.fullScroll(View.FOCUS_UP) else if (follow == 1) sc.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun ask(text: String) {
        if (busy) return
        val ms = Store.models(this)
        if (ms.none { it.key.isNotBlank() }) {
            setAnswer("Add an API key first: open the Prabhu app → Settings → Add model / API.", true)
            return
        }
        val q = text.trim().ifEmpty { "Explain what is on my screen and help me with it." }
        failedQ = null
        val um = Msg("user", q)
        if (convo.isEmpty()) um.atts = listOf(Att("image", "image/jpeg", shotB64, "screen.jpg"))
        convo.add(um)
        input?.setText("")
        setAnswer("Thinking…", false)
        busy = true
        val active = Store.active(this)
        val fb = Store.bool(this, "fallback", true)
        val snap = ArrayList(convo)
        val snapModels = ArrayList(ms)
        var lastPush = 0L
        var streamed = false
        val onText: (String) -> Unit = { t ->
            val now = android.os.SystemClock.uptimeMillis()
            if (now - lastPush >= 60) {
                lastPush = now
                streamed = true
                main.post { if (busy && panel != null) setAnswer(Md.render(t, cSurface2), false, 1) }
            }
        }
        Thread {
            val r = Ai.ask(snapModels, active, fb, snap, false, SCREEN_PROMPT, onText)
            main.post { onAnswer(q, r, streamed) }
        }.start()
    }

    private fun onAnswer(q: String, r: Ai.Result, streamed: Boolean) {
        busy = false
        if (r.ok) {
            convo.add(Msg("assistant", r.text, r.used))
            if (panel == null) return
            setAnswer(Md.render(r.text, cSurface2), false, if (streamed) 2 else 0)
            modelTv?.text = "⇄  " + r.used
        } else {
            if (convo.isNotEmpty()) convo.removeAt(convo.lastIndex)
            failedQ = q
            if (panel == null) return
            setAnswer(r.text + "\n\nTap the model name above to switch model and retry.", true)
        }
    }
}
