package com.prabhu.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    class Result(val ok: Boolean, val text: String, val used: String)

    private class Retry(msg: String) : Exception(msg)

    private const val SYS =
        "You are Prabhu, a helpful personal AI assistant. Reply in the same language the user writes in " +
        "(Telugu, English or Tenglish). Be clear, accurate and friendly. Start answering immediately, no preamble. " +
        "Keep answers concise unless the user asks for detail. Use simple markdown when it helps."
    private const val BRIEF = " This answer will be read aloud: keep it short and conversational, with no markdown."

    /** Tries the active model first; if it fails and fallback is on, tries the other models in order. */
    /** [onText] is called (from the background thread) with the full answer so far, as it streams in. */
    fun ask(
        models: List<ModelCfg>, active: Int, fallback: Boolean, msgs: List<Msg>, brief: Boolean,
        extra: String = "", onText: ((String) -> Unit)? = null
    ): Result {
        val order = ArrayList<ModelCfg>()
        models.getOrNull(active)?.let { order.add(it) }
        if (fallback) models.forEachIndexed { i, m -> if (i != active) order.add(m) }
        val list = order.filter { it.key.isNotBlank() }
        if (list.isEmpty()) return Result(false, "No API key set for this model. Open Settings and add one.", "")

        val hist = msgs.takeLast(14).dropWhile { it.role != "user" }.filter { it.text.isNotBlank() }
        // Only the two most recent messages with files are sent along, to keep requests small.
        val withAtt = hist.indices.filter { hist[it].role == "user" && hist[it].atts.isNotEmpty() }.takeLast(2).toSet()
        val sys = (if (brief) SYS + BRIEF else SYS) + extra
        val errs = ArrayList<String>()
        for (m in list) {
            try {
                if (m.modelId.isBlank()) throw Retry("model ID is empty")
                val out = when (m.type) {
                    "claude" -> claude(m, sys, hist, withAtt, onText)
                    "gemini" -> gemini(m, sys, hist, withAtt, onText)
                    else -> openai(m, sys, hist, withAtt, onText)
                }
                return Result(true, out, m.name)
            } catch (e: Exception) {
                errs.add("${m.name}: ${e.message}")
            }
        }
        return Result(false, "Couldn't get a reply.\n" + errs.joinToString("\n"), "")
    }

    private fun connect(url: String, headers: Map<String, String>, body: JSONObject, sse: Boolean): HttpURLConnection {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 120000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (sse) setRequestProperty("Accept", "text/event-stream")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) {
            val txt = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            val detail = try {
                val o = JSONObject(txt)
                o.optJSONObject("error")?.optString("message") ?: o.optString("error")
            } catch (e: Exception) { "" }
            throw Retry("HTTP $code ${detail.take(100)}")
        }
        return conn
    }

    /** Server-sent events: calls [onData] for every "data: ..." line as it arrives. */
    private fun stream(url: String, headers: Map<String, String>, body: JSONObject, onData: (String) -> Unit) {
        val conn = connect(url, headers, body, true)
        conn.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val d = line.substring(5).trim()
                if (d.isEmpty() || d == "[DONE]") continue
                onData(d)
            }
        }
    }

    private fun fileText(a: Att) = "File \"${a.name}\":\n${a.data}"

    private fun claude(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?): String {
        val arr = JSONArray()
        h.forEachIndexed { i, x ->
            val role = if (x.role == "user") "user" else "assistant"
            val at = if (i in withAtt) x.atts else emptyList()
            if (at.isEmpty()) {
                arr.put(JSONObject().put("role", role).put("content", x.text))
            } else {
                val c = JSONArray()
                for (a in at) {
                    when (a.kind) {
                        "image" -> c.put(JSONObject().put("type", "image").put("source",
                            JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", a.data)))
                        "pdf" -> c.put(JSONObject().put("type", "document").put("source",
                            JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", a.data)))
                        else -> c.put(JSONObject().put("type", "text").put("text", fileText(a)))
                    }
                }
                c.put(JSONObject().put("type", "text").put("text", x.text))
                arr.put(JSONObject().put("role", role).put("content", c))
            }
        }
        val body = JSONObject().put("model", m.modelId).put("max_tokens", 4096).put("stream", true)
            .put("system", sys).put("messages", arr)
        val sb = StringBuilder()
        stream(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to m.key, "anthropic-version" to "2023-06-01"), body
        ) { d ->
            val o = JSONObject(d)
            when (o.optString("type")) {
                "content_block_delta" -> {
                    val t = o.optJSONObject("delta")?.optString("text") ?: ""
                    if (t.isNotEmpty()) { sb.append(t); cb?.invoke(sb.toString()) }
                }
                "error" -> throw Retry("API error " + (o.optJSONObject("error")?.optString("message") ?: "").take(100))
            }
        }
        return sb.toString().ifBlank { "(empty reply)" }
    }

    private fun gemini(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?): String {
        val contents = JSONArray()
        h.forEachIndexed { i, x ->
            val parts = JSONArray()
            val at = if (i in withAtt) x.atts else emptyList()
            for (a in at) {
                when (a.kind) {
                    "image" -> parts.put(JSONObject().put("inlineData",
                        JSONObject().put("mimeType", "image/jpeg").put("data", a.data)))
                    "pdf" -> parts.put(JSONObject().put("inlineData",
                        JSONObject().put("mimeType", "application/pdf").put("data", a.data)))
                    else -> parts.put(JSONObject().put("text", fileText(a)))
                }
            }
            parts.put(JSONObject().put("text", x.text))
            contents.put(JSONObject().put("role", if (x.role == "user") "user" else "model").put("parts", parts))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
        // Gemini 2.5 Flash "thinks" before answering, which delays the first word. Turn that off for speed.
        if (m.modelId.contains("2.5") && m.modelId.contains("flash")) {
            body.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
        }
        val sb = StringBuilder()
        var blocked = ""
        stream(
            "https://generativelanguage.googleapis.com/v1beta/models/${m.modelId}:streamGenerateContent?alt=sse",
            mapOf("x-goog-api-key" to m.key), body
        ) { d ->
            val o = JSONObject(d)
            val parts = o.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) {
                var added = false
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    val t = p.optString("text")
                    if (t.isNotEmpty()) { sb.append(t); added = true }
                }
                if (added) cb?.invoke(sb.toString())
            } else {
                val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                if (br.isNotEmpty()) blocked = br
            }
        }
        if (sb.isBlank() && blocked.isNotEmpty()) throw Retry("blocked: $blocked")
        return sb.toString().ifBlank { "(empty reply)" }
    }

    /** OpenAI, Groq, OpenRouter and any other OpenAI-compatible API. PDFs are sent as page images. */
    private fun openai(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?): String {
        val base = m.baseUrl.trim().trimEnd('/').ifEmpty { "https://api.openai.com/v1" }
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
        fun imageBlock(b64: String) = JSONObject().put("type", "image_url").put("image_url",
            JSONObject().put("url", "data:image/jpeg;base64,$b64"))
        h.forEachIndexed { i, x ->
            val role = if (x.role == "user") "user" else "assistant"
            val at = if (i in withAtt) x.atts else emptyList()
            if (at.isEmpty()) {
                arr.put(JSONObject().put("role", role).put("content", x.text))
            } else {
                val c = JSONArray()
                for (a in at) {
                    when (a.kind) {
                        "image" -> c.put(imageBlock(a.data))
                        "pdf" -> {
                            c.put(JSONObject().put("type", "text").put("text",
                                "PDF \"${a.name}\" (first ${a.pages.size} pages shown as images):"))
                            a.pages.forEach { c.put(imageBlock(it)) }
                        }
                        else -> c.put(JSONObject().put("type", "text").put("text", fileText(a)))
                    }
                }
                c.put(JSONObject().put("type", "text").put("text", x.text))
                arr.put(JSONObject().put("role", role).put("content", c))
            }
        }
        val body = JSONObject().put("model", m.modelId).put("messages", arr).put("stream", true)
        val sb = StringBuilder()
        stream("$base/chat/completions", mapOf("Authorization" to "Bearer ${m.key}"), body) { d ->
            val t = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("delta")?.optString("content") ?: ""
            if (t.isNotEmpty() && t != "null") { sb.append(t); cb?.invoke(sb.toString()) }
        }
        return sb.toString().ifBlank { "(empty reply)" }
    }
}
