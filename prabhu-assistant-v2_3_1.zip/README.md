# Prabhu - AI assistant for Android

Chat app with side menu, chat history, photo/PDF/Word/text attach, voice input.
Add any number of AI APIs (Claude, Gemini, OpenAI, Groq, OpenRouter, custom).

v2.3
- Streaming: answers appear word by word, in chat and in the screen bubble.
- Faster: Gemini 2.5 Flash thinking off, smaller screenshots, shorter history.
- Fixed signing key (prabhu.jks): new APKs install OVER the old one, no uninstall needed.
- Gemini key is built in (app/gemini.key or GitHub secret GEMINI_API_KEY). Keep the repo PRIVATE.

v2.2
- Switch model inside the same chat when one API hits its limit (error card, last answer, model chip).
- Screen assist: floating P bubble, tap on any screen and Prabhu answers about it right there.
- Default digital assistant: power-button long-press opens Prabhu with a screenshot. No background listening.
- "Hey Prabhu" always-listening is now optional and off by default.
