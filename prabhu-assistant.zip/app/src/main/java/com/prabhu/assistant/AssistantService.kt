package com.prabhu.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class AssistantService : Service() {

    private enum class Mode { WAKE, COMMAND, BUSY }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wm: WindowManager? = null
    private var overlay: View? = null
    private var statusTv: TextView? = null
    private var replyTv: TextView? = null
    private var mode = Mode.WAKE
    private var running = false
    private val history = ArrayList<Pair<String, String>>()
    private val hideTask = Runnable { if (mode == Mode.WAKE) hideOverlay() }

    private val wake = Regex(
        "(hello|hallo|helo|hey|హలో)\\s*(prabhu|prabu|prabhoo|probhu|ప్రభు|ప్రభూ)",
        RegexOption.IGNORE_CASE
    )

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            shutdown()
            return START_NOT_STICKY
        }
        if (running) return START_STICKY
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Ee phone lo speech recognition ledu", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextToSpeech(this) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { afterSpeak() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { afterSpeak() } }
        })
        tts = t
        mode = Mode.WAKE
        listen()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("prabhu", "Prabhu", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "prabhu")
            .setContentTitle("Prabhu vintunnadi")
            .setContentText("\"Hello Prabhu\" ani anandi")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun recIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this@AssistantService))
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
    }

    private fun listen() {
        if (!running) return
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) { main.post { onRecError(e) } }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                main.post { onHeard(t) }
            }
        })
        r.startListening(recIntent())
    }

    private fun onRecError(e: Int) {
        if (!running) return
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            Toast.makeText(this, "Mic permission ivvandi", Toast.LENGTH_LONG).show()
            shutdown()
            return
        }
        when (mode) {
            Mode.WAKE -> {
                val wait = if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_CLIENT) 1500L else 300L
                main.postDelayed({ if (mode == Mode.WAKE) listen() }, wait)
            }
            Mode.COMMAND -> {
                setStatus("Em vinipinchaledu")
                mode = Mode.WAKE
                main.postDelayed(hideTask, 2000)
                main.postDelayed({ if (mode == Mode.WAKE) listen() }, 500)
            }
            Mode.BUSY -> {}
        }
    }

    private fun onHeard(text: String) {
        when (mode) {
            Mode.WAKE -> {
                val m = wake.find(text)
                if (m == null) {
                    listen()
                } else {
                    val rest = text.substring(m.range.last + 1).trim(' ', ',', '.')
                    if (rest.length > 2) handle(rest) else enterCommand()
                }
            }
            Mode.COMMAND -> if (text.isBlank()) onRecError(SpeechRecognizer.ERROR_NO_MATCH) else handle(text)
            Mode.BUSY -> {}
        }
    }

    private fun enterCommand() {
        main.removeCallbacks(hideTask)
        mode = Mode.COMMAND
        showOverlay()
        setStatus("Vintunna… cheppandi")
        setReply("")
        listen()
    }

    private fun handle(text: String) {
        main.removeCallbacks(hideTask)
        mode = Mode.BUSY
        showOverlay()
        setStatus("Alochistunna…")
        setReply("Meeru: $text")
        history.add("user" to text)
        while (history.size > 12) history.removeAt(0)
        val snap = ArrayList(history)
        Thread {
            val ans = Gemini.ask(this, snap)
            main.post { onAnswer(ans) }
        }.start()
    }

    private fun onAnswer(ans: String) {
        if (!running) return
        history.add("model" to ans)
        setStatus("Prabhu")
        setReply(ans)
        speak(ans)
    }

    private fun speak(text: String) {
        val t = tts
        if (ttsReady && t != null) {
            t.language = Locale.forLanguageTag(Prefs.lang(this))
            t.speak(text.replace(Regex("[*#`_]"), ""), TextToSpeech.QUEUE_FLUSH, null, "u1")
            main.postDelayed({ afterSpeak() }, 45000)
        } else {
            main.postDelayed({ afterSpeak() }, 7000)
        }
    }

    private fun afterSpeak() {
        if (!running || mode != Mode.BUSY) return
        mode = Mode.WAKE
        main.postDelayed(hideTask, 6000)
        listen()
    }

    // ---------- Overlay ----------

    private fun showOverlay() {
        if (overlay != null) return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Overlay permission ivvandi (app lo button)", Toast.LENGTH_LONG).show()
            return
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(20))
            background = GradientDrawable().apply {
                setColor(0xF2171C25.toInt())
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), 0xFF2A3345.toInt())
            }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val title = TextView(this).apply {
            text = "Prabhu"
            setTextColor(0xFF7FA6FF.toInt())
            setTypeface(typeface, Typeface.BOLD)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        }
        val close = TextView(this).apply {
            text = "✕"
            setTextColor(0xFF97A2B6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setPadding(dp(12), 0, 0, 0)
            setOnClickListener { dismiss() }
        }
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(close)

        val st = TextView(this).apply {
            setTextColor(0xFF97A2B6.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(4), 0, dp(8))
        }
        val rp = TextView(this).apply {
            setTextColor(0xFFE8ECF4.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        }
        val sc = ScrollView(this).apply { addView(rp) }

        card.addView(head)
        card.addView(st)
        card.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150)))

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm?.addView(card, lp)
        overlay = card
        statusTv = st
        replyTv = rp
    }

    private fun dismiss() {
        main.removeCallbacks(hideTask)
        tts?.stop()
        hideOverlay()
        if (mode != Mode.WAKE) {
            mode = Mode.WAKE
            listen()
        }
    }

    private fun hideOverlay() {
        overlay?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        overlay = null
        statusTv = null
        replyTv = null
    }

    private fun setStatus(s: String) { statusTv?.text = s }
    private fun setReply(s: String) { replyTv?.text = s }

    private fun shutdown() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy(); rec = null
        tts?.shutdown(); tts = null
        hideOverlay()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown()
        super.onDestroy()
    }
}
