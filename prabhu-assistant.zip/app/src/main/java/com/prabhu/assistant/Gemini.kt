package com.prabhu.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    private const val MODEL = "gemini-2.5-flash"
    private const val SYS =
        "You are Prabhu, a helpful personal voice assistant. Reply in the same language the user speaks " +
        "(Telugu, English or Tenglish). Keep answers short, clear and easy to read aloud. No markdown."
    private var cursor = 0

    private class Retry(msg: String) : Exception(msg)

    /** Tries each saved key in turn; moves on to the next one when a key fails or hits its limit. */
    fun ask(ctx: Context, history: List<Pair<String, String>>): String {
        val keys = Prefs.keys(ctx).filter { it.isNotEmpty() }
        if (keys.isEmpty()) return "Mundu app lo API key add cheyandi."
        var last = ""
        for (n in keys.indices) {
            val idx = (cursor + n) % keys.size
            try {
                val out = call(keys[idx], history)
                cursor = idx
                return out
            } catch (e: Exception) {
                last = e.message ?: ""
            }
        }
        return "Anni API keys fail ayyayi ($last). Kotta key add cheyandi."
    }

    private fun call(key: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("contents", contents)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Retry("HTTP $code")

        val parts = JSONObject(txt).optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "(reply raale)"
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().ifBlank { "(reply raale)" }
    }
}
