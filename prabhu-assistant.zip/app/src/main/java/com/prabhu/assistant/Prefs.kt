package com.prabhu.assistant

import android.content.Context

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Prefs {
    const val SLOTS = 6
    val LANGS = listOf("te-IN" to "Telugu", "en-IN" to "English", "hi-IN" to "Hindi")

    private fun sp(c: Context) = c.getSharedPreferences("prabhu", Context.MODE_PRIVATE)

    fun keys(c: Context): List<String> =
        (0 until SLOTS).map { sp(c).getString("k$it", "")!!.trim() }

    fun saveKeys(c: Context, v: List<String>) {
        val e = sp(c).edit()
        v.forEachIndexed { i, s -> e.putString("k$i", s.trim()) }
        e.apply()
    }

    fun lang(c: Context): String = sp(c).getString("lang", "te-IN")!!
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
}
