package com.prabhu.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val fields = ArrayList<EditText>()
    private lateinit var permTv: TextView
    private lateinit var langBtn: Button

    private val BG = 0xFF0E1116.toInt()
    private val SURFACE = 0xFF171C25.toInt()
    private val LINE = 0xFF2A3345.toInt()
    private val ACCENT = 0xFF5B8CFF.toInt()
    private val MUTE = 0xFF97A2B6.toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(32))
        }

        col.addView(text("Prabhu", 28f, Color.WHITE, true))
        col.addView(text("\"Hello Prabhu\" ani pilisthe, e app lo unna screen meedha vastundi.", 14f, MUTE, false, 4, 20))

        col.addView(text("Permissions", 16f, Color.WHITE, true, 0, 8))
        permTv = text("", 14f, MUTE, false, 0, 8)
        col.addView(permTv)
        col.addView(button("Mic + notification permission", false) { askMic() })
        col.addView(button("Display over other apps", false) { askOverlay() })

        col.addView(text("API keys", 16f, Color.WHITE, true, 24, 4))
        col.addView(text("Oka key limit ayithe, adi automatic ga next key ki velthundi.", 13f, MUTE, false, 0, 8))
        val saved = Prefs.keys(this)
        for (i in 0 until Prefs.SLOTS) {
            val e = EditText(this).apply {
                hint = "Slot ${i + 1}"
                setText(saved[i])
                setHintTextColor(0xFF5B6678.toInt())
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                setSingleLine()
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = box(SURFACE, LINE, 12)
            }
            fields.add(e)
            col.addView(e, lp(0, 6))
        }
        col.addView(button("Save keys", false) {
            Prefs.saveKeys(this, fields.map { it.text.toString() })
            val n = Prefs.keys(this).count { it.isNotEmpty() }
            Toast.makeText(this, "$n key(s) saved", Toast.LENGTH_SHORT).show()
        })

        col.addView(text("Voice language", 16f, Color.WHITE, true, 24, 8))
        langBtn = button("", false) { cycleLang() }
        col.addView(langBtn)

        col.addView(text("Assistant", 16f, Color.WHITE, true, 24, 8))
        col.addView(button("Start listening", true) { start() })
        col.addView(button("Stop", false) {
            startService(Intent(this, AssistantService::class.java).setAction("STOP"))
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(col)
        })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val ov = Settings.canDrawOverlays(this)
        permTv.text = "Mic: ${if (mic) "ready" else "needed"}    Overlay: ${if (ov) "ready" else "needed"}"
        val name = Prefs.LANGS.first { it.first == Prefs.lang(this) }.second
        langBtn.text = "Language: $name (tap to change)"
    }

    private fun cycleLang() {
        val i = Prefs.LANGS.indexOfFirst { it.first == Prefs.lang(this) }
        Prefs.setLang(this, Prefs.LANGS[(i + 1) % Prefs.LANGS.size].first)
        refresh()
    }

    private fun askMic() {
        val p = ArrayList<String>()
        p.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun askOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun start() {
        Prefs.saveKeys(this, fields.map { it.text.toString() })
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mundu mic permission ivvandi", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Mundu overlay permission ivvandi", Toast.LENGTH_LONG).show(); return
        }
        startForegroundService(Intent(this, AssistantService::class.java))
        Toast.makeText(this, "Ippudu \"Hello Prabhu\" anandi", Toast.LENGTH_LONG).show()
    }

    // ---------- UI helpers ----------

    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); setStroke(dp(1), stroke)
    }

    private fun lp(top: Int, bottom: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun text(s: String, sp: Float, color: Int, bold: Boolean, top: Int = 0, bottom: Int = 0) =
        TextView(this).apply {
            text = s
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            layoutParams = lp(top, bottom)
        }

    private fun button(label: String, primary: Boolean, onClick: (View) -> Unit) =
        Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(if (primary) Color.WHITE else 0xFFE8ECF4.toInt())
            background = if (primary) box(ACCENT, ACCENT, 12) else box(SURFACE, LINE, 12)
            layoutParams = lp(6, 0)
            setOnClickListener(onClick)
        }
}
