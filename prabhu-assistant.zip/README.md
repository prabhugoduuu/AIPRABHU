# Prabhu - voice assistant for Android

Say "Hello Prabhu" and a panel appears over whatever app is open.

Build: push to GitHub -> Actions tab -> "Build APK" -> download "Prabhu-APK".
Add your own API keys inside the app (Slot 1-6). Keys stay on the phone.
