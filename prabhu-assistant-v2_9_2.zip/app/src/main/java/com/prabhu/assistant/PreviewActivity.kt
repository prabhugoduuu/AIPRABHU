package com.prabhu.assistant

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.graphics.Typeface
import android.os.Bundle
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Shows the page the AI wrote, running live. "Float" shrinks it into a picture-in-picture window. */
class PreviewActivity : Activity() {
    private var web: WebView? = null
    private var bar: LinearLayout? = null
    private var html = ""
    private var name = "preview.html"

    private fun tv(s: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Theme.load(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        readIntent(intent)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cBg) }
        val tb = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        bar = tb
        tb.addView(tv("←", 22f, cText).apply { setPadding(dp(12), dp(6), dp(12), dp(6)); setOnClickListener { finish() } })
        tb.addView(tv("👁  " + name.substringAfterLast('/'), 15f, cText, true).apply { gravity = Gravity.CENTER_VERTICAL },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tb.addView(tv("⧉ Float", 13f, cAccent, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { goFloat() }
        })
        tb.addView(tv("💾 Save", 13f, cAccent, true).apply {
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener {
                val n = name.substringAfterLast('/').ifBlank { "preview.html" }
                val r = CodeFiles.save(this@PreviewActivity, n, html.toByteArray(Charsets.UTF_8), "text/html")
                Toast.makeText(this@PreviewActivity, if (r != null) "Saved: $r" else "Couldn't save", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(View(this).apply { background = accentGrad() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)))

        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = false
        w.settings.setSupportZoom(true)
        w.webViewClient = WebViewClient()
        w.webChromeClient = WebChromeClient()
        w.setBackgroundColor(0xFFFFFFFF.toInt())
        web = w
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(FrameLayout(this).apply { addView(root) })
        w.loadDataWithBaseURL("https://preview.local/", html, "text/html", "utf-8", null)
    }

    private fun readIntent(i: android.content.Intent?) {
        name = i?.getStringExtra("name") ?: "preview.html"
        html = try { File(i?.getStringExtra("path") ?: "").readText() } catch (e: Exception) { "" }
    }

    /** A new preview was opened while this screen was already showing: show the new page. */
    override fun onNewIntent(i: android.content.Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        readIntent(i)
        web?.loadDataWithBaseURL("https://preview.local/", html, "text/html", "utf-8", null)
    }

    private fun goFloat() {
        try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(9, 16)).build())
        } catch (e: Exception) {
            Toast.makeText(this, "Floating window is not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        bar?.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
    }

    override fun onDestroy() {
        web?.destroy()
        web = null
        super.onDestroy()
    }
}
