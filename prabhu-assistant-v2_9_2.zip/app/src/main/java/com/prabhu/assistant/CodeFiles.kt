package com.prabhu.assistant

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Finds code blocks in an AI answer and saves them as real files (Downloads/Prabhu) or one zip. */
object CodeFiles {
    class F(val name: String, val code: String, val lang: String = "")

    private val fence = Regex("""^[ \t]*```([\w+#.\-]*)[ \t]*\n(.*?)\n[ \t]*```[ \t]*$""",
        setOf(RegexOption.MULTILINE, RegexOption.DOT_MATCHES_ALL))
    private val fileName = Regex("""([\w\-. /]*\w\.[A-Za-z0-9]{1,8})""")

    private val extOf = mapOf(
        "kotlin" to "kt", "kt" to "kt", "kts" to "kts", "java" to "java", "python" to "py", "py" to "py",
        "javascript" to "js", "js" to "js", "jsx" to "jsx", "typescript" to "ts", "ts" to "ts", "tsx" to "tsx",
        "html" to "html", "css" to "css", "json" to "json", "xml" to "xml", "bash" to "sh", "sh" to "sh",
        "shell" to "sh", "zsh" to "sh", "c" to "c", "cpp" to "cpp", "c++" to "cpp", "csharp" to "cs", "cs" to "cs",
        "go" to "go", "rust" to "rs", "rs" to "rs", "php" to "php", "ruby" to "rb", "rb" to "rb", "sql" to "sql",
        "yaml" to "yml", "yml" to "yml", "md" to "md", "markdown" to "md", "swift" to "swift", "dart" to "dart",
        "gradle" to "gradle", "toml" to "toml", "ini" to "ini", "csv" to "csv", "txt" to "txt", "text" to "txt",
        "r" to "r", "lua" to "lua", "svg" to "svg", "dockerfile" to "Dockerfile", "bat" to "bat"
    )

    fun extract(text: String): List<F> {
        val out = ArrayList<F>()
        var n = 0
        for (m in fence.findAll(text)) {
            val lang = m.groupValues[1].lowercase()
            val code = m.groupValues[2]
            if (code.isBlank()) continue
            n++
            var name: String? = null
            // the line just before the code block may name the file, e.g. **index.html** or "File: app/main.py"
            val before = text.substring(0, m.range.first).trimEnd().lines().lastOrNull().orEmpty()
            if (before.length in 1..120) {
                val clean = before.replace(Regex("""[*#`"':>]"""), " ").trim()
                name = fileName.findAll(clean).lastOrNull()?.groupValues?.get(1)?.trim()
            }
            if (name.isNullOrBlank()) name = "code_$n." + (extOf[lang] ?: "txt")
            out.add(F(safe(name), code, lang))
        }
        return out
    }

    private fun safe(n: String) = n.trim().trimStart('/', '.').replace("..", ".").replace(Regex("""[^\w\-./ ]"""), "_")
        .ifBlank { "file.txt" }

    private fun mimeOf(name: String): String {
        val x = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(x) ?: "application/octet-stream"
    }

    /** Saves to Downloads/Prabhu. Returns where it went, or null if it failed. */
    fun save(c: Context, name: String, bytes: ByteArray, mime: String = mimeOf(name)): String? {
        val file = name.substringAfterLast('/')
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, file)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/Prabhu")
                }
                val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return null
                c.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: return null
                "Downloads/Prabhu/$file"
            } else {
                val dir = File(c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Prabhu").apply { mkdirs() }
                File(dir, file).writeBytes(bytes)
                "Android/data/${c.packageName}/files/Download/Prabhu/$file"
            }
        } catch (e: Exception) { null }
    }

    fun saveOne(c: Context, f: F): String? = save(c, f.name, f.code.toByteArray(Charsets.UTF_8))

    fun saveZip(c: Context, files: List<F>): String? {
        val o = ByteArrayOutputStream()
        val used = HashSet<String>()
        ZipOutputStream(o).use { z ->
            for (f in files) {
                var n = f.name
                var k = 1
                while (!used.add(n)) { k++; n = "${f.name.substringBeforeLast('.')}_$k.${f.name.substringAfterLast('.', "txt")}" }
                z.putNextEntry(ZipEntry(n))
                z.write(f.code.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return save(c, "prabhu_code_${System.currentTimeMillis() / 1000}.zip", o.toByteArray(), "application/zip")
    }
}

/** Live preview of HTML / SVG answers (inside the app, in a floating overlay panel, or as picture-in-picture). */
object Preview {
    private fun ext(n: String) = n.substringAfterLast('.', "").lowercase()

    fun can(f: CodeFiles.F): Boolean {
        val x = ext(f.name)
        if (x == "html" || x == "htm" || x == "svg") return true
        val head = f.code.trimStart().take(300).lowercase()
        return (f.lang == "html" || f.lang == "svg") || head.startsWith("<!doctype html") || head.startsWith("<html")
    }

    /** Turns the code block into one complete page. Other code blocks (style.css, script.js) are inlined if the page links to them. */
    fun build(all: List<CodeFiles.F>, f: CodeFiles.F): String {
        var h = f.code
        val lower = h.trimStart().take(300).lowercase()
        val shell = "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        if (ext(f.name) == "svg" || (lower.startsWith("<svg") && !lower.contains("<html"))) {
            return shell + "<style>body{margin:0;display:flex;align-items:center;justify-content:center;" +
                "min-height:100vh;background:#fff}svg{max-width:100%;height:auto}</style></head><body>" + h + "</body></html>"
        }
        fun find(ref: String): CodeFiles.F? {
            val n = ref.substringAfterLast('/')
            return all.firstOrNull { it !== f && it.name.substringAfterLast('/') == n }
        }
        h = Regex("<link[^>]+href=[\"']([^\"']+\\.css)[\"'][^>]*>", RegexOption.IGNORE_CASE).replace(h) { mr ->
            val c = find(mr.groupValues[1])
            if (c != null) "<style>\n" + c.code + "\n</style>" else mr.value
        }
        h = Regex("<script([^>]*?)src=[\"']([^\"']+\\.js)[\"']([^>]*)>\\s*</script>", RegexOption.IGNORE_CASE).replace(h) { mr ->
            val c = find(mr.groupValues[2])
            if (c != null) "<script>\n" + c.code + "\n</script>" else mr.value
        }
        if (!h.contains("<html", true)) return shell + "</head><body>" + h + "</body></html>"
        if (!h.contains("viewport", true)) {
            h = if (h.contains("<head>", true)) h.replaceFirst(Regex("<head>", RegexOption.IGNORE_CASE),
                "<head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">") else h
        }
        return h
    }

    /** Opens the preview screen. Works from an Activity or from the floating overlay service. */
    fun open(ctx: android.content.Context, all: List<CodeFiles.F>, f: CodeFiles.F) {
        try {
            val file = File(ctx.cacheDir, "preview.html")
            file.writeText(build(all, f))
            val i = android.content.Intent(ctx, PreviewActivity::class.java)
                .putExtra("path", file.absolutePath).putExtra("name", f.name)
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "Couldn't open the preview", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
}
