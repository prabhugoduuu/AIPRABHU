package com.prabhu.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Ai {
    class Result(val ok: Boolean, val text: String, val used: String)

    private class Retry(msg: String) : Exception(msg)

    private const val SYS =
        "You are Prabhu, a brilliant, extremely capable personal AI assistant. Reply in the same language the user writes in " +
        "(Telugu, English or Tenglish). Be clear, accurate and friendly. Start answering immediately, no preamble. " +
        "Think carefully before answering, double-check facts, maths and code, and never invent facts: say so when you are unsure. " +
        "When live web search is available, use it for anything recent, changing or uncertain. " +
        "Keep answers concise unless the user asks for detail. Use simple markdown when it helps. " +
        "When asked for code or a file, put EACH file in its own fenced code block and write the file name alone on the line just before it " +
        "(for example **index.html**). Always give the complete file, never cut it short. " +
        "For web pages give ONE self-contained index.html (inline CSS and JS) so it can be previewed. " +
        "The app shows a Save button and a Preview button for every code block."
    private const val CODER =
        " CODING RULES: Think about the requirements and edge cases first. Give COMPLETE working files, never placeholders or '...'. " +
        "The code must compile or run as-is: check imports, types, null-safety and every name you use. Handle errors and empty input. " +
        "Start with a PLAN of at most 6 short bullet points, then the code, then one line on how to run or test it."
    private const val REVIEW =
        "Review the code in your last answer like a strict senior engineer: look for bugs, compile or syntax errors, missing imports, " +
        "missing files, unhandled edge cases and anything incomplete. If everything is correct reply with exactly: OK. " +
        "Otherwise reply with one line starting 'Fixed:' (what you fixed), then the COMPLETE corrected files, " +
        "each in its own fenced code block with the file name on the line before it."
    private val codeWords = Regex(
        "(?i)(\\bcode\\b|coding|\\bscript\\b|program|\\bhtml\\b|\\bcss\\b|javascript|\\bjs\\b|kotlin|python|\\bjava\\b|c\\+\\+|\\bapp\\b|website|web ?page|function|\\bclass\\b|\\bbug\\b|compile|\\bapk\\b|\\bgame\\b|calculator|\\bapi\\b|\\bsql\\b|\\bjson\\b|react|android|```)"
    )
    fun looksLikeCode(t: String) = t.length > 12 && codeWords.containsMatchIn(t)
    private const val BRIEF = " This answer will be read aloud: keep it short and conversational, with no markdown."

    private fun now(): String = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm z", Locale.ENGLISH).format(Date())

    /**
     * Tries the active model first; if it fails and fallback is on, tries the other models in order.
     * [onText] is called (from the background thread) with the full answer so far, as it streams in.
     * [maxMode] = deepest thinking + web search + long answers (automatically steps down if a model doesn't support it).
     * [base] replaces the default system prompt (used by the self-improve tool).
     */
    fun ask(
        models: List<ModelCfg>, active: Int, fallback: Boolean, msgs: List<Msg>, brief: Boolean,
        extra: String = "", onText: ((String) -> Unit)? = null,
        maxMode: Boolean = true, base: String? = null, histLimit: Int = 14, coder: Boolean = false
    ): Result {
        val order = ArrayList<ModelCfg>()
        models.getOrNull(active)?.let { order.add(it) }
        if (fallback) models.forEachIndexed { i, m -> if (i != active) order.add(m) }
        val list = order.filter { it.key.isNotBlank() }
        if (list.isEmpty()) return Result(false, "No API key set for this model. Open Settings and add one.", "")

        val hist = msgs.takeLast(histLimit).dropWhile { it.role != "user" }.filter { it.text.isNotBlank() }
        // Only the two most recent messages with files are sent along, to keep requests small.
        val withAtt = hist.indices.filter { hist[it].role == "user" && hist[it].atts.isNotEmpty() }.takeLast(2).toSet()
        val sys = (base ?: SYS) + " Current date and time: " + now() + "." + (if (brief) BRIEF else "") + extra
        val max = maxMode && !brief
        val errs = ArrayList<String>()
        // Coder mode: plan + code, then the model reviews its own code and fixes bugs before you see the final answer.
        val doCode = coder && !brief && base == null && looksLikeCode(hist.lastOrNull { it.role == "user" }?.text ?: "")
        fun one(m: ModelCfg, s: String, h: List<Msg>, cb: ((String) -> Unit)?): String = when (m.type) {
            "claude" -> claude(m, s, h, withAtt, cb, max)
            "gemini" -> gemini(m, s, h, withAtt, cb, max)
            else -> openai(m, s, h, withAtt, cb, max)
        }
        for (m in list) {
            try {
                if (m.modelId.isBlank()) throw Retry("model ID is empty")
                val s2 = if (doCode) sys + CODER else sys
                var out = one(m, s2, hist, onText)
                if (doCode) {
                    onText?.invoke(out + "\n\n🔍 Reviewing the code…")
                    val rv = try {
                        one(m, s2, hist + Msg("assistant", out) + Msg("user", REVIEW), null).trim()
                    } catch (e: Exception) { "OK" }
                    val fine = rv.length < 16 && rv.startsWith("OK", true)
                    if (!fine && rv.contains("```")) out = rv
                }
                return Result(true, out, m.name)
            } catch (e: Exception) {
                errs.add("${m.name}: ${e.message}" + hint(e.message ?: ""))
            }
        }
        return Result(false, "Couldn't get a reply.\n" + errs.joinToString("\n"), "")
    }

    private fun connect(url: String, headers: Map<String, String>, body: JSONObject, sse: Boolean): HttpURLConnection {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 300000   // deep thinking can take a while before the first word
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (sse) {
                setRequestProperty("Accept", "text/event-stream")
                setRequestProperty("Accept-Encoding", "identity")   // gzip would hold words back until a block is full
            }
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) {
            val txt = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            val detail = try {
                val o = JSONObject(txt)
                o.optJSONObject("error")?.optString("message") ?: o.optString("error")
            } catch (e: Exception) { "" }
            throw Retry("HTTP $code ${detail.take(100)}")
        }
        return conn
    }

    /** Server-sent events: calls [onData] for every "data: ..." line as it arrives. */
    private fun stream(url: String, headers: Map<String, String>, body: JSONObject, onData: (String) -> Unit) {
        val conn = connect(url, headers, body, true)
        conn.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val d = line.substring(5).trim()
                if (d.isEmpty() || d == "[DONE]") continue
                onData(d)
            }
        }
    }

    private fun isBadRequest(e: Retry) = (e.message ?: "").startsWith("HTTP 400")

    /** A 400 means the model doesn't support an option; a 429 on search/thinking (their quota is separate) is also worth a lighter retry. */
    private fun canStepDown(e: Retry, tier: Int) =
        isBadRequest(e) || (tier <= 1 && (e.message ?: "").startsWith("HTTP 429"))

    private fun hint(m: String) = when {
        m.startsWith("HTTP 404") -> "\n   → Model ID not found. Settings → tap this model and fix the ID, or tap ★ Upgrade."
        m.startsWith("HTTP 429") -> "\n   → Quota used up for this key. Wait a few minutes, add another key, or turn Max mode off."
        m.startsWith("HTTP 401") || m.startsWith("HTTP 403") -> "\n   → This API key is not accepted for that model."
        else -> ""
    }

    private fun fileText(a: Att) = "File \"${a.name}\":\n${a.data}"

    // ---------------------------------------------------------------- Claude

    private fun claude(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?, max: Boolean): String {
        val arr = JSONArray()
        h.forEachIndexed { i, x ->
            val role = if (x.role == "user") "user" else "assistant"
            val at = if (i in withAtt) x.atts else emptyList()
            if (at.isEmpty()) {
                arr.put(JSONObject().put("role", role).put("content", x.text))
            } else {
                val c = JSONArray()
                for (a in at) {
                    when (a.kind) {
                        "image" -> c.put(JSONObject().put("type", "image").put("source",
                            JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", a.data)))
                        "pdf" -> c.put(JSONObject().put("type", "document").put("source",
                            JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", a.data)))
                        "media" -> c.put(JSONObject().put("type", "text").put("text", "[Attached ${a.name}: this model can't listen to audio/video. Use a Gemini model.]"))
                        else -> c.put(JSONObject().put("type", "text").put("text", fileText(a)))
                    }
                }
                c.put(JSONObject().put("type", "text").put("text", x.text))
                arr.put(JSONObject().put("role", role).put("content", c))
            }
        }

        // tier 0: adaptive thinking at max effort + live web search + 64k answer
        // tier 1: same with high effort, tier 2: no thinking options, tier 3: plain
        fun body(tier: Int): JSONObject {
            val o = JSONObject().put("model", m.modelId).put("stream", true).put("system", sys).put("messages", arr)
            when (tier) {
                0 -> {
                    o.put("max_tokens", 64000)
                    o.put("thinking", JSONObject().put("type", "adaptive"))
                    o.put("output_config", JSONObject().put("effort", "max"))
                    o.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5)))
                }
                1 -> {
                    o.put("max_tokens", 32000)
                    o.put("thinking", JSONObject().put("type", "adaptive"))
                    o.put("output_config", JSONObject().put("effort", "high"))
                    o.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5)))
                }
                2 -> {
                    o.put("max_tokens", 16000)
                    o.put("tools", JSONArray().put(JSONObject().put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5)))
                }
                else -> o.put("max_tokens", 16000)
            }
            return o
        }

        val first = if (max) 0 else 3
        for (tier in first..3) {
            val sb = StringBuilder()
            try {
                stream(
                    "https://api.anthropic.com/v1/messages",
                    mapOf("x-api-key" to m.key, "anthropic-version" to "2023-06-01"), body(tier)
                ) { d ->
                    val o = JSONObject(d)
                    when (o.optString("type")) {
                        "content_block_start" -> {
                            val t = o.optJSONObject("content_block")?.optString("type") ?: ""
                            if (t == "text" && sb.isNotEmpty() && !sb.endsWith("\n")) sb.append("\n\n")
                        }
                        "content_block_delta" -> {
                            val t = o.optJSONObject("delta")?.optString("text") ?: ""
                            if (t.isNotEmpty()) { sb.append(t); cb?.invoke(sb.toString()) }
                        }
                        "error" -> throw Retry("API error " + (o.optJSONObject("error")?.optString("message") ?: "").take(100))
                    }
                }
                return sb.toString().ifBlank { "(empty reply)" }
            } catch (e: Retry) {
                if (sb.isEmpty() && canStepDown(e, tier) && tier < 3) continue
                throw e
            }
        }
        throw Retry("no reply")
    }

    // ---------------------------------------------------------------- Gemini

    private fun gemini(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?, max: Boolean): String {
        val contents = JSONArray()
        h.forEachIndexed { i, x ->
            val parts = JSONArray()
            val at = if (i in withAtt) x.atts else emptyList()
            for (a in at) {
                when (a.kind) {
                    "image" -> parts.put(JSONObject().put("inlineData",
                        JSONObject().put("mimeType", "image/jpeg").put("data", a.data)))
                    "pdf" -> parts.put(JSONObject().put("inlineData",
                        JSONObject().put("mimeType", "application/pdf").put("data", a.data)))
                    "media" -> parts.put(JSONObject().put("inlineData",
                        JSONObject().put("mimeType", a.mime).put("data", a.data)))
                    else -> parts.put(JSONObject().put("text", fileText(a)))
                }
            }
            parts.put(JSONObject().put("text", x.text))
            contents.put(JSONObject().put("role", if (x.role == "user") "user" else "model").put("parts", parts))
        }
        val id = m.modelId.lowercase()
        val ver = Regex("(\\d+)(?:\\.(\\d+))?").find(id.removePrefix("gemini-"))
        val major = ver?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val minor = ver?.groupValues?.get(2)?.toIntOrNull() ?: 0

        fun think(tier: Int): JSONObject? = when {
            tier <= 1 -> when {
                major >= 3 -> JSONObject().put("thinkingLevel", "high")
                major == 2 && minor >= 5 -> JSONObject().put("thinkingBudget", -1)
                else -> null
            }
            // fast mode: thinking delays the first word, so keep it minimal on Flash models
            tier == 2 -> when {
                !id.contains("flash") || id.contains("lite") -> null
                id.contains("2.5") -> JSONObject().put("thinkingBudget", 0)
                id.contains("gemini-3") -> JSONObject().put("thinkingLevel", "low")
                else -> null
            }
            else -> null
        }

        // tier 0: deep thinking + Google Search, tier 1: deep thinking, tier 2: fast settings, tier 3: plain
        fun body(tier: Int): JSONObject {
            val b = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents)
            val gc = JSONObject()
            think(tier)?.let { gc.put("thinkingConfig", it) }
            if (tier <= 1) gc.put("maxOutputTokens", 32768)
            if (gc.length() > 0) b.put("generationConfig", gc)
            if (tier == 0) b.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            return b
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${m.modelId}:streamGenerateContent?alt=sse"
        val hdr = mapOf("x-goog-api-key" to m.key)
        val first = if (max) 0 else 2
        for (tier in first..3) {
            val sb = StringBuilder()
            var blocked = ""
            try {
                stream(url, hdr, body(tier)) { d ->
                    val o = JSONObject(d)
                    val parts = o.optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) {
                        var added = false
                        for (i in 0 until parts.length()) {
                            val p = parts.getJSONObject(i)
                            if (p.optBoolean("thought", false)) continue
                            val t = p.optString("text")
                            if (t.isNotEmpty()) { sb.append(t); added = true }
                        }
                        if (added) cb?.invoke(sb.toString())
                    } else {
                        val br = o.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                        if (br.isNotEmpty()) blocked = br
                    }
                }
                if (sb.isBlank() && blocked.isNotEmpty()) throw Retry("blocked: $blocked")
                return sb.toString().ifBlank { "(empty reply)" }
            } catch (e: Retry) {
                if (sb.isEmpty() && canStepDown(e, tier) && tier < 3) continue
                throw e
            }
        }
        throw Retry("no reply")
    }

    // ---------------------------------------------------------------- OpenAI-compatible

    /** OpenAI, Groq, OpenRouter and any other OpenAI-compatible API. PDFs are sent as page images. */
    private fun openai(m: ModelCfg, sys: String, h: List<Msg>, withAtt: Set<Int>, cb: ((String) -> Unit)?, max: Boolean): String {
        val base = m.baseUrl.trim().trimEnd('/').ifEmpty { "https://api.openai.com/v1" }
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
        fun imageBlock(b64: String) = JSONObject().put("type", "image_url").put("image_url",
            JSONObject().put("url", "data:image/jpeg;base64,$b64"))
        h.forEachIndexed { i, x ->
            val role = if (x.role == "user") "user" else "assistant"
            val at = if (i in withAtt) x.atts else emptyList()
            if (at.isEmpty()) {
                arr.put(JSONObject().put("role", role).put("content", x.text))
            } else {
                val c = JSONArray()
                for (a in at) {
                    when (a.kind) {
                        "image" -> c.put(imageBlock(a.data))
                        "pdf" -> {
                            c.put(JSONObject().put("type", "text").put("text",
                                "PDF \"${a.name}\" (first ${a.pages.size} pages shown as images):"))
                            a.pages.forEach { c.put(imageBlock(it)) }
                        }
                        "media" -> c.put(JSONObject().put("type", "text").put("text", "[Attached ${a.name}: this model can't listen to audio/video. Use a Gemini model.]"))
                        else -> c.put(JSONObject().put("type", "text").put("text", fileText(a)))
                    }
                }
                c.put(JSONObject().put("type", "text").put("text", x.text))
                arr.put(JSONObject().put("role", role).put("content", c))
            }
        }
        val reasoning = max && base.contains("api.openai.com") &&
            Regex("^(o\\d|gpt-5)").containsMatchIn(m.modelId.lowercase())
        for (tier in (if (reasoning) 0 else 1)..1) {
            val body = JSONObject().put("model", m.modelId).put("messages", arr).put("stream", true)
            if (tier == 0) body.put("reasoning_effort", "high")
            val sb = StringBuilder()
            try {
                stream("$base/chat/completions", mapOf("Authorization" to "Bearer ${m.key}"), body) { d ->
                    val t = JSONObject(d).optJSONArray("choices")?.optJSONObject(0)
                        ?.optJSONObject("delta")?.optString("content") ?: ""
                    if (t.isNotEmpty() && t != "null") { sb.append(t); cb?.invoke(sb.toString()) }
                }
                return sb.toString().ifBlank { "(empty reply)" }
            } catch (e: Retry) {
                if (sb.isEmpty() && isBadRequest(e) && tier == 0) continue
                throw e
            }
        }
        throw Retry("no reply")
    }
}

/** Finds the strongest model a given API key can use, so "super max" never depends on a hard-coded model name. */
object Discover {
    private val skip = Regex(
        "embed|tts|whisper|dall|image|audio|realtime|moderation|transcribe|vision|imagen|veo|live|robot|aqa|guard|search-preview|computer-use|learnlm|gemma|banana|research|agent|deep-think|customtools",
        RegexOption.IGNORE_CASE
    )

    private fun httpGet(url: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code ${txt.take(80)}")
        return txt
    }

    /** Model IDs this key can use, strongest first. Throws if the list can't be fetched. */
    fun ranked(m: ModelCfg): List<String> {
        val ids = ArrayList<String>()
        when (m.type) {
            "claude" -> {
                val o = JSONObject(httpGet("https://api.anthropic.com/v1/models?limit=100",
                    mapOf("x-api-key" to m.key, "anthropic-version" to "2023-06-01")))
                val a = o.optJSONArray("data") ?: JSONArray()
                for (i in 0 until a.length()) ids.add(a.getJSONObject(i).optString("id"))
            }
            "gemini" -> {
                val o = JSONObject(httpGet("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
                    mapOf("x-goog-api-key" to m.key)))
                val a = o.optJSONArray("models") ?: JSONArray()
                for (i in 0 until a.length()) {
                    val x = a.getJSONObject(i)
                    val methods = x.optJSONArray("supportedGenerationMethods")?.toString() ?: ""
                    if (methods.contains("generateContent")) ids.add(x.optString("name").removePrefix("models/"))
                }
            }
            else -> {
                val base = m.baseUrl.trim().trimEnd('/').ifEmpty { "https://api.openai.com/v1" }
                val o = JSONObject(httpGet("$base/models", mapOf("Authorization" to "Bearer ${m.key}")))
                val a = o.optJSONArray("data") ?: JSONArray()
                for (i in 0 until a.length()) ids.add(a.getJSONObject(i).optString("id"))
            }
        }
        return ids.filter { it.isNotBlank() && !skip.containsMatchIn(it) }.distinct()
            .sortedByDescending { score(m.type, it) }
    }

    private fun score(type: String, id: String): Int {
        val s = id.lowercase()
        val v = Regex("(?<!\\d)(\\d{1,2})(?:[.\\-](\\d{1,2})(?!\\d))?").find(s)
        val major = v?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val minor = v?.groupValues?.get(2)?.toIntOrNull() ?: 0
        val low = Regex("haiku|mini|nano|lite|small|instant|8b|7b").containsMatchIn(s)
        val tier = when {
            Regex("mythos|fable|ultra").containsMatchIn(s) -> 6
            s.contains("opus") || s.contains("-pro") || s.contains("max") || s.contains("large") -> 5
            s.contains("sonnet") -> 4
            s.contains("flash") -> 3
            low -> 1
            else -> 4
        }
        val stable = if (Regex("preview|exp|beta|latest").containsMatchIn(s)) 0 else 1
        return if (type == "claude") tier * 100000 + major * 1000 + minor * 10 + stable
        else major * 100000 + tier * 1000 + minor * 10 + stable
    }
}
