package com.prabhu.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import kotlin.math.abs

private const val SMATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val SWRAP = ViewGroup.LayoutParams.WRAP_CONTENT

private const val SCREEN_PROMPT =
    " The user is sharing a screenshot of their phone screen. Answer about what is visible, directly and briefly. " +
    "If it shows a quiz or MCQ question, solve it step by step and state the final answer clearly."

/**
 * The floating Prabhu bubble and the chat panel that opens on top of any app.
 *
 *  - BUBBLE:  bubble only (no screen capture needed). Tap it to chat in a small panel over the current app.
 *  - START:   bubble + screen capture (needs the screen-capture permission). The panel also sees the screen.
 *  - OVERLAY: opens the panel straight away, with a screenshot if one is handed over (assistant gesture).
 */
class ScreenService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var capturing = false

        fun start(ctx: Context, action: String, shot: String = ""): Boolean = try {
            ctx.startForegroundService(Intent(ctx, ScreenService::class.java).setAction(action).putExtra("shot", shot))
            true
        } catch (e: Exception) { false }
    }

    private val main = Handler(Looper.getMainLooper())
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val lock = Any()

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var last: Image? = null
    private var thread: HandlerThread? = null
    private var down = false
    private var persistent = false   // the bubble stays after the panel closes
    private var oneShot = false      // the service stops when the panel closes

    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var answer: TextView? = null
    private var answerScroll: ScrollView? = null
    private var codeBox: LinearLayout? = null
    private var input: EditText? = null
    private var modelTv: TextView? = null

    private var shotB64 = ""
    private var shotSent = false
    private var attachedNow = false
    private val convo = ArrayList<Msg>()
    private var busy = false
    private var failedQ: String? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Theme.load(this)
    }

    // ---------------------------------------------------------------- start / stop

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action ?: ""
        if (act == "STOP") { shutdown(); return START_NOT_STICKY }
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        val wantCapture = data != null && !capturing
        Theme.load(this)
        try {
            startFg(wantCapture || capturing)
        } catch (e: Exception) {
            try { startFg(false) } catch (e2: Exception) { stopSelf(); return START_NOT_STICKY }
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow 'Display over other apps' for Prabhu")
            shutdown()
            return START_NOT_STICKY
        }
        if (wantCapture && data != null) startCapture(code, data)
        running = true
        if (act == "OVERLAY") {
            val shot = intent?.getStringExtra("shot").orEmpty()
            if (bubble == null && !persistent) oneShot = true
            main.post { openPanel(shot) }
        } else {
            persistent = true
            oneShot = false
            main.post { if (bubble == null) showBubble() }
        }
        return START_NOT_STICKY
    }

    private fun startFg(capture: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("prabhu_screen", "Prabhu bubble", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val icon = Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel)
        val n = Notification.Builder(this, "prabhu_screen")
            .setContentTitle("Prabhu bubble is on")
            .setContentText(if (capture) "Tap the P bubble on any screen to ask about it" else "Tap the P bubble to chat on top of any app")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(icon, "Stop", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                2, n,
                if (capture) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(2, n)
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            projection = p
            val t = HandlerThread("prabhu-capture")
            t.start()
            thread = t
            val bg = Handler(t.looper)
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post {
                        if (capturing) {
                            stopCapture()
                            try { startFg(false) } catch (e: Exception) { }
                        }
                    }
                }
            }, bg)
            setupCapture(p, bg)
            capturing = true
        } catch (e: Exception) {
            toast("Couldn't start screen capture. The bubble still works without it.")
            stopCapture()
        }
    }

    private fun setupCapture(p: MediaProjection, bg: Handler) {
        val dm = resources.displayMetrics
        val big = maxOf(dm.widthPixels, dm.heightPixels)
        val scale = if (big > 1280) 1280f / big else 1f
        val cw = maxOf(2, (dm.widthPixels * scale).toInt())
        val ch = maxOf(2, (dm.heightPixels * scale).toInt())
        val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                synchronized(lock) {
                    last?.close()
                    last = img
                }
            }
        }, bg)
        reader = r
        vd = p.createVirtualDisplay(
            "prabhu-screen", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, bg
        )
    }

    private fun stopCapture() {
        capturing = false
        try { vd?.release() } catch (e: Exception) { }
        vd = null
        synchronized(lock) {
            try { last?.close() } catch (e: Exception) { }
            last = null
        }
        try { reader?.close() } catch (e: Exception) { }
        reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        thread?.quitSafely()
        thread = null
    }

    private fun shutdown() {
        if (down) return
        down = true
        running = false
        closePanel()
        try { bubble?.let { wm.removeView(it) } } catch (e: Exception) { }
        bubble = null
        stopCapture()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(s: CharSequence, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, r: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
    }

    private fun chip(label: String, f: () -> Unit) = tv(label, 13f, cText).apply {
        background = rounded(cSurface2, 16)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        setOnClickListener { f() }
    }

    /** The newest frame of the screen as a base64 JPEG, or null if nothing was captured yet. */
    private fun grab(): String? {
        synchronized(lock) {
            val img = last ?: return null
            return try {
                val pl = img.planes[0]
                val buf = pl.buffer
                buf.rewind()
                val w = pl.rowStride / pl.pixelStride
                val bmp = Bitmap.createBitmap(w, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf)
                val crop = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                val o = ByteArrayOutputStream()
                crop.compress(Bitmap.CompressFormat.JPEG, 75, o)
                Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            } catch (e: Exception) {
                null
            }
        }
    }

    /** A screenshot file (from the assistant gesture) as a smaller base64 JPEG. */
    private fun loadShot(path: String): String {
        if (path.isEmpty()) return ""
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            var s = 1
            while (maxOf(opts.outWidth, opts.outHeight) / s > 1400) s *= 2
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
            if (bmp == null) "" else {
                val o = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 75, o)
                Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            }
        } catch (e: Exception) { "" }
    }

    // ---------------------------------------------------------------- bubble

    private fun showBubble() {
        val size = dp(56)
        val b = TextView(this).apply {
            text = "P"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            background = accentGrad(oval = true)
            alpha = 0.95f
            elevation = dp(6).toFloat()
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(260)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx
                        val dy = e.rawY - ty
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        try { wm.updateViewLayout(v, lp) } catch (ex: Exception) { }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) onBubbleTap()
                }
                return true
            }
        })
        try {
            wm.addView(b, lp)
            bubble = b
        } catch (e: Exception) {
            toast("Allow 'Display over other apps' for Prabhu")
            shutdown()
        }
    }

    private fun onBubbleTap() {
        if (panel != null) return
        var shot = ""
        if (capturing) {
            val g = grab()
            if (g == null) toast("Screen not captured yet, opening without it") else shot = g
        }
        beginPanel(shot)
    }

    private fun openPanel(path: String) {
        if (panel != null) return
        beginPanel(loadShot(path))
    }

    private fun beginPanel(shot: String) {
        shotB64 = shot
        shotSent = false
        convo.clear()
        failedQ = null
        busy = false
        showPanel()
    }

    // ---------------------------------------------------------------- answer panel

    private fun showPanel() {
        bubble?.visibility = View.GONE
        val hasShot = shotB64.isNotEmpty()
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(cSurface)
                val r = dp(22).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(dp(1), cLine)
            }
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv(if (hasShot) "✦  Prabhu · this screen" else "✦  Prabhu", 14f, cText, true), LinearLayout.LayoutParams(0, SWRAP, 1f))
        val mt = tv("", 12f, cAccent, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener { cycleModel() }
        }
        modelTv = mt
        refreshModelLabel()
        top.addView(mt)
        top.addView(tv("⤢", 18f, cText).apply {
            setPadding(dp(10), dp(4), dp(6), dp(4))
            setOnClickListener {
                try {
                    startActivity(Intent(this@ScreenService, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                } catch (e: Exception) { }
                closePanel()
            }
        })
        top.addView(tv("✕", 20f, cText).apply {
            setPadding(dp(12), dp(4), dp(4), dp(4))
            setOnClickListener { closePanel() }
        })
        p.addView(top, LinearLayout.LayoutParams(SMATCH, SWRAP))

        val ans = tv("", 15f, cText).apply {
            setLineSpacing(0f, 1.2f)
            setTextIsSelectable(true)
        }
        answer = ans
        val sc = ScrollView(this).apply { visibility = View.GONE; addView(ans) }
        answerScroll = sc
        p.addView(sc, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(8) })

        val cb = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        codeBox = cb
        p.addView(cb, LinearLayout.LayoutParams(SMATCH, SWRAP))

        // quick actions: asking about the screen when a screenshot is attached, general helpers otherwise
        val chips: List<Triple<String, String, Boolean>> = if (hasShot) listOf(
            Triple("Explain this", "Explain what is on my screen simply.", true),
            Triple("Solve this question", "Solve the question shown on my screen step by step and give the final answer.", true),
            Triple("Translate to Telugu", "Translate the text on my screen to Telugu.", true),
            Triple("Summarize", "Summarize what is on my screen.", true)
        ) else listOf(
            Triple("📸 Read my screen", "", false),
            Triple("Build a web page", "Build a complete single-file index.html web page for: ", false),
            Triple("Explain simply", "Explain simply: ", false),
            Triple("Translate to Telugu", "Translate to Telugu: ", false)
        )
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val et = EditText(this)
        chips.forEach { c ->
            chipRow.addView(chip(c.first) {
                when {
                    c.first.startsWith("📸") -> readScreen()
                    c.third -> ask(c.second)
                    else -> { et.setText(c.second); et.setSelection(et.text.length); et.requestFocus() }
                }
            }, LinearLayout.LayoutParams(SWRAP, SWRAP).apply { rightMargin = dp(8) })
        }
        val hs = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        p.addView(hs, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(10) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cSurface2, 26)
            setPadding(dp(14), dp(2), dp(6), dp(2))
        }
        et.apply {
            hint = if (hasShot) "Ask about this screen…" else "Ask Prabhu anything…"
            setHintTextColor(cMute)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setBackgroundColor(Color.TRANSPARENT)
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }
        input = et
        row.addView(et, LinearLayout.LayoutParams(0, SWRAP, 1f))
        row.addView(tv("↑", 20f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = accentGrad(oval = true)
            setOnClickListener { ask(et.text.toString()) }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        p.addView(row, LinearLayout.LayoutParams(SMATCH, SWRAP).apply { topMargin = dp(10) })

        val lp = WindowManager.LayoutParams(
            SMATCH, SWRAP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            wm.addView(p, lp)
            panel = p
        } catch (e: Exception) {
            bubble?.visibility = View.VISIBLE
            toast("Couldn't open the panel")
            if (oneShot) shutdown()
        }
    }

    /** Hides the panel for a moment so the screen behind it can be captured, then brings it back. */
    private fun readScreen() {
        if (!capturing) {
            // screen capture needs the system permission dialog, which only an app screen can show
            try {
                startActivity(Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("capture", true))
            } catch (e: Exception) { toast("Open Prabhu and start Screen assist") }
            closePanel()
            return
        }
        val p = panel ?: return
        p.visibility = View.INVISIBLE
        main.postDelayed({
            val g = grab()
            p.visibility = View.VISIBLE
            if (g == null) toast("Couldn't read the screen, try again")
            else {
                shotB64 = g
                shotSent = false
                toast("Screen attached. Now ask your question.")
            }
        }, 450)
    }

    private fun closePanel() {
        val p = panel
        if (p != null) {
            try { wm.removeView(p) } catch (e: Exception) { }
        }
        panel = null
        answer = null
        answerScroll = null
        codeBox = null
        input = null
        modelTv = null
        bubble?.visibility = View.VISIBLE
        if (oneShot && !persistent && !down) shutdown()
    }

    private fun refreshModelLabel() {
        val ms = Store.models(this)
        modelTv?.text = "⇄  " + (ms.getOrNull(Store.active(this))?.name ?: "Add model")
    }

    /** Tap the model name to switch to the next model that has a key (and retry if the last try failed). */
    private fun cycleModel() {
        val ms = Store.models(this)
        if (ms.isEmpty()) return
        val cur = Store.active(this)
        for (k in 1..ms.size) {
            val j = (cur + k) % ms.size
            if (ms[j].key.isNotBlank()) {
                Store.setActive(this, j)
                break
            }
        }
        refreshModelLabel()
        val q = failedQ
        if (q != null && !busy) ask(q)
    }

    private fun setAnswer(text: CharSequence, err: Boolean, follow: Int = 0) {
        val a = answer ?: return
        val sc = answerScroll ?: return
        a.setTextColor(if (err) cErr else cText)
        a.text = text
        sc.visibility = View.VISIBLE
        val maxH = (resources.displayMetrics.heightPixels * 0.38f).toInt()
        a.post {
            val lp = sc.layoutParams
            lp.height = if (a.height > maxH) maxH else SWRAP
            sc.layoutParams = lp
            // follow: 0 = jump to top (new answer), 1 = follow the newest words while streaming, 2 = stay put
            if (follow == 0) sc.fullScroll(View.FOCUS_UP) else if (follow == 1) sc.fullScroll(View.FOCUS_DOWN)
        }
    }

    /** Save and Preview buttons under an answer that contains code. */
    private fun showCode(text: String) {
        val box = codeBox ?: return
        box.removeAllViews()
        val files = CodeFiles.extract(text)
        files.take(4).forEach { f ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(chip("💾  " + f.name.substringAfterLast('/').takeLast(24)) {
                toast(CodeFiles.saveOne(this@ScreenService, f)?.let { "Saved: $it" } ?: "Couldn't save the file")
            }, LinearLayout.LayoutParams(SWRAP, SWRAP).apply { rightMargin = dp(8) })
            if (Preview.can(f)) {
                r.addView(chip("👁  Preview") { Preview.open(this@ScreenService, files, f) },
                    LinearLayout.LayoutParams(SWRAP, SWRAP))
            }
            box.addView(r, LinearLayout.LayoutParams(SWRAP, SWRAP).apply { topMargin = dp(6) })
        }
        box.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun ask(text: String) {
        if (busy) return
        val cmd = Cmd.handle(this, text)
        if (cmd != null) {
            input?.setText("")
            cmd.run()
            closePanel()
            return
        }
        val ms = Store.models(this)
        if (ms.none { it.key.isNotBlank() }) {
            setAnswer("Add an API key first: open the Prabhu app → Settings → Add model / API.", true)
            return
        }
        val withShot = shotB64.isNotEmpty()
        val q = text.trim().ifEmpty { if (withShot) "Explain what is on my screen and help me with it." else return }
        failedQ = null
        val um = Msg("user", q)
        attachedNow = false
        if (withShot && !shotSent) {
            um.atts = listOf(Att("image", "image/jpeg", shotB64, "screen.jpg"))
            shotSent = true
            attachedNow = true
        }
        convo.add(um)
        input?.setText("")
        codeBox?.removeAllViews()
        codeBox?.visibility = View.GONE
        setAnswer("Thinking…", false)
        busy = true
        val active = Store.active(this)
        val fb = Store.bool(this, "fallback", true)
        val maxMode = Store.bool(this, "max", true)
        val coder = Store.bool(this, "coder", true)
        val extra = (if (withShot) SCREEN_PROMPT else "") + Mem.extra(this)
        val snap = ArrayList(convo)
        val snapModels = ArrayList(ms)
        var lastPush = 0L
        var streamed = false
        val onText: (String) -> Unit = { t ->
            val now = android.os.SystemClock.uptimeMillis()
            if (now - lastPush >= 60) {
                lastPush = now
                streamed = true
                main.post { if (busy && panel != null) setAnswer(Md.render(t, cSurface2), false, 1) }
            }
        }
        Thread {
            val r = Ai.ask(snapModels, active, fb, snap, false, extra, onText, maxMode, coder = coder)
            main.post { onAnswer(q, r, streamed) }
        }.start()
    }

    private fun onAnswer(q: String, r: Ai.Result, streamed: Boolean) {
        busy = false
        if (r.ok) {
            val clean = Mem.absorb(this, r.text)
            convo.add(Msg("assistant", clean, r.used))
            if (panel == null) return
            setAnswer(Md.render(clean, cSurface2), false, if (streamed) 2 else 0)
            modelTv?.text = "⇄  " + r.used
            showCode(clean)
        } else {
            if (convo.isNotEmpty()) convo.removeAt(convo.lastIndex)
            if (attachedNow) shotSent = false
            failedQ = q
            if (panel == null) return
            setAnswer(r.text + "\n\nTap the model name above to switch model and retry.", true)
        }
    }
}
