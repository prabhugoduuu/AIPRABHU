package com.prabhu.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import java.io.File
import java.io.FileOutputStream

/**
 * Lets Prabhu be chosen as the phone's default digital assistant.
 * Then a power-button long-press / home long-press / corner swipe opens Prabhu together with a
 * screenshot of the current screen. Nothing listens in the background.
 */
class PrabhuInteractionService : VoiceInteractionService()

class PrabhuSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = PrabhuSession(this)
}

/** Only here because the system asks an assistant to declare one. It never records anything. */
class PrabhuRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { }
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}

class PrabhuSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    private val h = Handler(Looper.getMainLooper())
    private var launched = false
    private var shotPath = ""

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        launched = false
        shotPath = ""
        h.removeCallbacksAndMessages(null)
        // The screenshot arrives a moment after onShow. If it never comes, open the app anyway.
        h.postDelayed({ launch() }, 1800)
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        if (launched) return
        if (screenshot != null) {
            try {
                val f = File(ctx.cacheDir, "screen_${System.currentTimeMillis()}.jpg")
                FileOutputStream(f).use { screenshot.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                shotPath = f.absolutePath
            } catch (e: Exception) { }
        }
        launch()
    }

    private fun launch() {
        if (launched) return
        launched = true
        h.removeCallbacksAndMessages(null)
        // Overlay mode: show Prabhu as a floating panel on top of the current app (with the screenshot).
        if (Store.bool(ctx, "overlay", true) && android.provider.Settings.canDrawOverlays(ctx)) {
            if (ScreenService.start(ctx, "OVERLAY", shotPath)) { hide(); return }
        }
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("wake", true)
            .putExtra("cmd", "")
            .putExtra("shot", shotPath)
        try { ctx.startActivity(i) } catch (e: Exception) { }
        hide()
    }
}
