plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Gemini key: comes from the GEMINI_API_KEY GitHub secret, or from the file app/gemini.key (one line).
val geminiKey: String = (System.getenv("GEMINI_API_KEY")?.trim()?.takeIf { it.isNotEmpty() }
    ?: file("gemini.key").takeIf { it.exists() }?.readText()?.trim()
    ?: "").replace("\"", "")

android {
    namespace = "com.prabhu.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.prabhu.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 16
        versionName = "2.9.2"
        buildConfigField("String", "GEMINI_KEY", "\"$geminiKey\"")
    }

    // Same signing key on every build, so a new APK installs OVER the old one (no uninstall needed).
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("prabhu.jks")
            storePassword = "prabhu123"
            keyAlias = "prabhu"
            keyPassword = "prabhu123"
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
