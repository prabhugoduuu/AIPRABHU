package com.prabhu.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

/**
 * Voice / text commands that run on the phone directly (instant, no AI call):
 * open any app, web search, YouTube, navigate, dial, alarm, timer.
 * Anything that is not a command returns null and goes to the AI as usual.
 */
object Cmd {
    class Result(val reply: String, val run: () -> Unit)

    private val openWords = setOf(
        "open", "launch", "start", "ఓపెన్", "ఓపన్", "తెరువు", "తెరవండి", "తెరవు", "తెరవ"
    )
    private val filler = setOf(
        "chey", "cheyi", "cheyyi", "cheyandi", "cheyyandi", "chei", "cheyu", "cheyyu", "cheyava",
        "please", "pls", "plz", "the", "app", "my", "na", "naku", "ni", "nu", "ippudu", "okasari",
        "చేయి", "చెయ్యి", "చేయండి", "చెయ్యండి", "చేయు", "చేయవా", "ప్లీజ్", "యాప్", "ఆప్", "నా", "నాకు",
        "ఇప్పుడు", "ఒకసారి", "ని", "ను", "లో"
    )
    // Telugu spelling -> app name(s) to look for (first one that is installed wins). Order matters.
    private val aliases = listOf(
        "గూగుల్ పే" to "google pay|gpay|wallet",
        "జీపే" to "google pay|gpay|wallet",
        "ఫోన్ పే" to "phonepe",
        "ఫోన్పే" to "phonepe",
        "వాట్సాప్" to "whatsapp", "వాట్సప్" to "whatsapp", "వాట్స్అప్" to "whatsapp",
        "యూట్యూబ్" to "youtube", "యూటూబ్" to "youtube",
        "క్రోమ్" to "chrome", "గూగుల్" to "google|chrome",
        "కెమెరా" to "camera", "కెమేరా" to "camera",
        "సెట్టింగ్స్" to "settings", "సెట్టింగ్" to "settings",
        "ఇన్స్టాగ్రామ్" to "instagram", "ఇన్స్టా" to "instagram",
        "ఫేస్బుక్" to "facebook", "టెలిగ్రామ్" to "telegram",
        "జీమెయిల్" to "gmail", "జిమెయిల్" to "gmail",
        "మ్యాప్స్" to "maps", "మ్యాప్" to "maps",
        "గ్యాలరీ" to "gallery|photos", "ఫోటోలు" to "photos|gallery",
        "కాలిక్యులేటర్" to "calculator", "క్యాలెండర్" to "calendar",
        "మెసేజెస్" to "messages", "మెసేజ్" to "messages",
        "క్లాక్" to "clock", "స్పాటిఫై" to "spotify", "నెట్ఫ్లిక్స్" to "netflix",
        "ఫోన్" to "phone"
    )

    fun handle(ctx: Context, text: String): Result? {
        val t = text.trim().replace("\u200c", "").replace("\u200d", "").lowercase()
        if (t.isEmpty() || t.length > 80) return null
        return try { openApp(ctx, t) ?: other(ctx, t) } catch (e: Exception) { null }
    }

    private fun go(ctx: Context, i: Intent) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- open an app

    private class App(val label: String, val pkg: String, val norm: String)

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun openApp(ctx: Context, t: String): Result? {
        val tokens = t.split(Regex("[\\s,.!?।]+")).filter { it.isNotEmpty() }
        if (tokens.none { it in openWords }) return null
        val q = tokens.filter { it !in openWords && it !in filler }
        if (q.isEmpty() || q.size > 3) return null
        val query = q.joinToString(" ")
        var cands = listOf(query)
        for ((k, v) in aliases) if (query.contains(k)) { cands = v.split("|"); break }

        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { val l = it.loadLabel(pm).toString(); App(l, it.activityInfo.packageName, norm(l)) }
        for (c in cands) {
            val a = best(list, norm(c)) ?: continue
            val launch = pm.getLaunchIntentForPackage(a.pkg) ?: continue
            return Result("${a.label} open chestunna") { go(ctx, launch) }
        }
        return null
    }

    private fun best(list: List<App>, q: String): App? {
        if (q.length < 2) return null
        var b: App? = null
        var bs = 0
        for (a in list) {
            val s = when {
                a.norm == q -> 3
                a.norm.startsWith(q) -> 2
                q.length >= 3 && a.norm.contains(q) -> 1
                else -> 0
            }
            if (s == 0) continue
            val cur = b
            if (cur == null || s > bs || (s == bs && a.norm.length < cur.norm.length)) { b = a; bs = s }
        }
        return b
    }

    // ---------------------------------------------------------------- other commands

    private fun other(ctx: Context, t: String): Result? {
        Regex("^(?:search|google)(?: for)?\\s+(.+)$").find(t)?.let {
            val q = it.groupValues[1]
            return Result("Searching Google for $q") {
                go(ctx, Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            }
        }
        val yt = Regex("^(?:play |search )?(.+?)\\s+(?:on|in)\\s+youtube$").find(t)
            ?: Regex("^youtube\\s+(?:search\\s+)?(.+)$").find(t)
        if (yt != null) {
            val q = yt.groupValues[1]
            return Result("YouTube lo $q") {
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            }
        }
        Regex("^(?:navigate|directions|route|take me)(?: to)?\\s+(.+)$").find(t)?.let {
            val q = it.groupValues[1]
            return Result("Navigating to $q") {
                go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(q))))
            }
        }
        Regex("^call\\s+([+\\d][\\d\\s-]{5,})$").find(t)?.let {
            val n = it.groupValues[1].replace(Regex("[\\s-]"), "")
            return Result("Dialing $n") { go(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
        }
        if (t.contains("alarm") || t.contains("అలారం")) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(t) ?: return null
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            if (h > 23 || min > 59) return null
            val pm = listOf("pm", "p.m", "evening", "night", "afternoon", "సాయంత్రం", "రాత్రి", "మధ్యాహ్నం").any { t.contains(it) }
            if (pm && h < 12) h += 12
            val label = "%d:%02d".format(h, min)
            return Result("Alarm set for $label") {
                go(ctx, Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Prabhu").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
        }
        if (t.contains("timer") || t.contains("టైమర్")) {
            val m = Regex("(\\d+)\\s*(hour|hr|గంట|min|నిమిష|sec|సెక)").find(t) ?: return null
            val n = m.groupValues[1].toInt()
            val secs = when {
                m.groupValues[2].startsWith("h") || m.groupValues[2] == "గంట" -> n * 3600
                m.groupValues[2].startsWith("m") || m.groupValues[2] == "నిమిష" -> n * 60
                else -> n
            }
            return Result("Timer set") {
                go(ctx, Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            }
        }
        return null
    }
}
