package com.prabhu.assistant

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream

/** Pulls readable text out of many file types so the AI can read them: Office, OpenDocument, zip, rtf, old .doc, plain text. */
object Extract {
    const val MAX = 80000
    private val DOT = RegexOption.DOT_MATCHES_ALL

    private val textExt = setOf(
        "txt", "md", "csv", "tsv", "json", "jsonl", "xml", "html", "htm", "xhtml", "log", "py", "kt", "java", "js", "ts",
        "tsx", "jsx", "c", "cpp", "h", "hpp", "cs", "go", "rs", "php", "rb", "sh", "sql", "yml", "yaml", "ini", "cfg",
        "conf", "toml", "properties", "gradle", "kts", "css", "scss", "swift", "dart", "r", "tex", "srt", "vtt", "svg",
        "bat", "lua", "pl", "env", "gitignore", "vcf", "ics"
    )
    val zipLike = setOf("zip", "jar", "apk", "epub", "cbz")
    val officeNew = setOf("docx", "xlsx", "pptx", "odt", "ods", "odp", "dotx", "xlsm")
    val legacy = setOf("doc", "dot", "xls", "ppt", "wps")

    fun ext(name: String) = name.substringAfterLast('.', "").lowercase()
    fun isTextName(name: String) = ext(name) in textExt

    fun looksText(b: ByteArray): Boolean {
        val n = minOf(b.size, 4000)
        if (n == 0) return false
        var bad = 0
        for (i in 0 until n) {
            val c = b[i].toInt() and 0xFF
            if (c == 0 || c < 9 || c in 14..31) bad++
        }
        return bad * 100 / n < 2
    }

    private fun unxml(s: String) = s.replace(Regex("<[^>]+>"), "")
        .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&apos;", "'")

    private fun readCapped(z: ZipInputStream, cap: Int): ByteArray {
        val o = ByteArrayOutputStream()
        val buf = ByteArray(16384)
        while (true) {
            val n = z.read(buf)
            if (n < 0) break
            if (o.size() + n > cap) { o.write(buf, 0, cap - o.size()); break }
            o.write(buf, 0, n)
        }
        return o.toByteArray()
    }

    private fun entries(bytes: ByteArray, pick: (String) -> Boolean): List<Pair<String, ByteArray>> {
        val out = ArrayList<Pair<String, ByteArray>>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && pick(e.name)) out.add(e.name to readCapped(z, 8_000_000))
                e = z.nextEntry
            }
        }
        return out
    }

    private fun num(name: String) = Regex("""(\d+)""").findAll(name).lastOrNull()?.value?.toIntOrNull() ?: 0

    // ---------------------------------------------------------------- Office / OpenDocument

    fun docx(bytes: ByteArray): String {
        val e = entries(bytes) { it == "word/document.xml" }.firstOrNull() ?: return ""
        val xml = String(e.second, Charsets.UTF_8)
        return unxml(xml.replace("</w:p>", "\n").replace("</w:tc>", " | ").replace("<w:tab/>", "\t")).trim()
    }

    fun xlsx(bytes: ByteArray): String {
        val es = entries(bytes) { it == "xl/sharedStrings.xml" || (it.startsWith("xl/worksheets/") && it.endsWith(".xml")) }
        val shared = ArrayList<String>()
        es.firstOrNull { it.first == "xl/sharedStrings.xml" }?.let {
            Regex("<si>(.*?)</si>", DOT).findAll(String(it.second, Charsets.UTF_8)).forEach { m -> shared.add(unxml(m.groupValues[1])) }
        }
        val sb = StringBuilder()
        es.filter { it.first.startsWith("xl/worksheets/") }.sortedBy { num(it.first) }.forEach { (n, b) ->
            sb.append("## ").append(n.substringAfterLast('/').removeSuffix(".xml")).append('\n')
            val xml = String(b, Charsets.UTF_8)
            Regex("<row[^>]*>(.*?)</row>", DOT).findAll(xml).forEach { r ->
                val cells = Regex("<c ([^>]*?)(?:/>|>(.*?)</c>)", DOT).findAll(r.groupValues[1]).map { c ->
                    val attrs = c.groupValues[1]
                    val inner = c.groupValues[2]
                    val t = Regex("""t="(\w+)"""").find(attrs)?.groupValues?.get(1)
                    val v = Regex("<v>(.*?)</v>", DOT).find(inner)?.groupValues?.get(1) ?: ""
                    when (t) {
                        "s" -> shared.getOrElse(v.toIntOrNull() ?: -1) { "" }
                        "inlineStr" -> unxml(inner)
                        else -> unxml(v)
                    }
                }.toList()
                if (sb.length < MAX && cells.any { it.isNotEmpty() }) sb.append(cells.joinToString("\t")).append('\n')
            }
        }
        return sb.toString().trim().take(MAX)
    }

    fun pptx(bytes: ByteArray): String {
        val es = entries(bytes) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }.sortedBy { num(it.first) }
        val sb = StringBuilder()
        es.forEach { (n, b) ->
            sb.append("## Slide ").append(num(n)).append('\n')
            sb.append(unxml(String(b, Charsets.UTF_8).replace("</a:p>", "\n")).trim()).append("\n\n")
        }
        return sb.toString().trim().take(MAX)
    }

    fun odf(bytes: ByteArray): String {
        val e = entries(bytes) { it == "content.xml" }.firstOrNull() ?: return ""
        val xml = String(e.second, Charsets.UTF_8)
            .replace("</text:p>", "\n").replace("</text:h>", "\n")
            .replace("</table:table-row>", "\n").replace("</table:table-cell>", "\t")
        return unxml(xml).trim().take(MAX)
    }

    /** Dispatches by file extension to one of the readers above. Returns null if the type is not an Office file. */
    fun office(name: String, bytes: ByteArray): String? = when (ext(name)) {
        "docx", "dotx" -> docx(bytes)
        "xlsx", "xlsm" -> xlsx(bytes)
        "pptx" -> pptx(bytes)
        "odt", "ods", "odp" -> odf(bytes)
        else -> null
    }

    // ---------------------------------------------------------------- zip

    /** A list of the files inside, plus the text of the readable ones (text, code, Office files). */
    fun zip(bytes: ByteArray): String {
        val names = ArrayList<String>()
        val body = StringBuilder()
        var read = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
            var e = z.nextEntry
            while (e != null && names.size < 2000) {
                if (!e.isDirectory) {
                    val n = e.name
                    names.add(n)
                    val x = ext(n)
                    val readable = isTextName(n) || x in officeNew || x == "rtf"
                    if (readable && body.length < MAX && read < 12_000_000) {
                        val b = readCapped(z, 2_000_000)
                        read += b.size
                        val t = when {
                            x in officeNew -> office(n, b) ?: ""
                            x == "rtf" -> rtf(String(b, Charsets.UTF_8))
                            else -> String(b, Charsets.UTF_8)
                        }
                        if (t.isNotBlank()) body.append("\n--- ").append(n).append(" ---\n").append(t.take(20000)).append('\n')
                    }
                }
                e = z.nextEntry
            }
        }
        val head = StringBuilder("Files inside (${names.size}):\n")
        names.take(300).forEach { head.append("- ").append(it).append('\n') }
        if (names.size > 300) head.append("… and ${names.size - 300} more\n")
        return (head.toString() + body).take(MAX)
    }

    // ---------------------------------------------------------------- rtf / old binary Word

    fun rtf(s: String): String {
        var t = Regex("""\\u(-?\d+)\??""").replace(s) {
            val n = it.groupValues[1].toInt().let { v -> if (v < 0) v + 65536 else v }
            String(Character.toChars(n))
        }
        t = t.replace(Regex("""\\pard?"""), "\n").replace(Regex("""\\'[0-9a-fA-F]{2}"""), "")
            .replace(Regex("""\\[a-zA-Z]+-?\d* ?"""), "").replace(Regex("[{}]"), "")
        return t.trim().take(MAX)
    }

    /** Last resort for old .doc / .xls / .ppt: pull out the runs of readable text (English and Telugu). */
    fun strings(b: ByteArray): String {
        val sb = StringBuilder()
        val cur = StringBuilder()
        var i = 0
        while (i + 1 < b.size && sb.length < MAX) {
            val lo = b[i].toInt() and 0xFF
            val hi = b[i + 1].toInt() and 0xFF
            val ok = (hi == 0 && (lo in 32..126 || lo == 9 || lo == 10 || lo == 13)) || (hi == 0x0C && lo <= 0x7F)
            if (ok) {
                cur.append(((hi shl 8) or lo).toChar())
                i += 2
            } else {
                if (cur.length >= 8) sb.append(cur).append('\n')
                cur.setLength(0)
                i += 1
            }
        }
        if (cur.length >= 8) sb.append(cur)
        // plain 8-bit text runs
        val asc = StringBuilder()
        val run = StringBuilder()
        for (x in b) {
            val c = x.toInt() and 0xFF
            if (c in 32..126) run.append(c.toChar())
            else {
                if (run.length >= 12) asc.append(run).append('\n')
                run.setLength(0)
            }
            if (asc.length > MAX) break
        }
        return (sb.toString() + "\n" + asc).trim().take(MAX)
    }
}
