package com.prabhu.assistant

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * "My own voice": speaks replies with a cloned voice from ElevenLabs.
 * Needs an ElevenLabs API key and the Voice ID of your cloned voice. Falls back to the phone voice on any error.
 */
object Voice {
    @Volatile var speaking = false
    private var player: MediaPlayer? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var gen = 0

    fun enabled(c: Context) = Store.bool(c, "cloneOn", false) &&
        Store.str(c, "el_key", "").isNotBlank() && Store.str(c, "el_voice", "").isNotBlank()

    /** Call on the main thread. */
    fun stop() {
        gen++
        speaking = false
        try { player?.stop() } catch (e: Exception) { }
        try { player?.release() } catch (e: Exception) { }
        player = null
    }

    fun speak(c: Context, raw: String, onFail: (String) -> Unit) {
        val app = c.applicationContext
        stop()
        val my = gen
        speaking = true
        val text = raw.replace(Regex("[*#`_]"), "").trim().take(1500)
        if (text.isEmpty()) { speaking = false; return }
        Thread {
            try {
                val f = fetch(app, text)
                main.post { if (my == gen) play(f, onFail) }
            } catch (e: Exception) {
                main.post { if (my == gen) { speaking = false; onFail(e.message ?: "error") } }
            }
        }.start()
    }

    private fun fetch(c: Context, text: String): File {
        val voice = Store.str(c, "el_voice", "").trim()
        val model = Store.str(c, "el_model", "").trim().ifEmpty { "eleven_v3" }
        val conn = (URL("https://api.elevenlabs.io/v1/text-to-speech/$voice?output_format=mp3_44100_64")
            .openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 60000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "audio/mpeg")
            setRequestProperty("xi-api-key", Store.str(c, "el_key", "").trim())
        }
        conn.outputStream.use { it.write(JSONObject().put("text", text).put("model_id", model).toString().toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) {
            val err = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            throw Exception("HTTP $code ${err.take(120)}")
        }
        c.cacheDir.listFiles()?.filter { it.name.startsWith("voice_") }?.forEach { it.delete() }
        val f = File(c.cacheDir, "voice_${System.nanoTime()}.mp3")
        conn.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    private fun play(f: File, onFail: (String) -> Unit) {
        try {
            val p = MediaPlayer()
            p.setDataSource(f.absolutePath)
            p.setOnCompletionListener { speaking = false; try { it.release() } catch (e: Exception) { }; if (player === it) player = null }
            p.setOnErrorListener { _, _, _ -> speaking = false; onFail("playback error"); true }
            p.prepare()
            p.start()
            player = p
        } catch (e: Exception) {
            speaking = false
            onFail(e.message ?: "playback error")
        }
    }

    /** Uploads a voice sample to ElevenLabs and returns the new Voice ID. Call from a background thread. */
    fun clone(c: Context, bytes: ByteArray, fileName: String, mime: String): String {
        val boundary = "----prabhu" + System.nanoTime()
        val conn = (URL("https://api.elevenlabs.io/v1/voices/add").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 180000
            doOutput = true
            setChunkedStreamingMode(0)
            setRequestProperty("xi-api-key", Store.str(c, "el_key", "").trim())
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        DataOutputStream(conn.outputStream).use { o ->
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"name\"\r\n\r\nMy voice (Prabhu)\r\n")
            o.writeBytes("--$boundary\r\nContent-Disposition: form-data; name=\"files\"; filename=\"$fileName\"\r\n")
            o.writeBytes("Content-Type: $mime\r\n\r\n")
            o.write(bytes)
            o.writeBytes("\r\n--$boundary--\r\n")
        }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val low = txt.lowercase()
            if (code == 401 || low.contains("invalid_api_key")) throw Exception("API key is wrong")
            if (code == 402 || code == 403 || low.contains("instant_voice_cloning") || low.contains("subscription") || low.contains("upgrade"))
                throw Exception("Your ElevenLabs plan doesn't allow voice cloning (needs a paid plan)")
            throw Exception("HTTP $code ${txt.take(120)}")
        }
        val id = JSONObject(txt).optString("voice_id")
        if (id.isBlank()) throw Exception("No voice ID came back")
        return id
    }
}
