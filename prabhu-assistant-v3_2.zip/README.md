# Prabhu - AI assistant for Android

Chat app with side menu, chat history, photo/PDF/Word/text attach, voice input.
Add any number of AI APIs (Claude, Gemini, OpenAI, Groq, OpenRouter, custom).

v2.9.2
- Prabhu knows you are its creator and master (Settings > Memory > your name/title). Type "/improve <what to change>" in chat and it edits itself.
- API key and GitHub token fields are hidden (••••).

v3.2
- Backup & restore (Settings): API keys, models, settings, memory (+ optional chats) saved to Downloads/Prabhu, optional password encryption, restore offer on a fresh install.
- Install errors are explained clearly (version too low, different signing key, blocked).

v3.1
- YouTube manager: connect your channel (Google device login), weekly plan, scheduled uploads (YouTube publishAt), AI title/description/tags, best times from your channel, background resumable uploads of the original file.

v2.9
- Update from a zip, an APK file or a link (Self-improve screen). Zip: pushed to your GitHub repo, built, installed. APK: installed directly. Version is checked first.
- Coder mode: for code requests Prabhu plans, writes, then reviews and fixes its own code before answering (switch in Settings).
- Strict coding rules; Prabhu saves lessons from your corrections in Memory.
- "Paste build error" button, and a "What's new" note after each update.

v2.8
- Bubble mode: floating P bubble WITHOUT screen capture (Settings > Bubble & overlay). Tap it to chat on top of any app.
- Overlay: power-button / assistant gesture now opens a floating panel over your app (switch in Settings).
- Code: every code block has Save + Preview (HTML/SVG run live, with a Float / picture-in-picture button). Works in the overlay panel too.
- Super max: Max mode (deepest thinking, live web search, 64k answers; auto steps down if a model can't) + "Upgrade my models to the strongest" (asks your key which models it can use).
- Themes: Ocean, Aurora, Emerald, Sunset, Midnight, Light. Colourful dashboard tiles.
- Memory: Prabhu remembers facts about you (Settings > Memory, or say "remember ...").
- Self-improve: Prabhu edits its own code on GitHub, builds, fixes build errors, installs the update, with Undo. Needs a private repo + GitHub token.

v2.7
- Code files: every code block in an answer gets a Save button (Downloads/Prabhu), plus Save all as zip. Longer answers for Claude (16000 tokens).

v2.6
- Settings: record your voice (or upload a file) inside the app; Prabhu clones it via ElevenLabs and uses it automatically.

v2.5
- Attach ANY file: PDF, Word, Excel, PowerPoint, zip, text/code, audio/video, old .doc, rtf, OpenDocument. Pick several at once.
- Share to Prabhu from any app (WhatsApp, Files, Gmail...).

v2.4
- Voice commands: "WhatsApp open chey", "open YouTube", "search ...", "navigate to ...", "alarm 7 am", "timer 5 minutes" run instantly on the phone.
- AI voice: speak replies in your own cloned voice (ElevenLabs key + Voice ID in Settings).

v2.3
- Streaming: answers appear word by word, in chat and in the screen bubble.
- Faster: Gemini thinking minimal, smaller screenshots, shorter history.
- Fixed signing key (prabhu.jks): new APKs install OVER the old one, no uninstall needed.
- Gemini key is built in (app/gemini.key or GitHub secret GEMINI_API_KEY). Keep the repo PRIVATE.

v2.2
- Switch model inside the same chat when one API hits its limit (error card, last answer, model chip).
- Screen assist: floating P bubble, tap on any screen and Prabhu answers about it right there.
- Default digital assistant: power-button long-press opens Prabhu with a screenshot. No background listening.
- "Hey Prabhu" always-listening is now optional and off by default.
