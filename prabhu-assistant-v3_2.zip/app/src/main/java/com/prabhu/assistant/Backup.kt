package com.prabhu.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Backup and restore: API keys, models, settings, memory, GitHub/YouTube logins and (optionally) chats.
 * The file goes to Downloads/Prabhu and survives uninstalling the app. An optional password encrypts it (AES-256).
 */
object Backup {
    private val skip = setOf("yt_access", "yt_exp", "dev_pending", "install_result", "seen_ver", "dev_notes", "bk_asked")

    private fun prefs(c: Context) = c.getSharedPreferences("prabhu", Context.MODE_PRIVATE)

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)

    private fun snapshot(c: Context, withChats: Boolean): JSONObject {
        val items = JSONObject()
        for ((k, v) in prefs(c).all) {
            if (k in skip || v == null) continue
            val t = when (v) {
                is Boolean -> "b"
                is Int -> "i"
                is Long -> "l"
                is Float -> "f"
                else -> "s"
            }
            items.put(k, JSONObject().put("t", t).put("v", v.toString()))
        }
        val o = JSONObject().put("app", "prabhu").put("time", System.currentTimeMillis()).put("prefs", items)
        if (withChats) {
            val f = File(c.filesDir, "chats.json")
            if (f.exists()) o.put("chats", f.readText())
        }
        return o
    }

    private fun key(pass: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pass.toCharArray(), salt, 120000, 256)).encoded, "AES")
    }

    fun export(c: Context, withChats: Boolean, pass: String): ByteArray {
        val snap = snapshot(c, withChats)
        val root = JSONObject().put("v", 1)
        if (pass.isEmpty()) {
            root.put("enc", false).put("data", snap)
        } else {
            val salt = ByteArray(16)
            val iv = ByteArray(12)
            SecureRandom().nextBytes(salt)
            SecureRandom().nextBytes(iv)
            val ci = Cipher.getInstance("AES/GCM/NoPadding")
            ci.init(Cipher.ENCRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
            val enc = ci.doFinal(snap.toString().toByteArray(Charsets.UTF_8))
            root.put("enc", true).put("salt", b64(salt)).put("iv", b64(iv)).put("data", b64(enc))
        }
        return root.toString().toByteArray(Charsets.UTF_8)
    }

    /** Saves to Downloads/Prabhu and returns where, or null if it failed. */
    fun save(c: Context, withChats: Boolean, pass: String): String? {
        val name = "prabhu-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".json"
        return CodeFiles.save(c, name, export(c, withChats, pass), "application/json")
    }

    fun isEncrypted(bytes: ByteArray): Boolean = try {
        JSONObject(String(bytes, Charsets.UTF_8)).optBoolean("enc", false)
    } catch (e: Exception) { false }

    /** Puts the saved settings (and chats, if the file has them) back. Returns a short summary. */
    fun restore(c: Context, bytes: ByteArray, pass: String): String {
        val root = try { JSONObject(String(bytes, Charsets.UTF_8)) } catch (e: Exception) { throw Exception("This is not a Prabhu backup file.") }
        val snap: JSONObject = if (root.optBoolean("enc", false)) {
            try {
                val salt = Base64.decode(root.getString("salt"), Base64.NO_WRAP)
                val iv = Base64.decode(root.getString("iv"), Base64.NO_WRAP)
                val data = Base64.decode(root.getString("data"), Base64.NO_WRAP)
                val ci = Cipher.getInstance("AES/GCM/NoPadding")
                ci.init(Cipher.DECRYPT_MODE, key(pass, salt), GCMParameterSpec(128, iv))
                JSONObject(String(ci.doFinal(data), Charsets.UTF_8))
            } catch (e: Exception) {
                throw Exception("Wrong password, or the file is damaged.")
            }
        } else {
            root.optJSONObject("data") ?: throw Exception("This is not a Prabhu backup file.")
        }
        if (snap.optString("app") != "prabhu") throw Exception("This is not a Prabhu backup file.")
        val items = snap.optJSONObject("prefs") ?: JSONObject()
        val ed = prefs(c).edit()
        var n = 0
        for (k in items.keys()) {
            val e = items.getJSONObject(k)
            val v = e.optString("v")
            when (e.optString("t")) {
                "b" -> ed.putBoolean(k, v == "true")
                "i" -> ed.putInt(k, v.toIntOrNull() ?: 0)
                "l" -> ed.putLong(k, v.toLongOrNull() ?: 0L)
                "f" -> ed.putFloat(k, v.toFloatOrNull() ?: 0f)
                else -> ed.putString(k, v)
            }
            n++
        }
        ed.commit()
        var chats = false
        val ch = snap.optString("chats", "")
        if (ch.isNotEmpty()) {
            File(c.filesDir, "chats.json").writeText(ch)
            chats = true
        }
        return "✓ Restored $n settings (API keys, models, memory, logins)" + (if (chats) " and your chats." else ". Chats were not in this backup.")
    }
}
