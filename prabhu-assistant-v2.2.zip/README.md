# Prabhu - AI assistant for Android

Chat app with side menu, chat history, photo/PDF/Word/text attach, voice input.
Add any number of AI APIs (Claude, Gemini, OpenAI, Groq, OpenRouter, custom).

v2.2
- Switch model inside the same chat when one API hits its limit (error card, last answer, model chip).
- Screen assist: floating P bubble, tap on any screen and Prabhu answers about it right there.
- Default digital assistant: power-button long-press opens Prabhu with a screenshot. No background listening.
- "Hey Prabhu" always-listening is now optional and off by default.
