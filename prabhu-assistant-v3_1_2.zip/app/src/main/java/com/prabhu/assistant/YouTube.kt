package com.prabhu.assistant

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * YouTube for Prabhu: login (Google "device" sign-in), upload your ORIGINAL file (no re-compression, so full quality),
 * schedule with YouTube's own publishAt (works even when the phone is off), a weekly plan that hands out the next free slot,
 * AI-written title/description/tags, and best-time suggestions from your own channel's numbers.
 */
object YouTube {
    const val SCOPE = "https://www.googleapis.com/auth/youtube"

    class Item(
        val id: String,
        var uri: String,
        var name: String,
        var size: Long,
        var title: String,
        var desc: String,
        var tags: String,
        var cat: String,
        var publishAt: Long,      // 0 = no schedule
        var privacy: String,      // "public" or "private" (used when publishAt == 0)
        var thumb: String = "",
        var status: String = "ready",   // ready, uploading, scheduled, published, failed
        var videoId: String = "",
        var error: String = "",
        var progress: Int = 0,
        var session: String = ""
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("id", id).put("uri", uri).put("name", name).put("size", size).put("title", title)
            .put("desc", desc).put("tags", tags).put("cat", cat).put("publishAt", publishAt)
            .put("privacy", privacy).put("thumb", thumb).put("status", status).put("videoId", videoId)
            .put("error", error).put("progress", progress).put("session", session)
    }

    private fun fromJson(o: JSONObject) = Item(
        o.optString("id"), o.optString("uri"), o.optString("name"), o.optLong("size"), o.optString("title"),
        o.optString("desc"), o.optString("tags"), o.optString("cat", "22"), o.optLong("publishAt"),
        o.optString("privacy", "private"), o.optString("thumb"), o.optString("status", "ready"),
        o.optString("videoId"), o.optString("error"), o.optInt("progress"), o.optString("session")
    )

    // ---------------------------------------------------------------- queue storage

    private val lock = Any()

    fun items(c: Context): List<Item> = synchronized(lock) { load(c) }

    private fun load(c: Context): MutableList<Item> {
        val out = ArrayList<Item>()
        try {
            val a = JSONArray(Store.str(c, "yt_queue", "[]"))
            for (i in 0 until a.length()) out.add(fromJson(a.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    private fun save(c: Context, l: List<Item>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        Store.setStr(c, "yt_queue", a.toString())
    }

    fun mutate(c: Context, f: (MutableList<Item>) -> Unit) = synchronized(lock) {
        val l = load(c)
        f(l)
        save(c, l)
    }

    fun patch(c: Context, id: String, f: (Item) -> Unit) = mutate(c) { l -> l.firstOrNull { it.id == id }?.let(f) }

    // ---------------------------------------------------------------- HTTP

    private class Resp(val code: Int, val text: String, val location: String?, val range: String?)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun form(vararg p: Pair<String, String>) = p.joinToString("&") { enc(it.first) + "=" + enc(it.second) }

    private fun req(method: String, url: String, headers: Map<String, String> = emptyMap(), body: ByteArray? = null, timeout: Int = 40000): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = timeout
        c.instanceFollowRedirects = false
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        val text = try {
            (if (code in 200..399) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) { "" }
        return Resp(code, text, c.getHeaderField("Location"), c.getHeaderField("Range"))
    }

    private fun err(r: Resp): String {
        return try {
            val o = JSONObject(r.text)
            val e = o.optJSONObject("error")
            val m = e?.optString("message").orEmpty().ifEmpty { o.optString("error_description").ifEmpty { o.optString("error") } }
            "YouTube ${r.code}: ${m.ifEmpty { r.text.take(120) }}"
        } catch (e: Exception) { "YouTube ${r.code}: ${r.text.take(120)}" }
    }

    private val formHdr = mapOf("Content-Type" to "application/x-www-form-urlencoded")

    // ---------------------------------------------------------------- login (device flow)

    fun connected(c: Context) = Store.str(c, "yt_refresh", "").isNotEmpty()

    fun disconnect(c: Context) {
        Store.setStr(c, "yt_refresh", ""); Store.setStr(c, "yt_access", ""); Store.setStr(c, "yt_exp", "0")
        Store.setStr(c, "yt_channel", "")
    }

    class DeviceCode(val device: String, val user: String, val url: String, val interval: Int, val expires: Int)

    fun deviceStart(c: Context): DeviceCode {
        val cid = Store.str(c, "yt_cid", "").trim()
        if (cid.isEmpty()) throw Exception("Enter the Client ID and Client secret first.")
        val r = req("POST", "https://oauth2.googleapis.com/device/code", formHdr,
            form("client_id" to cid, "scope" to SCOPE).toByteArray())
        if (r.code !in 200..299) throw Exception(err(r))
        val o = JSONObject(r.text)
        return DeviceCode(
            o.getString("device_code"), o.getString("user_code"),
            o.optString("verification_url", "https://www.google.com/device"), o.optInt("interval", 5), o.optInt("expires_in", 1800)
        )
    }

    private fun saveTokens(c: Context, o: JSONObject) {
        val acc = o.optString("access_token")
        if (acc.isNotEmpty()) {
            Store.setStr(c, "yt_access", acc)
            Store.setStr(c, "yt_exp", (System.currentTimeMillis() + o.optLong("expires_in", 3000) * 1000).toString())
        }
        val rt = o.optString("refresh_token")
        if (rt.isNotEmpty()) Store.setStr(c, "yt_refresh", rt)
    }

    /** Waits until the person has approved the code on google.com/device. Returns true when connected. */
    fun devicePoll(c: Context, d: DeviceCode, cancelled: () -> Boolean): Boolean {
        val cid = Store.str(c, "yt_cid", "").trim()
        val secret = Store.str(c, "yt_secret", "").trim()
        var wait = d.interval
        val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < d.expires * 1000L) {
            Thread.sleep(wait * 1000L)
            if (cancelled()) return false
            val r = req("POST", "https://oauth2.googleapis.com/token", formHdr, form(
                "client_id" to cid, "client_secret" to secret, "device_code" to d.device,
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code"
            ).toByteArray())
            if (r.code in 200..299) { saveTokens(c, JSONObject(r.text)); return true }
            val e = try { JSONObject(r.text).optString("error") } catch (x: Exception) { "" }
            when (e) {
                "authorization_pending" -> { }
                "slow_down" -> wait += 5
                else -> throw Exception(err(r))
            }
        }
        throw Exception("The code expired. Tap Connect again.")
    }

    @Synchronized
    fun token(c: Context): String {
        val exp = Store.str(c, "yt_exp", "0").toLongOrNull() ?: 0L
        val acc = Store.str(c, "yt_access", "")
        if (acc.isNotEmpty() && exp > System.currentTimeMillis() + 60000) return acc
        val rt = Store.str(c, "yt_refresh", "")
        if (rt.isEmpty()) throw Exception("YouTube is not connected.")
        val r = req("POST", "https://oauth2.googleapis.com/token", formHdr, form(
            "client_id" to Store.str(c, "yt_cid", "").trim(), "client_secret" to Store.str(c, "yt_secret", "").trim(),
            "refresh_token" to rt, "grant_type" to "refresh_token"
        ).toByteArray())
        if (r.code !in 200..299) {
            if (r.text.contains("invalid_grant")) {
                Store.setStr(c, "yt_refresh", "")
                throw Exception("YouTube login expired. Connect again. (Tip: set your Google OAuth app to “In production” so the login lasts.)")
            }
            throw Exception(err(r))
        }
        saveTokens(c, JSONObject(r.text))
        return Store.str(c, "yt_access", "")
    }

    private fun getJson(c: Context, url: String): JSONObject {
        val r = req("GET", url, mapOf("Authorization" to "Bearer " + token(c)))
        if (r.code !in 200..299) throw Exception(err(r))
        return JSONObject(r.text)
    }

    fun channelName(c: Context): String {
        val o = getJson(c, "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true")
        val a = o.optJSONArray("items")
        if (a == null || a.length() == 0) throw Exception("This Google account has no YouTube channel yet.")
        return a.getJSONObject(0).getJSONObject("snippet").optString("title", "your channel")
    }

    // ---------------------------------------------------------------- upload

    private fun iso(ms: Long): String {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.000'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ms))
    }

    private fun skipFully(ins: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val s = ins.skip(left)
            if (s <= 0) {
                if (ins.read() < 0) break
                left -= 1
            } else left -= s
        }
    }

    /** Sends the file. Asks YouTube how much it already has before every try, so a dropped connection just continues. */
    private fun transfer(c: Context, session: String, uri: Uri, size: Long, progress: (Int) -> Unit): String {
        var last: Exception? = null
        for (attempt in 0..7) {
            try {
                val q = req("PUT", session, mapOf("Content-Range" to "bytes */$size"), ByteArray(0))
                if (q.code == 200 || q.code == 201) return q.text
                if (q.code == 404 || q.code == 410) throw IllegalStateException("session-gone")
                if (q.code != 308) throw Exception("Resume check failed (${q.code}).")
                val offset = q.range?.substringAfter("-")?.trim()?.toLongOrNull()?.plus(1) ?: 0L
                val conn = URL(session).openConnection() as HttpURLConnection
                conn.requestMethod = "PUT"
                conn.doOutput = true
                conn.instanceFollowRedirects = false
                conn.connectTimeout = 20000
                conn.readTimeout = 180000
                conn.setFixedLengthStreamingMode(size - offset)
                conn.setRequestProperty("Content-Type", "video/*")
                conn.setRequestProperty("Content-Range", "bytes $offset-${size - 1}/$size")
                val ins = c.contentResolver.openInputStream(uri) ?: throw Exception("Can't read the video file.")
                ins.use { s ->
                    skipFully(s, offset)
                    conn.outputStream.use { out ->
                        val buf = ByteArray(256 * 1024)
                        var sent = offset
                        var lastPct = -1
                        while (true) {
                            val n = s.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            sent += n
                            val p = (sent * 100 / size).toInt()
                            if (p != lastPct) { lastPct = p; progress(p) }
                        }
                    }
                }
                val code = conn.responseCode
                val text = try {
                    (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) { "" }
                if (code == 200 || code == 201) return text
                if (code == 308) continue
                throw Exception("Upload failed ($code): ${text.take(150)}")
            } catch (e: java.io.IOException) {
                last = e
                Thread.sleep(4000L * (attempt + 1))
            }
        }
        throw Exception("Network problem during upload (${last?.message}). Tap Upload again to continue where it stopped.")
    }

    private fun uploadItem(c: Context, item: Item, progress: (Int) -> Unit): String {
        val uri = Uri.parse(item.uri)
        var size = item.size
        if (size <= 0) size = c.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
        if (size <= 0) throw Exception("Can't read the video file. Add it again.")

        fun newSession(): String {
            val tok = token(c)
            val tags = JSONArray()
            item.tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { tags.put(it) }
            val sn = JSONObject().put("title", item.title.take(100)).put("description", item.desc.take(5000)).put("categoryId", item.cat)
            if (tags.length() > 0) sn.put("tags", tags)
            val st = JSONObject().put("selfDeclaredMadeForKids", false)
            if (item.publishAt > System.currentTimeMillis() + 5 * 60_000L) {
                st.put("privacyStatus", "private").put("publishAt", iso(item.publishAt))
            } else {
                st.put("privacyStatus", if (item.privacy == "private") "private" else "public")
            }
            val meta = JSONObject().put("snippet", sn).put("status", st)
            val r = req(
                "POST", "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
                mapOf(
                    "Authorization" to "Bearer $tok", "Content-Type" to "application/json; charset=UTF-8",
                    "X-Upload-Content-Type" to "video/*", "X-Upload-Content-Length" to size.toString()
                ),
                meta.toString().toByteArray()
            )
            if (r.code !in 200..299) throw Exception(err(r))
            val s = r.location ?: throw Exception("YouTube did not give an upload address.")
            patch(c, item.id) { it.session = s }
            return s
        }

        var session = item.session.ifEmpty { newSession() }
        val body = try {
            transfer(c, session, uri, size, progress)
        } catch (e: IllegalStateException) {
            session = newSession()
            transfer(c, session, uri, size, progress)
        }
        val vid = JSONObject(body).optString("id")
        if (vid.isEmpty()) throw Exception("Upload finished but YouTube returned no video id.")
        if (item.thumb.isNotEmpty()) {
            try { setThumb(c, vid, item.thumb) } catch (e: Exception) { }   // needs a phone-verified channel; not fatal
        }
        return vid
    }

    private fun setThumb(c: Context, videoId: String, uriStr: String) {
        val uri = Uri.parse(uriStr)
        val bytes = c.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
        if (bytes.size > 2_000_000) return
        val mime = c.contentResolver.getType(uri) ?: "image/jpeg"
        req(
            "POST", "https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=$videoId&uploadType=media",
            mapOf("Authorization" to "Bearer " + token(c), "Content-Type" to mime), bytes, 60000
        )
    }

    /** Uploads every "ready" video one by one. Runs inside YtService. */
    fun processQueue(c: Context, note: (String) -> Unit) {
        while (true) {
            val item = items(c).firstOrNull { it.status == "ready" || it.status == "uploading" } ?: break
            patch(c, item.id) { it.status = "uploading"; it.error = "" }
            note("Uploading: " + item.title.take(40))
            var lastSaved = -10
            try {
                val vid = uploadItem(c, item) { p ->
                    if (p - lastSaved >= 2 || p == 100) {
                        lastSaved = p
                        patch(c, item.id) { it.progress = p }
                        note(item.title.take(30) + "  " + p + "%")
                    }
                }
                patch(c, item.id) {
                    it.videoId = vid
                    it.progress = 100
                    it.session = ""
                    it.status = if (it.publishAt > System.currentTimeMillis()) "scheduled" else "published"
                }
                note("Done: " + item.title.take(40))
            } catch (e: Exception) {
                val m = e.message ?: "error"
                patch(c, item.id) { it.status = "failed"; it.error = m }
                if (m.contains("not connected") || m.contains("login expired")) break
            }
        }
    }

    // ---------------------------------------------------------------- weekly plan

    class Slot(val dow: Int, val h: Int, val m: Int)

    private val dayNames = arrayOf("", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")

    fun parsePlan(s: String): List<Slot> {
        val map = mapOf("sun" to 1, "mon" to 2, "tue" to 3, "wed" to 4, "thu" to 5, "fri" to 6, "sat" to 7)
        val out = ArrayList<Slot>()
        Regex("(?i)(sun|mon|tue|wed|thu|fri|sat)[a-z]*\\s*(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").findAll(s).forEach { m ->
            var h = m.groupValues[2].toInt()
            val mi = m.groupValues[3].toIntOrNull() ?: 0
            val ap = m.groupValues[4].lowercase()
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            if (h in 0..23 && mi in 0..59) out.add(Slot(map[m.groupValues[1].lowercase()] ?: 1, h, mi))
        }
        return out
    }

    /** The next free time in the weekly plan (skips times that already have a video within 30 minutes). */
    fun nextSlot(c: Context): Long? {
        val slots = parsePlan(Store.str(c, "yt_plan", ""))
        if (slots.isEmpty()) return null
        val taken = items(c).filter { it.publishAt > 0 && it.status != "failed" }.map { it.publishAt }
        val now = System.currentTimeMillis()
        val cand = ArrayList<Long>()
        for (d in 0..35) {
            val base = Calendar.getInstance()
            base.add(Calendar.DAY_OF_YEAR, d)
            for (s in slots) {
                if (base.get(Calendar.DAY_OF_WEEK) != s.dow) continue
                val t = base.clone() as Calendar
                t.set(Calendar.HOUR_OF_DAY, s.h)
                t.set(Calendar.MINUTE, s.m)
                t.set(Calendar.SECOND, 0)
                t.set(Calendar.MILLISECOND, 0)
                cand.add(t.timeInMillis)
            }
        }
        return cand.sorted().firstOrNull { t -> t > now + 20 * 60_000L && taken.none { x -> Math.abs(x - t) < 30 * 60_000L } }
    }

    // ---------------------------------------------------------------- AI title / description / tags

    class Meta(val title: String, val desc: String, val tags: String)

    fun aiMeta(c: Context, notes: String, short: Boolean): Meta {
        val sys = "You are a top YouTube growth strategist. You write titles, descriptions and tags that get clicks AND keep viewers, " +
            "without lying or fake clickbait. Reply with ONLY one JSON object, no markdown."
        val prompt = "Video notes from the creator:\n$notes\n\n" +
            (if (short) "This is a YouTube Short (vertical, short). Keep the title very punchy and add #Shorts to the description.\n" else "") +
            "Write in the same language as the notes (Telugu, English or a mix, whichever the creator used).\n" +
            "Rules: title max 70 characters, strongest keyword and hook in the first 40 characters, curiosity or clear benefit. " +
            "Description: first 2 lines = hook + main keywords (they show before 'more'), then 3 to 5 short lines of value, " +
            "a call to subscribe/comment, and 3 relevant hashtags at the end. Tags: 10 to 15 specific search phrases.\n" +
            "JSON format: {\"title\":\"...\",\"description\":\"...\",\"tags\":[\"...\"]}"
        val r = Ai.ask(Store.models(c), Store.active(c), Store.bool(c, "fallback", true), listOf(Msg("user", prompt)), false, "", null, Store.bool(c, "max", true), sys)
        if (!r.ok) throw Exception(r.text)
        val t = r.text
        val a = t.indexOf('{')
        val b = t.lastIndexOf('}')
        if (a < 0 || b <= a) throw Exception("The AI did not return a usable answer. Try again.")
        val o = JSONObject(t.substring(a, b + 1))
        val tags = ArrayList<String>()
        val ta = o.optJSONArray("tags")
        if (ta != null) for (i in 0 until ta.length()) tags.add(ta.optString(i))
        return Meta(o.optString("title"), o.optString("description"), tags.joinToString(", "))
    }

    // ---------------------------------------------------------------- best times from your channel

    /** Returns (plan text like "Thu 19:00, Sat 19:00", explanation). */
    fun analyze(c: Context): Pair<String, String> {
        val ch = getJson(c, "https://www.googleapis.com/youtube/v3/channels?part=contentDetails&mine=true")
        val up = ch.getJSONArray("items").getJSONObject(0).getJSONObject("contentDetails")
            .getJSONObject("relatedPlaylists").getString("uploads")
        val pl = getJson(c, "https://www.googleapis.com/youtube/v3/playlistItems?part=contentDetails&maxResults=50&playlistId=$up")
        val ids = ArrayList<String>()
        val arr = pl.optJSONArray("items") ?: JSONArray()
        for (i in 0 until arr.length()) ids.add(arr.getJSONObject(i).getJSONObject("contentDetails").getString("videoId"))
        val fallback = "Thu 19:00, Sat 19:00, Sun 18:00"
        if (ids.size < 6) {
            return fallback to "Your channel has only ${ids.size} videos, so there is not enough data yet. This is a common good starting plan " +
                "(evenings and weekends). Prabhu will be able to learn from your numbers after about 6 uploads."
        }
        val vs = getJson(c, "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&id=" + ids.joinToString(","))
        val items = vs.optJSONArray("items") ?: JSONArray()
        val byDay = HashMap<Int, ArrayList<Double>>()
        val byBucket = HashMap<Int, ArrayList<Double>>()
        val now = System.currentTimeMillis()
        var used = 0
        for (i in 0 until items.length()) {
            val o = items.getJSONObject(i)
            val pub = try { java.time.Instant.parse(o.getJSONObject("snippet").getString("publishedAt")).toEpochMilli() } catch (e: Exception) { continue }
            val ageDays = (now - pub) / 86_400_000.0
            if (ageDays < 2) continue
            val views = o.optJSONObject("statistics")?.optString("viewCount")?.toDoubleOrNull() ?: 0.0
            val score = views / Math.max(ageDays, 3.0)
            val cal = Calendar.getInstance()
            cal.timeInMillis = pub
            byDay.getOrPut(cal.get(Calendar.DAY_OF_WEEK)) { ArrayList() }.add(score)
            byBucket.getOrPut(cal.get(Calendar.HOUR_OF_DAY) / 3) { ArrayList() }.add(score)
            used++
        }
        if (used < 5) return fallback to "Not enough older videos to learn from yet. Starting plan suggested."
        val bestDays = byDay.entries.sortedByDescending { e -> e.value.average() }.take(3).map { it.key }
        val bestBucket = byBucket.entries.maxByOrNull { e -> e.value.average() }?.key ?: 6
        val hour = Math.min(23, bestBucket * 3 + 1)
        val plan = bestDays.joinToString(", ") { d -> dayNames[d] + " " + String.format(Locale.US, "%02d:00", hour) }
        return plan to "Based on $used of your videos (views per day since upload), your best days are " +
            bestDays.joinToString(", ") { dayNames[it] } + " and around %02d:00. This is an estimate, not a guarantee. Keep posting regularly and Prabhu will refine it.".format(hour)
    }
}
