package com.prabhu.assistant

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private const val YM = ViewGroup.LayoutParams.MATCH_PARENT
private const val YW = ViewGroup.LayoutParams.WRAP_CONTENT

/** Prabhu's YouTube manager: connect your channel, plan your week, upload with AI-written titles. */
class YouTubeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var connBox: LinearLayout
    private lateinit var queueBox: LinearLayout
    private lateinit var planField: EditText
    @Volatile private var cancelLogin = false

    private var pendingThumb = ""
    private var thumbLabel: TextView? = null

    private val dlgTheme: Int
        get() = if (Theme.isLight()) android.R.style.Theme_Material_Light_Dialog_Alert else android.R.style.Theme_Material_Dialog_Alert

    private val ticker = object : Runnable {
        override fun run() {
            renderQueue()
            ui.postDelayed(this, 2500)
        }
    }

    // ---------------------------------------------------------------- small UI helpers

    private fun tv(s: CharSequence, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun btn(label: String, filled: Boolean, f: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setTextColor(if (filled) Color.WHITE else cText)
        background = if (filled) accentGrad(false, dp(12).toFloat()) else rounded(cSurface, cLine, 12)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnClickListener { f() }
    }

    private fun small(label: String, color: Int, f: () -> Unit) = TextView(this).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { f() }
    }

    private fun lpm(top: Int, bottom: Int = 0) =
        LinearLayout.LayoutParams(YM, YW).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun section(t: String): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(View(this).apply { background = accentGrad(false, dp(2).toFloat()) }, LinearLayout.LayoutParams(dp(4), dp(16)))
        row.addView(tv(t.uppercase(), 12f, cAccent, true).apply { setPadding(dp(8), 0, 0, 0) })
        return row
    }

    private fun field(hint: String, value: String, multi: Boolean, secret: Boolean = false, onChange: ((String) -> Unit)? = null): EditText =
        EditText(this).apply {
            this.hint = hint
            setText(value)
            setHintTextColor(cMute)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            inputType = if (multi) {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            } else {
                InputType.TYPE_CLASS_TEXT or (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
            }
            if (multi) { minLines = 3; gravity = Gravity.TOP } else setSingleLine()
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(cSurface, cLine, 12)
            if (onChange != null) addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { onChange(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()).format(Date(ms))

    // ---------------------------------------------------------------- screen

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Theme.load(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        if (Theme.isLight()) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cBg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        bar.addView(tv("←", 22f, cText).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { finish() }
        })
        bar.addView(tv("▶  YouTube", 18f, cText, true))
        root.addView(bar, LinearLayout.LayoutParams(YM, YW))
        root.addView(View(this).apply { background = accentGrad() }, LinearLayout.LayoutParams(YM, dp(2)))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(40))
        }
        body.addView(section("Your channel"), lpm(4, 8))
        connBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(connBox, lpm(0, 0))

        body.addView(section("Weekly plan"), lpm(24, 8))
        body.addView(tv(
            "When should videos go live? Example: Mon 18:00, Thu 18:00, Sat 7pm. Each new video gets the next free time automatically.",
            13f, cMute), lpm(0, 8))
        planField = field("Mon 18:00, Thu 18:00, Sat 19:00", Store.str(this, "yt_plan", ""), false) { Store.setStr(this, "yt_plan", it) }
        body.addView(planField, lpm(0, 8))
        body.addView(btn("📊  Suggest best times from my channel", false) { suggestTimes() }, lpm(0, 0))

        body.addView(section("Videos"), lpm(24, 8))
        body.addView(btn("➕  Add a video", true) { pickVideo() }, lpm(0, 8))
        body.addView(btn("⬆  Upload the queue now", false) { uploadNow() }, lpm(0, 8))
        queueBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(queueBox, lpm(4, 0))
        body.addView(tv(
            "Quality: your original file is uploaded as it is, nothing is re-compressed. YouTube makes the HD/4K versions itself. " +
                "Scheduled videos go live on YouTube's side, so your phone can be off at that time.", 12f, cMute), lpm(16, 0))

        root.addView(ScrollView(this).apply { addView(body) }, LinearLayout.LayoutParams(YM, 0, 1f))
        setContentView(root)
        renderConn()
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    // ---------------------------------------------------------------- connection

    private fun renderConn() {
        connBox.removeAllViews()
        if (YouTube.connected(this)) {
            val name = Store.str(this, "yt_channel", "")
            connBox.addView(tv("✓  YouTube connected" + (if (name.isNotEmpty()) "  ·  $name" else ""), 15f, cText, true), lpm(0, 8))
            connBox.addView(btn("Disconnect", false) { YouTube.disconnect(this); renderConn() }, lpm(0, 0))
            if (name.isEmpty()) {
                Thread {
                    try {
                        val n = YouTube.channelName(this)
                        Store.setStr(this, "yt_channel", n)
                        runOnUiThread { renderConn() }
                    } catch (e: Exception) { }
                }.start()
            }
            return
        }
        connBox.addView(tv(
            "One-time setup (10 minutes, free):\n" +
                "1. On a browser open console.cloud.google.com and create a project.\n" +
                "2. APIs & Services → Library → enable “YouTube Data API v3”.\n" +
                "3. OAuth consent screen: add yourself as a test user, then press “Publish app” (In production) so login does not expire.\n" +
                "4. Credentials → Create credentials → OAuth client ID → type “TVs and Limited Input devices”.\n" +
                "5. Paste the Client ID and Client secret here.", 12f, cMute), lpm(0, 8))
        connBox.addView(field("Client ID", Store.str(this, "yt_cid", ""), false) { Store.setStr(this, "yt_cid", it.trim()) }, lpm(0, 8))
        connBox.addView(field("Client secret", Store.str(this, "yt_secret", ""), false, true) { Store.setStr(this, "yt_secret", it.trim()) }, lpm(0, 8))
        connBox.addView(btn("🔗  Connect YouTube", true) { connect() }, lpm(0, 0))
    }

    private fun connect() {
        cancelLogin = false
        toast("Contacting Google…")
        Thread {
            try {
                val d = YouTube.deviceStart(this)
                runOnUiThread {
                    try {
                        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("code", d.user))
                    } catch (e: Exception) { }
                    AlertDialog.Builder(this, dlgTheme)
                        .setTitle("Allow Prabhu on YouTube")
                        .setMessage("1. Tap “Open Google”.\n2. Enter this code (already copied):\n\n        ${d.user}\n\n3. Choose your channel's Google account and tap Allow.\n\nCome back here after that.")
                        .setCancelable(false)
                        .setPositiveButton("Open Google") { _, _ ->
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(d.url))) } catch (e: Exception) { }
                        }
                        .setNegativeButton("Cancel") { _, _ -> cancelLogin = true }
                        .show()
                }
                val ok = YouTube.devicePoll(this, d) { cancelLogin }
                runOnUiThread {
                    if (ok) { toast("YouTube connected ✓"); Store.setStr(this, "yt_channel", ""); renderConn() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "Couldn't connect") }
            }
        }.start()
    }

    // ---------------------------------------------------------------- plan

    private fun suggestTimes() {
        if (!YouTube.connected(this)) { toast("Connect YouTube first"); return }
        toast("Reading your channel…")
        Thread {
            try {
                val (plan, why) = YouTube.analyze(this)
                runOnUiThread {
                    AlertDialog.Builder(this, dlgTheme)
                        .setTitle("Suggested: $plan")
                        .setMessage(why)
                        .setPositiveButton("Use this plan") { _, _ -> planField.setText(plan) }
                        .setNegativeButton("Close", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "Couldn't read your channel") }
            }
        }.start()
    }

    // ---------------------------------------------------------------- add video

    private fun pickVideo() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            startActivityForResult(i, 401)
        } catch (e: Exception) { toast("No file picker found") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
        if (req == 401) {
            var name = "video"
            var size = 0L
            try {
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val si = c.getColumnIndex(OpenableColumns.SIZE)
                        if (ni >= 0) name = c.getString(ni) ?: name
                        if (si >= 0) size = c.getLong(si)
                    }
                }
            } catch (e: Exception) { }
            showAdd(uri, name, size)
        } else if (req == 402) {
            pendingThumb = uri.toString()
            thumbLabel?.text = "🖼  Thumbnail added ✓"
        }
    }

    private fun showAdd(uri: Uri, name: String, size: Long) {
        pendingThumb = ""
        var mode = "slot"          // slot, now, private, custom
        var custom = 0L
        var cat = "22"
        val cats = listOf("People & Blogs" to "22", "Entertainment" to "24", "Education" to "27", "How-to & Style" to "26",
            "Science & Tech" to "28", "Gaming" to "20", "Music" to "10", "News" to "25", "Comedy" to "23", "Travel" to "19")

        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)) }
        v.addView(tv("🎬  $name", 13f, cMute), lpm(0, 8))
        val notes = field("What is this video about? (AI uses this)", "", true)
        v.addView(notes, lpm(0, 8))
        val short = Switch(this).apply { text = "This is a Short (vertical)"; setTextColor(cText) }
        v.addView(short, lpm(0, 8))
        val title = field("Title", "", false)
        val desc = field("Description", "", true)
        val tags = field("Tags, separated by commas", "", false)
        v.addView(btn("✨  Write title, description & tags with AI", true) {
            val n = notes.text.toString().trim()
            if (n.isEmpty()) { toast("Write a line about the video first"); return@btn }
            toast("Prabhu is thinking…")
            Thread {
                try {
                    val m = YouTube.aiMeta(this, n, short.isChecked)
                    runOnUiThread { title.setText(m.title); desc.setText(m.desc); tags.setText(m.tags) }
                } catch (e: Exception) {
                    runOnUiThread { toast(e.message ?: "AI failed") }
                }
            }.start()
        }, lpm(0, 8))
        v.addView(title, lpm(0, 8))
        v.addView(desc, lpm(0, 8))
        v.addView(tags, lpm(0, 8))

        val whenBtn = btn("When: next slot in my weekly plan  ▾", false) {}
        fun whenText() = when (mode) {
            "now" -> "When: publish right now  ▾"
            "private" -> "When: keep private  ▾"
            "custom" -> "When: " + fmt(custom) + "  ▾"
            else -> "When: next slot in my weekly plan  ▾"
        }
        whenBtn.setOnClickListener {
            val opts = arrayOf("Next slot in my weekly plan", "Publish right now", "Pick date & time", "Keep private")
            AlertDialog.Builder(this, dlgTheme).setItems(opts) { _, i ->
                when (i) {
                    0 -> { mode = "slot"; whenBtn.text = whenText() }
                    1 -> { mode = "now"; whenBtn.text = whenText() }
                    3 -> { mode = "private"; whenBtn.text = whenText() }
                    else -> {
                        val cal = Calendar.getInstance()
                        DatePickerDialog(this, { _, y, mo, d ->
                            TimePickerDialog(this, { _, h, mi ->
                                val t = Calendar.getInstance()
                                t.set(y, mo, d, h, mi, 0)
                                t.set(Calendar.MILLISECOND, 0)
                                custom = t.timeInMillis
                                mode = "custom"
                                whenBtn.text = whenText()
                            }, 18, 0, false).show()
                        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }
                }
            }.show()
        }
        v.addView(whenBtn, lpm(0, 8))

        val catBtn = btn("Category: People & Blogs  ▾", false) {}
        catBtn.setOnClickListener {
            AlertDialog.Builder(this, dlgTheme).setItems(cats.map { it.first }.toTypedArray()) { _, i ->
                cat = cats[i].second
                catBtn.text = "Category: " + cats[i].first + "  ▾"
            }.show()
        }
        v.addView(catBtn, lpm(0, 8))

        val thumbBtn = btn("🖼  Add a thumbnail (optional)", false) {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 402
                )
            } catch (e: Exception) { toast("No file picker found") }
        }
        thumbLabel = thumbBtn
        v.addView(thumbBtn, lpm(0, 0))

        val dlg = AlertDialog.Builder(this, dlgTheme)
            .setTitle("Add to YouTube queue")
            .setView(ScrollView(this).apply { addView(v) })
            .setPositiveButton("Add to queue", null)
            .setNegativeButton("Cancel", null)
            .create()
        dlg.show()
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val t = title.text.toString().trim()
            if (t.isEmpty()) { toast("Write a title (or use the AI button)"); return@setOnClickListener }
            var at = 0L
            var privacy = "public"
            when (mode) {
                "slot" -> {
                    val s = YouTube.nextSlot(this)
                    if (s == null) { toast("Set your weekly plan first (Mon 18:00, ...)"); return@setOnClickListener }
                    at = s
                }
                "custom" -> {
                    if (custom < System.currentTimeMillis() + 10 * 60_000L) { toast("Pick a time at least 10 minutes from now"); return@setOnClickListener }
                    at = custom
                }
                "private" -> privacy = "private"
            }
            var d = desc.text.toString().trim()
            if (short.isChecked && !d.contains("#Shorts", true)) d = (d + "\n\n#Shorts").trim()
            val item = YouTube.Item(
                System.currentTimeMillis().toString(), uri.toString(), name, size, t, d, tags.text.toString().trim(),
                cat, at, privacy, pendingThumb
            )
            YouTube.mutate(this) { it.add(item) }
            dlg.dismiss()
            renderQueue()
            toast(if (at > 0) "Added. Goes live " + fmt(at) else "Added to the queue")
        }
    }

    // ---------------------------------------------------------------- queue

    private fun uploadNow() {
        if (!YouTube.connected(this)) { toast("Connect YouTube first"); return }
        if (YouTube.items(this).none { it.status == "ready" || it.status == "uploading" }) { toast("Nothing waiting to upload"); return }
        YtService.start(this)
        toast("Uploading in the background. You can close the app.")
    }

    private fun renderQueue() {
        if (!::queueBox.isInitialized) return
        queueBox.removeAllViews()
        val list = YouTube.items(this)
        if (list.isEmpty()) {
            queueBox.addView(tv("No videos yet. Tap “Add a video”.", 13f, cMute), lpm(0, 0))
            return
        }
        for (q in list.reversed()) {
            val st = when (q.status) {
                "ready" -> "⏳ Waiting" + (if (q.publishAt > 0) " · goes live " + fmt(q.publishAt) else "")
                "uploading" -> "⬆ Uploading ${q.progress}%"
                "scheduled" -> "🗓 Scheduled · goes live " + fmt(q.publishAt)
                "published" -> "✅ Published"
                else -> "❌ Failed: " + q.error.take(140)
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(cSurface, cLine, 14)
                setPadding(dp(14), dp(12), dp(14), dp(8))
            }
            card.addView(tv(q.title, 15f, cText, true))
            card.addView(tv(st, 13f, if (q.status == "failed") cErr else cMute), lpm(4, 0))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val id = q.id
            val vid = q.videoId
            if (q.status == "failed") row.addView(small("Retry", cAccent) {
                YouTube.patch(this, id) { x -> x.status = "ready"; x.error = "" }
                uploadNow()
                renderQueue()
            })
            if (vid.isNotEmpty()) row.addView(small("Open in Studio", cAccent) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://studio.youtube.com/video/$vid/edit"))) } catch (e: Exception) { }
            })
            if (q.status != "uploading") row.addView(small("Remove", cErr) {
                YouTube.mutate(this) { l -> l.removeAll { x -> x.id == id } }
                renderQueue()
            })
            card.addView(row)
            queueBox.addView(card, lpm(0, 8))
        }
    }
}
