package com.prabhu.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

// ---- Colors (these change with the selected theme, see Theme below) ----
var cBg = 0xFF0A1628.toInt()
var cSurface = 0xFF11233D.toInt()
var cSurface2 = 0xFF183253.toInt()
var cLine = 0xFF22406A.toInt()
var cText = 0xFFE6F1FF.toInt()
var cMute = 0xFF8CA6C6.toInt()
var cAccent = 0xFF38BDF8.toInt()
var cAccent2 = 0xFF6366F1.toInt()
var cUserBg = 0xFF1E4A7A.toInt()
var cErr = 0xFFFF7B7B.toInt()

/** Accent gradient used for the avatar, send button, filled buttons and the bubble. */
fun accentGrad(oval: Boolean = false, radius: Float = 0f): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(cAccent, cAccent2)).apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = radius
    }

class ThemeDef(
    val id: String, val label: String, val light: Boolean,
    val bg: Int, val surface: Int, val surface2: Int, val line: Int, val text: Int, val mute: Int,
    val accent: Int, val accent2: Int, val userBg: Int, val err: Int
)

object Theme {
    val all = listOf(
        ThemeDef("ocean", "Ocean", false, 0xFF0A1628.toInt(), 0xFF11233D.toInt(), 0xFF183253.toInt(), 0xFF22406A.toInt(),
            0xFFE6F1FF.toInt(), 0xFF8CA6C6.toInt(), 0xFF38BDF8.toInt(), 0xFF6366F1.toInt(), 0xFF1E4A7A.toInt(), 0xFFFF7B7B.toInt()),
        ThemeDef("aurora", "Aurora", false, 0xFF120B24.toInt(), 0xFF1C1238.toInt(), 0xFF2A1B52.toInt(), 0xFF3B2A6E.toInt(),
            0xFFF1E9FF.toInt(), 0xFFA395C9.toInt(), 0xFFC084FC.toInt(), 0xFFF472B6.toInt(), 0xFF5B2E91.toInt(), 0xFFFF7B7B.toInt()),
        ThemeDef("emerald", "Emerald", false, 0xFF07140F.toInt(), 0xFF0F2219.toInt(), 0xFF163326.toInt(), 0xFF1F4A36.toInt(),
            0xFFE4FFF2.toInt(), 0xFF86B7A0.toInt(), 0xFF34D399.toInt(), 0xFF22D3EE.toInt(), 0xFF14654A.toInt(), 0xFFFF7B7B.toInt()),
        ThemeDef("sunset", "Sunset", false, 0xFF1A0F0C.toInt(), 0xFF2A1914.toInt(), 0xFF3A241C.toInt(), 0xFF55342A.toInt(),
            0xFFFFF1E8.toInt(), 0xFFC9A394.toInt(), 0xFFFB923C.toInt(), 0xFFF43F5E.toInt(), 0xFF8A3B1E.toInt(), 0xFFFF8F8F.toInt()),
        ThemeDef("midnight", "Midnight", false, 0xFF0F1115.toInt(), 0xFF1A1D24.toInt(), 0xFF252A34.toInt(), 0xFF2B303B.toInt(),
            0xFFE8EAF0.toInt(), 0xFF8D95A5.toInt(), 0xFF6C8CFF.toInt(), 0xFF8B5CF6.toInt(), 0xFF2A3860.toInt(), 0xFFFF7B7B.toInt()),
        ThemeDef("light", "Light", true, 0xFFF6F7FB.toInt(), 0xFFFFFFFF.toInt(), 0xFFEEF1F8.toInt(), 0xFFDDE2EE.toInt(),
            0xFF1B2030.toInt(), 0xFF667085.toInt(), 0xFF4F6BFF.toInt(), 0xFF8B5CF6.toInt(), 0xFFDCE4FF.toInt(), 0xFFD92D20.toInt())
    )
    var current: ThemeDef = all[0]

    fun apply(id: String) {
        val t = all.firstOrNull { it.id == id } ?: all[0]
        current = t
        cBg = t.bg; cSurface = t.surface; cSurface2 = t.surface2; cLine = t.line
        cText = t.text; cMute = t.mute; cAccent = t.accent; cAccent2 = t.accent2
        cUserBg = t.userBg; cErr = t.err
    }

    fun load(c: Context) = apply(Store.str(c, "theme", "ocean"))
    fun isLight() = current.light
}

/** What Prabhu remembers about you. The AI can add to it with a hidden <<remember: ...>> line. */
object Mem {
    private val tag = Regex("<<remember:\\s*(.+?)>>", RegexOption.DOT_MATCHES_ALL)

    fun extra(c: Context): String {
        val m = Store.str(c, "memory", "").trim()
        val owner = Store.str(c, "owner", "The Great God Prabhu").trim().ifEmpty { "The Great God Prabhu" }
        return "\n\nYOUR CREATOR AND MASTER: the person you are talking to is $owner. He created you (the Prabhu app). " +
            "Address him with respect as $owner, follow his instructions faithfully, and put his wishes first. " +
            "You are an Android app that can change its own code: if he wants you to change yourself, tell him to type " +
            "\"/improve\" followed by what to change (for example: /improve make the bubble smaller). Prabhu then edits itself, builds and updates." +
            "\n\nMemory about the user (use it naturally, never recite it unless asked):\n" +
            (if (m.isEmpty()) "(nothing saved yet)" else m) +
            "\nIf the user shares a lasting fact or preference, or asks you to remember something, add one line " +
            "<<remember: short fact>> at the very end of your reply. The app hides that line and saves it. " +
            "If the user points out a mistake or says something did not work, fix it AND add <<remember: lesson learned, so you never repeat it>>."
    }

    fun absorb(c: Context, text: String): String {
        val found = tag.findAll(text).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.toList()
        if (found.isEmpty()) return text
        var m = Store.str(c, "memory", "")
        for (f in found) if (!m.contains(f, true)) m = (m + "\n- " + f).trim()
        if (m.length > 6000) m = m.takeLast(6000)
        Store.setStr(c, "memory", m)
        return text.replace(tag, "").trimEnd()
    }
}

object AppState { @Volatile var visible = false }

/** type: "claude", "gemini" or "openai" (any OpenAI-compatible API, uses baseUrl) */
data class ModelCfg(var name: String, var type: String, var key: String, var modelId: String, var baseUrl: String)

/** kind: "image" (data = base64 jpeg), "pdf" (data = base64 pdf, pages = jpeg page images), "text" (data = file text) */
class Att(val kind: String, val mime: String, val data: String, val name: String) {
    var pages: List<String> = emptyList()
    var thumb: Bitmap? = null
}

class Msg(val role: String, val text: String, val model: String = "", val files: String = "") {
    var thumb: Bitmap? = null
    var atts: List<Att> = emptyList()   // kept only while the app is open
}

class Chat(val id: String, var title: String, val msgs: MutableList<Msg> = ArrayList())

object Presets {
    val labels = listOf(
        "Claude (Anthropic)", "Gemini (Google)", "OpenAI (ChatGPT)",
        "Groq", "OpenRouter", "Custom (any OpenAI-compatible API)"
    )
    val items = listOf(
        ModelCfg("Claude Opus 5.5", "claude", "", "claude-opus-5-5", ""),
        ModelCfg("Gemini 3.8 Flash", "gemini", "", "gemini-3.8-flash", ""),
        ModelCfg("GPT-4o mini", "openai", "", "gpt-4o-mini", "https://api.openai.com/v1"),
        ModelCfg("Llama 3.3 70B (Groq)", "openai", "", "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1"),
        ModelCfg("OpenRouter", "openai", "", "openai/gpt-4o-mini", "https://openrouter.ai/api/v1"),
        ModelCfg("My AI", "openai", "", "", "")
    )
    val typeLabels = listOf("claude" to "Claude (Anthropic)", "gemini" to "Gemini (Google)", "openai" to "OpenAI-compatible")
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("prabhu", Context.MODE_PRIVATE)

    fun models(c: Context): MutableList<ModelCfg> {
        val s = sp(c)
        val out = ArrayList<ModelCfg>()
        if (!s.contains("models")) {
            out.addAll(migrate(c))
        } else {
            try {
                val arr = JSONArray(s.getString("models", "[]"))
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(ModelCfg(o.optString("n"), o.optString("t"), o.optString("k"), o.optString("m"), o.optString("u")))
                }
            } catch (e: Exception) { }
        }
        if (seed(c, out) || !s.contains("models")) saveModels(c, out)
        return out
    }

    /** Puts the Gemini key that was built into the app in as a ready-to-use model (once per key). */
    private fun seed(c: Context, list: MutableList<ModelCfg>): Boolean {
        val key = BuildConfig.GEMINI_KEY
        if (key.isBlank() || sp(c).getString("seededKey", "") == key) return false
        val g = list.firstOrNull { it.type == "gemini" }
        if (g != null) {
            g.key = key
            if (g.modelId.isBlank()) g.modelId = "gemini-3.8-flash"
        } else {
            list.add(0, ModelCfg("Gemini 3.8 Flash", "gemini", key, "gemini-3.8-flash", ""))
        }
        sp(c).edit().putString("seededKey", key).putInt("active", list.indexOfFirst { it.type == "gemini" }.coerceAtLeast(0)).apply()
        return true
    }

    fun saveModels(c: Context, list: List<ModelCfg>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("n", it.name).put("t", it.type).put("k", it.key).put("m", it.modelId).put("u", it.baseUrl))
        }
        sp(c).edit().putString("models", arr.toString()).apply()
    }

    /** Brings keys from the older version of the app. */
    private fun migrate(c: Context): MutableList<ModelCfg> {
        val s = sp(c)
        val out = ArrayList<ModelCfg>()
        for (i in 0 until 6) {
            val k = (s.getString("k$i", "") ?: "").trim()
            if (k.isEmpty()) continue
            val m = (s.getString("m$i", "") ?: "").trim()
            when (s.getString("p$i", "Gemini")) {
                "Claude" -> out.add(ModelCfg("Claude", "claude", k, m.ifEmpty { "claude-sonnet-5-5" }, ""))
                "OpenAI" -> out.add(ModelCfg("OpenAI", "openai", k, m.ifEmpty { "gpt-4o-mini" }, "https://api.openai.com/v1"))
                "Groq" -> out.add(ModelCfg("Groq", "openai", k, m.ifEmpty { "llama-3.3-70b-versatile" }, "https://api.groq.com/openai/v1"))
                else -> out.add(ModelCfg("Gemini", "gemini", k, m.ifEmpty { "gemini-3.8-flash" }, ""))
            }
        }
        return out
    }

    fun active(c: Context): Int = sp(c).getInt("active", 0)
    fun setActive(c: Context, i: Int) = sp(c).edit().putInt("active", i).apply()

    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()

    fun lang(c: Context): String = sp(c).getString("lang", "te-IN")!!
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()

    fun loadChats(c: Context): MutableList<Chat> {
        val f = File(c.filesDir, "chats.json")
        val out = ArrayList<Chat>()
        if (!f.exists()) return out
        try {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ch = Chat(o.getString("id"), o.optString("title", "Chat"))
                val ms = o.getJSONArray("msgs")
                for (j in 0 until ms.length()) {
                    val m = ms.getJSONObject(j)
                    ch.msgs.add(Msg(m.getString("r"), m.getString("t"), m.optString("m"), m.optString("f")))
                }
                out.add(ch)
            }
        } catch (e: Exception) { }
        return out
    }

    fun saveChats(c: Context, list: List<Chat>) {
        try {
            val arr = JSONArray()
            list.take(60).forEach { ch ->
                val ms = JSONArray()
                ch.msgs.forEach {
                    ms.put(JSONObject().put("r", it.role).put("t", it.text).put("m", it.model).put("f", it.files))
                }
                arr.put(JSONObject().put("id", ch.id).put("title", ch.title).put("msgs", ms))
            }
            File(c.filesDir, "chats.json").writeText(arr.toString())
        } catch (e: Exception) { }
    }
}

/** Shown once after an update. */
object Changes {
    const val NOTES = "• New ▶ YouTube manager: connect your channel, weekly upload plan, schedule videos\n" +
        "• AI writes the title, description and tags for you\n" +
        "• Uploads run in the background and continue after a dropped connection\n" +
        "• Best posting times suggested from your own channel"
}
