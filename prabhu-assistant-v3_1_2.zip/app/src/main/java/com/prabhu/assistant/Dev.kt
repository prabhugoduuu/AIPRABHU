package com.prabhu.assistant

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.util.Base64
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Prabhu improving itself, with no PC:
 *   1. reads its own source from your GitHub repo,
 *   2. asks the AI (max mode) to write the change as small patches,
 *   3. commits it, GitHub Actions builds the new APK,
 *   4. if the build fails it reads the errors and lets the AI fix them (up to 2 times),
 *   5. downloads the APK and installs it over the old app (same signing key).
 * Every change can be undone.
 */
object Dev {
    class Cfg(val repo: String, val token: String, val branch: String)
    class FileRef(val path: String, val sha: String, val size: Int)
    class Snap(val commit: String, val tree: String, val files: List<FileRef>)

    /** changes: path -> new content (null = delete). originals: path -> content before (null = file did not exist). */
    class Proposal(val summary: String, val originals: Map<String, String?>, val changes: Map<String, String?>)

    class UI(
        val log: (String) -> Unit,
        val status: (String) -> Unit,
        val confirm: (String) -> Boolean,
        val cancelled: () -> Boolean
    )

    private class Http(val code: Int, val text: String, val location: String?)
    private class Edit(val path: String, val find: String, val replace: String)
    private class Parsed(val summary: String, val edits: List<Edit>, val news: Map<String, String>, val deletes: List<String>)
    private class Build(val id: Long, val ok: Boolean, val conclusion: String)

    private const val DEV_SYS =
        "You are the self-improvement engineer of \"Prabhu\", an Android app written in Kotlin (1.9.24, Gradle, minSdk 26, compileSdk 34). " +
        "The UI is built in code with plain Android Views (no Compose, no XML layouts, no external libraries). " +
        "Main files: MainActivity.kt (chat UI, settings, drawer), Ai.kt (Claude/Gemini/OpenAI calls), ScreenService.kt (floating bubble and overlay panel), " +
        "Store.kt (settings, themes, chats), CodeFiles.kt (code save + preview), Cmd.kt (phone voice commands), Dev.kt/DevActivity.kt (this self-improve tool). " +
        "You receive the user's request and the current source of the relevant files. Make the change the user wants, with the smallest safe edits.\n\n" +
        "RULES:\n" +
        "- The result MUST compile. Use only the Android SDK (API 34 or lower) and the Kotlin standard library. Do not add dependencies.\n" +
        "- If you add an Activity, Service, Receiver or permission, also edit app/src/main/AndroidManifest.xml.\n" +
        "- Never change versionCode/versionName (the app bumps them), the signing config, applicationId, prabhu.jks, gemini.key or .github/workflows.\n" +
        "- Do not remove existing features. Do not touch code that has nothing to do with the request.\n" +
        "- Copy FIND text EXACTLY from the file contents given (same spaces and line breaks), with enough lines to be unique in the file.\n\n" +
        "OUTPUT FORMAT (nothing else, no markdown fences):\n" +
        "SUMMARY: one or two short sentences saying what you changed, in the user's language\n" +
        "@@@ FILE path/to/ExistingFile.kt\n" +
        "<<<<<<< FIND\n" +
        "exact existing text\n" +
        "=======\n" +
        "replacement text\n" +
        ">>>>>>> REPLACE\n" +
        "(more FIND/REPLACE blocks for the same file may follow)\n" +
        "@@@ NEW path/to/NewFile.kt\n" +
        "complete content of the new file\n" +
        "@@@ END\n" +
        "@@@ DELETE path/to/file\n"

    private const val PLAN_SYS =
        "You help plan code changes. Answer with ONLY a JSON array of file paths, nothing else."

    // ---------------------------------------------------------------- config + HTTP

    fun cfg(c: Context): Cfg {
        val repo = Store.str(c, "gh_repo", "").trim().removePrefix("https://github.com/").trim('/').removeSuffix(".git")
        val token = Store.str(c, "gh_token", "").trim()
        val br = Store.str(c, "gh_branch", "main").trim().ifEmpty { "main" }
        if (repo.count { it == '/' } != 1 || token.isEmpty()) throw Exception("Enter your GitHub repo (owner/name) and token first.")
        return Cfg(repo, token, br)
    }

    /** Every GitHub call is retried 3 times if the network drops. */
    private fun http(cfg: Cfg?, method: String, url: String, body: String? = null, auth: Boolean = true, follow: Boolean = true): Http {
        var err: Exception? = null
        for (a in 1..3) {
            try {
                return http1(cfg, method, url, body, auth, follow)
            } catch (e: java.io.IOException) {
                err = e
                Thread.sleep(3000L * a)
            }
        }
        throw Exception("Network problem (${err?.message}). Check your internet, then tap Resume.")
    }

    private fun http1(cfg: Cfg?, method: String, url: String, body: String? = null, auth: Boolean = true, follow: Boolean = true): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.instanceFollowRedirects = follow
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("User-Agent", "Prabhu-App")
        if (auth && cfg != null) {
            c.setRequestProperty("Authorization", "Bearer ${cfg.token}")
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val loc = c.getHeaderField("Location")
        val text = try {
            (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) { "" }
        return Http(code, text, loc)
    }

    private fun api(cfg: Cfg, method: String, path: String, body: JSONObject? = null): JSONObject {
        val r = http(cfg, method, "https://api.github.com/repos/${cfg.repo}$path", body?.toString())
        if (r.code !in 200..299) {
            val msg = try { JSONObject(r.text).optString("message") } catch (e: Exception) { r.text.take(100) }
            val write = method != "GET"
            val hint = if (write && (r.code == 404 || r.code == 403))
                "\n\nThis step SAVES to GitHub. 'Not Found' here almost always means your token cannot WRITE. " +
                    "Make a classic token with “repo” ticked (or a fine-grained token with Contents = Read and write), paste it in the token box and tap Test connection."
            else ""
            throw Exception("GitHub ${r.code}: $msg  [$method $path]$hint")
        }
        return if (r.text.isBlank()) JSONObject() else JSONObject(r.text)
    }

    /** Checks the repo + token and returns a short description. */
    fun check(c: Context): String {
        val cfg = cfg(c)
        val s = snapshot(cfg)
        val canWrite = canPush(cfg)
        return "Connected to ${cfg.repo} (${cfg.branch}). ${s.files.size} source files, latest commit ${s.commit.take(7)}.\n" +
            (if (canWrite) "Write access: YES ✓ (Prabhu can save changes)"
            else "Write access: NO ✗. This token can only read. Make a classic token with “repo” ticked and paste it again.")
    }

    /** Does the token have permission to save (push) to the repo? */
    private fun canPush(cfg: Cfg): Boolean {
        val o = api(cfg, "GET", "")
        return o.optJSONObject("permissions")?.optBoolean("push", false) ?: false
    }

    private fun wanted(p: String): Boolean {
        if (p.startsWith("build/") || p.contains("/build/") || p.startsWith(".gradle")) return false
        val x = p.substringAfterLast('.', "").lowercase()
        return x in setOf("kt", "kts", "xml", "yml", "yaml", "md", "properties", "gradle", "txt", "json")
    }

    private fun snapshot(cfg: Cfg): Snap {
        val ref = api(cfg, "GET", "/git/ref/heads/${cfg.branch}")
        val commit = ref.getJSONObject("object").getString("sha")
        val cm = api(cfg, "GET", "/git/commits/$commit")
        val tree = cm.getJSONObject("tree").getString("sha")
        val t = api(cfg, "GET", "/git/trees/$tree?recursive=1")
        val files = ArrayList<FileRef>()
        val arr = t.getJSONArray("tree")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") != "blob") continue
            val p = o.getString("path")
            if (!wanted(p)) continue
            files.add(FileRef(p, o.getString("sha"), o.optInt("size")))
        }
        if (files.isEmpty()) throw Exception("No source files found in ${cfg.repo}. Is the project at the root of the repo?")
        return Snap(commit, tree, files)
    }

    private fun blob(cfg: Cfg, sha: String): String {
        val o = api(cfg, "GET", "/git/blobs/$sha")
        return String(Base64.decode(o.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
    }

    // ---------------------------------------------------------------- AI

    /** Asks the AI. If the network drops (common on mobile data) it waits and retries up to 3 times. */
    private fun ai(c: Context, system: String, prompt: String, onText: ((String) -> Unit)?): String {
        val net = Regex("(?i)resolve host|connection|timeout|timed out|abort|reset|unexpected end|EOF|network|unreachable")
        var last = "failed"
        for (a in 1..3) {
            val r = Ai.ask(
                Store.models(c), Store.active(c), Store.bool(c, "fallback", true),
                listOf(Msg("user", prompt)), false, "", onText, true, system
            )
            if (r.ok) return r.text
            last = r.text
            if (!net.containsMatchIn(last) || a == 3) break
            Thread.sleep(5000L * a)
        }
        throw Exception(last + "\n\nCheck your internet (Wi-Fi is best) and tap Improve Prabhu again.")
    }

    private fun parsePaths(text: String, snap: Snap): List<String> {
        val have = snap.files.map { it.path }.toSet()
        val out = ArrayList<String>()
        try {
            val a = text.indexOf('[')
            val b = text.lastIndexOf(']')
            if (a >= 0 && b > a) {
                val arr = JSONArray(text.substring(a, b + 1))
                for (i in 0 until arr.length()) {
                    val p = arr.optString(i).trim()
                    if (p in have && p !in out) out.add(p)
                }
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) {
            snap.files.filter { it.path.endsWith(".kt") && it.size < 80000 }.take(6).forEach { out.add(it.path) }
        }
        return out.take(8)
    }

    private fun cleanPath(p: String) = p.trim().trim('`', '"', '\'', '*').trimStart('/')

    private fun unfence(s: String): String {
        var t = s
        if (t.startsWith("```")) t = t.substringAfter("\n", "")
        val e = t.trimEnd()
        if (e.endsWith("```")) t = e.removeSuffix("```").trimEnd('\n', ' ') + "\n"
        return t
    }

    private fun parse(text: String): Parsed {
        var summary = ""
        val edits = ArrayList<Edit>()
        val news = LinkedHashMap<String, String>()
        val dels = ArrayList<String>()
        val lines = text.replace("\r\n", "\n").split("\n")
        var i = 0
        var cur = ""
        while (i < lines.size) {
            val t = lines[i].trim()
            if (t.startsWith("SUMMARY:") && summary.isEmpty()) {
                summary = t.removePrefix("SUMMARY:").trim()
            } else if (t.startsWith("@@@ FILE ")) {
                cur = cleanPath(t.removePrefix("@@@ FILE "))
            } else if (t.startsWith("@@@ DELETE ")) {
                dels.add(cleanPath(t.removePrefix("@@@ DELETE ")))
            } else if (t.startsWith("@@@ NEW ")) {
                val p = cleanPath(t.removePrefix("@@@ NEW "))
                val sb = StringBuilder()
                i++
                while (i < lines.size && lines[i].trim() != "@@@ END") { sb.append(lines[i]).append("\n"); i++ }
                news[p] = unfence(sb.toString())
            } else if (t.startsWith("<<<<<<< FIND") && cur.isNotEmpty()) {
                val f = StringBuilder()
                val r = StringBuilder()
                i++
                while (i < lines.size && lines[i].trim() != "=======") { f.append(lines[i]).append("\n"); i++ }
                i++
                while (i < lines.size && !lines[i].trim().startsWith(">>>>>>> REPLACE")) { r.append(lines[i]).append("\n"); i++ }
                edits.add(Edit(cur, f.toString().removeSuffix("\n"), r.toString().removeSuffix("\n")))
            }
            i++
        }
        return Parsed(summary, edits, news, dels)
    }

    private fun replaceOnce(src: String, find: String, rep: String): String? {
        if (find.isBlank()) return null
        val i = src.indexOf(find)
        if (i >= 0) {
            if (src.indexOf(find, i + 1) >= 0) return null   // not unique
            return src.substring(0, i) + rep + src.substring(i + find.length)
        }
        // tolerant match: ignore spaces at the end of lines
        val sl = src.split("\n")
        val fl = find.split("\n").map { it.trimEnd() }
        var hit = -1
        for (s in 0..(sl.size - fl.size)) {
            var ok = true
            for (k in fl.indices) if (sl[s + k].trimEnd() != fl[k]) { ok = false; break }
            if (ok) { if (hit >= 0) return null; hit = s }
        }
        if (hit < 0) return null
        val out = ArrayList<String>()
        out.addAll(sl.subList(0, hit))
        out.addAll(rep.split("\n"))
        out.addAll(sl.subList(hit + fl.size, sl.size))
        return out.joinToString("\n")
    }

    /** Applies the edits to [files] in memory. Returns the list of edits that could not be applied. */
    private fun applyEdits(files: MutableMap<String, String>, edits: List<Edit>): List<String> {
        val errs = ArrayList<String>()
        for (e in edits) {
            val cur = files[e.path]
            if (cur == null) { errs.add("${e.path}: file does not exist"); continue }
            val r = replaceOnce(cur, e.find, e.replace)
            if (r == null) errs.add("${e.path}: this FIND text was not found exactly once:\n${e.find.take(400)}")
            else files[e.path] = r
        }
        return errs
    }

    // ---------------------------------------------------------------- propose

    private fun readFiles(cfg: Cfg, snap: Snap, paths: List<String>, ui: UI): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        for (p in paths) {
            val f = snap.files.firstOrNull { it.path == p } ?: continue
            ui.status("Reading $p")
            out[p] = blob(cfg, f.sha)
        }
        return out
    }

    /** Sends the request + file contents to the AI and turns the answer into a verified proposal. */
    private fun generate(
        c: Context, snap: Snap, task: String, current: Map<String, String>, ui: UI
    ): Proposal {
        val list = snap.files.joinToString("\n") { "${it.path} (${it.size} bytes)" }
        val sb = StringBuilder()
        sb.append("Project files:\n").append(list).append("\n\nCurrent contents of the files you may edit:\n")
        for ((p, t) in current) sb.append("\n##### FILE: ").append(p).append("\n").append(t).append("\n##### END OF ").append(p).append("\n")
        sb.append("\n").append(task).append("\n\nNow write the changes in the required patch format.")
        val prompt = sb.toString()
        if (prompt.length > 600_000) throw Exception("The request touches too much code at once. Ask for a smaller change.")

        ui.log("Prabhu is writing the change (max mode, this can take a minute or two)…")
        var shown = 0L
        val out = ai(c, DEV_SYS, prompt) { t ->
            val now = System.currentTimeMillis()
            if (now - shown > 700) { shown = now; ui.status("Writing… ${t.length / 1000} KB") }
        }
        var parsed = parse(out)
        if (parsed.edits.isEmpty() && parsed.news.isEmpty() && parsed.deletes.isEmpty()) {
            throw Exception("Prabhu did not produce a change. It said:\n" + out.take(400))
        }
        val files = LinkedHashMap<String, String>(current)
        val newPaths = HashSet<String>()
        for ((p, t) in parsed.news) { files[p] = t; newPaths.add(p) }
        var errs = applyEdits(files, parsed.edits)
        if (errs.isNotEmpty()) {
            ui.log("${errs.size} edit(s) did not match, asking Prabhu to correct them…")
            val retry = prompt + "\n\nYour previous answer:\n" + out +
                "\n\nThese edits could NOT be applied:\n" + errs.joinToString("\n---\n") +
                "\n\nReply with ONLY corrected @@@ FILE blocks for the failed edits (same format), copying the FIND text exactly from the file contents above."
            val out2 = ai(c, DEV_SYS, retry, null)
            val p2 = parse(out2)
            errs = applyEdits(files, p2.edits)
            if (errs.isNotEmpty()) throw Exception("Couldn't apply the change cleanly:\n" + errs.first().take(300))
            parsed = Parsed(parsed.summary, parsed.edits + p2.edits, parsed.news, parsed.deletes)
        }
        val changes = LinkedHashMap<String, String?>()
        val originals = LinkedHashMap<String, String?>()
        for ((p, t) in files) {
            val before = current[p]
            if (before == null || before != t) {
                changes[p] = t
                originals[p] = before
            }
        }
        for (d in parsed.deletes) {
            if (snap.files.any { it.path == d } && d !in changes) {
                changes[d] = null
                originals[d] = current[d] ?: blob(cfgOf(c), snap.files.first { it.path == d }.sha)
            }
        }
        if (changes.isEmpty()) throw Exception("The change was empty.")
        for (p in changes.keys) {
            val low = p.lowercase()
            if (low.endsWith(".jks") || low.contains("gemini.key") || low.startsWith(".github/")) {
                throw Exception("Prabhu tried to change a protected file ($p). Cancelled.")
            }
        }
        return Proposal(parsed.summary.ifBlank { "Update" }, originals, changes)
    }

    private fun cfgOf(c: Context) = cfg(c)

    private fun propose(c: Context, cfg: Cfg, snap: Snap, request: String, ui: UI): Proposal {
        ui.log("Planning which files to read…")
        val list = snap.files.joinToString("\n") { "${it.path} (${it.size} bytes)" }
        val planText = ai(
            c, PLAN_SYS,
            "Project files:\n$list\n\nUser request: $request\n\n" +
                "Which files do you need to read to implement this? Include every file you will edit. " +
                "Reply with ONLY a JSON array of paths (max 8).", null
        )
        val paths = parsePaths(planText, snap)
        ui.log("Reading: " + paths.joinToString(", ") { it.substringAfterLast('/') })
        val current = readFiles(cfg, snap, paths, ui)
        return generate(c, snap, "User request:\n$request", current, ui)
    }

    private fun fixProposal(c: Context, cfg: Cfg, snap: Snap, request: String, errors: String, ui: UI): Proposal {
        val mentioned = Regex("app/src/main/[\\w/.\\-]+\\.(?:kt|xml|kts)").findAll(errors).map { it.value }.toList()
        var paths = mentioned.filter { p -> snap.files.any { it.path == p } }.distinct().take(6)
        if (paths.isEmpty()) paths = snap.files.filter { it.path.endsWith(".kt") && it.size < 80000 }.take(4).map { it.path }
        val current = readFiles(cfg, snap, paths, ui)
        val task = "The build FAILED after this change: \"$request\".\n" +
            "Fix ONLY the compile errors below with the smallest possible edits (or undo the part that caused them).\n\n" +
            "BUILD ERRORS:\n$errors"
        return generate(c, snap, task, current, ui)
    }

    // ---------------------------------------------------------------- commit

    private fun bump(g: String): String {
        var s = Regex("versionCode\\s*=\\s*(\\d+)").replace(g) { "versionCode = ${it.groupValues[1].toInt() + 1}" }
        s = Regex("versionName\\s*=\\s*\"(\\d+)\\.(\\d+)(?:\\.\\d+)?\"").replace(s) {
            "versionName = \"${it.groupValues[1]}.${it.groupValues[2].toInt() + 1}\""
        }
        return s
    }

    /** One commit with all changed files (so GitHub starts exactly one build). */
    private fun commit(cfg: Cfg, snap: Snap, changes: Map<String, String?>, message: String): String {
        val all = LinkedHashMap<String, String?>(changes)
        val bg = "app/build.gradle.kts"
        val gradle = all[bg] ?: snap.files.firstOrNull { it.path == bg }?.let { blob(cfg, it.sha) }
        if (gradle != null) all[bg] = bump(gradle)
        val tree = JSONArray()
        for ((path, content) in all) {
            val e = JSONObject().put("path", path).put("mode", "100644").put("type", "blob")
            if (content == null) {
                e.put("sha", JSONObject.NULL)
            } else {
                val b = api(cfg, "POST", "/git/blobs", JSONObject().put("content", content).put("encoding", "utf-8"))
                e.put("sha", b.getString("sha"))
            }
            tree.put(e)
        }
        val nt = api(cfg, "POST", "/git/trees", JSONObject().put("base_tree", snap.tree).put("tree", tree))
        val nc = api(
            cfg, "POST", "/git/commits",
            JSONObject().put("message", message).put("tree", nt.getString("sha")).put("parents", JSONArray().put(snap.commit))
        )
        val sha = nc.getString("sha")
        api(cfg, "PATCH", "/git/refs/heads/${cfg.branch}", JSONObject().put("sha", sha))
        return sha
    }

    private fun saveUndo(c: Context, originals: Map<String, String?>) {
        try {
            val o = JSONObject()
            for ((p, t) in originals) o.put(p, t ?: JSONObject.NULL)
            File(c.filesDir, "dev_undo.json").writeText(o.toString())
        } catch (e: Exception) { }
    }

    fun hasUndo(c: Context) = File(c.filesDir, "dev_undo.json").exists()

    // ---------------------------------------------------------------- build

    private fun waitBuild(cfg: Cfg, sha: String, ui: UI): Build {
        val t0 = System.currentTimeMillis()
        while (System.currentTimeMillis() - t0 < 30 * 60_000L) {
            if (ui.cancelled()) throw Exception("Stopped.")
            val secs = (System.currentTimeMillis() - t0) / 1000
            val r = api(cfg, "GET", "/actions/runs?head_sha=$sha&per_page=5")
            val runs = r.optJSONArray("workflow_runs")
            if (runs != null && runs.length() > 0) {
                val run = runs.getJSONObject(0)
                val status = run.optString("status")
                if (status == "completed") {
                    val concl = run.optString("conclusion")
                    return Build(run.getLong("id"), concl == "success", concl)
                }
                ui.status("GitHub is building… $status (${secs / 60}m ${secs % 60}s)")
            } else {
                if (secs > 240) throw Exception("GitHub did not start a build. Check that Actions are enabled for the repo.")
                ui.status("Waiting for GitHub to start the build… (${secs}s)")
            }
            Thread.sleep(8000)
        }
        throw Exception("The build took too long (30 min).")
    }

    private fun buildErrors(cfg: Cfg, runId: Long): String {
        val jobs = api(cfg, "GET", "/actions/runs/$runId/jobs").optJSONArray("jobs") ?: return ""
        val lines = ArrayList<String>()
        val pick = Regex("(^|\\s)e: |error:|Execution failed|What went wrong|Unresolved reference|Type mismatch|None of the following")
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i)
            if (j.optString("conclusion") != "failure") continue
            val r = http(cfg, "GET", "https://api.github.com/repos/${cfg.repo}/actions/jobs/${j.getLong("id")}/logs", follow = false)
            val loc = r.location
            val text = if (r.code in 300..399 && loc != null) http(null, "GET", loc, auth = false).text else r.text
            for (raw in text.lines()) {
                if (!pick.containsMatchIn(raw)) continue
                var l = raw.replace(Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z\\s?"), "")
                l = l.replace(Regex("file:///home/runner/work/[^/]+/[^/]+/"), "")
                lines.add(l.take(300))
                if (lines.size >= 60) break
            }
        }
        return lines.distinct().joinToString("\n")
    }

    private fun downloadApk(cfg: Cfg, runId: Long, dest: File) {
        val arts = api(cfg, "GET", "/actions/runs/$runId/artifacts").optJSONArray("artifacts")
        if (arts == null || arts.length() == 0) throw Exception("The build finished but has no APK file.")
        val id = arts.getJSONObject(0).getLong("id")
        val r = http(cfg, "GET", "https://api.github.com/repos/${cfg.repo}/actions/artifacts/$id/zip", follow = false)
        val loc = r.location ?: throw Exception("Couldn't download the APK (GitHub ${r.code}).")
        val conn = URL(loc).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 120000
        if (conn.responseCode !in 200..299) throw Exception("Download failed (${conn.responseCode}).")
        ZipInputStream(conn.inputStream).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (!e.isDirectory && e.name.endsWith(".apk")) {
                    dest.parentFile?.mkdirs()
                    dest.outputStream().use { o -> z.copyTo(o) }
                    return
                }
            }
        }
        throw Exception("No .apk file inside the build download.")
    }

    private fun apkFile(c: Context) = File(c.cacheDir, "update/Prabhu-update.apk")

    /** Waits for the build of [sha]. With [request] set, build errors are fixed automatically (2 tries). */
    private fun finish(c: Context, cfg: Cfg, shaIn: String, request: String?, ui: UI): File {
        var sha = shaIn
        for (attempt in 0..2) {
            val b = waitBuild(cfg, sha, ui)
            if (b.ok) {
                ui.log("Build succeeded ✓  Downloading the new app…")
                ui.status("Downloading…")
                val f = apkFile(c)
                downloadApk(cfg, b.id, f)
                Store.setStr(c, "dev_pending", "")
                return f
            }
            ui.log("Build failed (${b.conclusion}).")
            if (request == null || attempt == 2) break
            val errs = buildErrors(cfg, b.id)
            if (errs.isBlank()) throw Exception("The build failed and no error lines were found. Check the Actions tab on GitHub.")
            ui.log("Asking Prabhu to fix the build errors (try ${attempt + 1} of 2)…")
            val snap = snapshot(cfg)
            val fix = fixProposal(c, cfg, snap, request, errs, ui)
            sha = commit(cfg, snap, fix.changes, "Prabhu: auto-fix build errors (${attempt + 1})")
            Store.setStr(c, "dev_pending", sha + "|" + (request ?: ""))
            ui.log("Fix saved (${sha.take(7)}). Building again…")
        }
        Store.setStr(c, "dev_pending", "")
        throw Exception("The build is still failing. Use 'Undo last change' to go back, or describe the problem differently.")
    }

    // ---------------------------------------------------------------- public actions

    /** The whole loop: understand -> change -> commit -> build -> (fix) -> APK. Returns the APK, ready to install. */
    fun improve(c: Context, request: String, ui: UI): File {
        val cfg = cfg(c)
        ui.log("Reading your repo ${cfg.repo}…")
        val snap = snapshot(cfg)
        ui.log("${snap.files.size} source files found.")
        if (!canPush(cfg)) {
            throw Exception("Your GitHub token can only READ this repo, so it cannot save changes. " +
                "Make a classic token with “repo” ticked (or fine-grained: Contents = Read and write), paste it in the token box, tap Test connection, then try again.")
        }
        if (snap.files.none { it.path.endsWith(".kt") }) {
            throw Exception("Your repo has no Prabhu code yet (only ${snap.files.size} file(s)). Upload the Prabhu project zip to the repo first.")
        }
        val p = propose(c, cfg, snap, request, ui)
        val names = p.changes.keys.joinToString("\n") { "• $it" + (if (p.changes[it] == null) "  (delete)" else "") }
        ui.log("Plan: ${p.summary}\n$names")
        if (!ui.confirm("${p.summary}\n\nFiles:\n$names\n\nSave this to GitHub and build a new version?")) {
            throw Exception("Cancelled. Nothing was changed.")
        }
        val sha = commit(cfg, snap, p.changes, "Prabhu self-improve: ${request.take(60)}")
        saveUndo(c, p.originals)
        Store.setStr(c, "dev_pending", sha + "|" + request.take(200))
        Store.setStr(c, "dev_notes", p.summary)
        ui.log("Saved to GitHub (${sha.take(7)}). Building the new app…")
        return finish(c, cfg, sha, request, ui)
    }

    fun pending(c: Context): String = Store.str(c, "dev_pending", "")

    /** Continues a build that was interrupted (app closed, network lost): waits for it, then downloads the APK. */
    fun resume(c: Context, ui: UI): File {
        val p = pending(c)
        if (p.isBlank()) throw Exception("Nothing to resume.")
        val sha = p.substringBefore("|")
        val req = p.substringAfter("|", "").ifBlank { null }
        ui.log("Resuming the build for ${sha.take(7)}…")
        return finish(c, cfg(c), sha, req, ui)
    }

    /** Puts the files of the last change back to how they were, builds, and returns the APK. */
    fun undo(c: Context, ui: UI): File {
        val f = File(c.filesDir, "dev_undo.json")
        if (!f.exists()) throw Exception("Nothing to undo.")
        val cfg = cfg(c)
        val o = JSONObject(f.readText())
        val changes = LinkedHashMap<String, String?>()
        for (k in o.keys()) changes[k] = if (o.isNull(k)) null else o.getString(k)
        val snap = snapshot(cfg)
        // files that the change had deleted come back; files it created are removed (null)
        val names = changes.keys.joinToString("\n") { "• $it" }
        if (!ui.confirm("Put these files back to how they were before the last change?\n\n$names")) throw Exception("Cancelled.")
        val sha = commit(cfg, snap, changes, "Prabhu: undo last self-improve")
        f.delete()
        ui.log("Undo saved (${sha.take(7)}). Building…")
        return finish(c, cfg, sha, null, ui)
    }

    /** Downloads the newest successful build from GitHub (use after a build you started elsewhere). */
    fun latest(c: Context, ui: UI): File {
        val cfg = cfg(c)
        ui.log("Looking for the newest successful build…")
        val r = api(cfg, "GET", "/actions/runs?branch=${cfg.branch}&status=success&per_page=1")
        val runs = r.optJSONArray("workflow_runs")
        if (runs == null || runs.length() == 0) throw Exception("No successful build found yet.")
        val f = apkFile(c)
        ui.status("Downloading…")
        downloadApk(cfg, runs.getJSONObject(0).getLong("id"), f)
        ui.log("Downloaded.")
        return f
    }

    // ---------------------------------------------------------------- update from zip / APK / link

    private fun gitSha(b: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${b.size}\u0000".toByteArray())
        md.update(b)
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun codeOf(g: String) = Regex("versionCode\\s*=\\s*(\\d+)").find(g)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    private fun nameOf(g: String) = Regex("versionName\\s*=\\s*\"([^\"]+)\"").find(g)?.groupValues?.get(1) ?: "?"

    private fun download(url0: String, cfg: Cfg?, ui: UI): ByteArray {
        var url = url0
        var auth = cfg != null && url.startsWith("https://api.github.com/")
        ui.status("Downloading…")
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.setRequestProperty("User-Agent", "Prabhu-App")
            if (auth && cfg != null) {
                c.setRequestProperty("Authorization", "Bearer ${cfg.token}")
                c.setRequestProperty("Accept", "application/vnd.github+json")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw Exception("Bad redirect from the server.")
                url = URL(URL(url), loc).toString()
                auth = false
                return@repeat
            }
            if (code !in 200..299) throw Exception("Download failed (HTTP $code). For a private repo use a token, or a public link.")
            c.inputStream.use { st ->
                val out = ByteArrayOutputStream()
                val buf = ByteArray(65536)
                while (true) {
                    val n = st.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > 80_000_000) throw Exception("That file is too big.")
                }
                return out.toByteArray()
            }
        }
        throw Exception("Too many redirects.")
    }

    /** The APK must be this app, newer than the installed one (Android refuses updates that are not newer). */
    private fun checkApk(c: Context, f: File) {
        val pm = c.packageManager
        val info = pm.getPackageArchiveInfo(f.absolutePath, 0) ?: throw Exception("That file is not a valid APK.")
        if (info.packageName != c.packageName) throw Exception("This APK is for another app (${info.packageName}).")
        val cur = pm.getPackageInfo(c.packageName, 0)
        @Suppress("DEPRECATION")
        val newV = if (android.os.Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        @Suppress("DEPRECATION")
        val curV = if (android.os.Build.VERSION.SDK_INT >= 28) cur.longVersionCode else cur.versionCode.toLong()
        if (newV <= curV) {
            throw Exception("This APK is version ${info.versionName}, you already have ${cur.versionName}. Android only installs a NEWER version.")
        }
    }

    /**
     * Update from a file: either a ready APK (installed as it is) or a zip of the project
     * (pushed to your GitHub repo, built there, then installed).
     */
    fun fromBytes(c: Context, bytes: ByteArray, ui: UI): File {
        if (bytes.size < 4 || bytes[0] != 'P'.code.toByte() || bytes[1] != 'K'.code.toByte()) {
            throw Exception("This is not a zip or APK file.")
        }
        val names = ArrayList<String>()
        ZipInputStream(bytes.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (!e.isDirectory) names.add(e.name)
            }
        }
        val apk = apkFile(c)
        // 1) the file itself is an APK
        if (names.contains("AndroidManifest.xml") && names.any { it.endsWith(".dex") }) {
            apk.parentFile?.mkdirs()
            apk.writeBytes(bytes)
            checkApk(c, apk)
            ui.log("APK looks good.")
            return apk
        }
        // 2) a zip that contains a ready APK
        if (names.none { it.endsWith("settings.gradle.kts") } && names.any { it.endsWith(".apk") }) {
            ZipInputStream(bytes.inputStream()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (!e.isDirectory && e.name.endsWith(".apk")) {
                        apk.parentFile?.mkdirs()
                        apk.writeBytes(z.readBytes())
                        break
                    }
                }
            }
            checkApk(c, apk)
            ui.log("APK found inside the zip and it looks good.")
            return apk
        }
        // 3) a zip of the project source
        val root = names.filter { it.endsWith("settings.gradle.kts") }.minByOrNull { it.length }
        val prefix = if (root != null) root.removeSuffix("settings.gradle.kts")
        else names.firstOrNull { it.contains("app/src/") }?.let { it.substring(0, it.indexOf("app/src/")) } ?: ""
        val fresh = LinkedHashMap<String, ByteArray>()
        ZipInputStream(bytes.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory || !e.name.startsWith(prefix) || e.name.startsWith("__MACOSX")) continue
                val rel = e.name.removePrefix(prefix)
                val low = rel.lowercase()
                if (!wanted(rel) || low.endsWith(".jks") || low.contains("gemini.key") || low.startsWith(".github/")) continue
                fresh[rel] = z.readBytes()
            }
        }
        if (fresh.isEmpty()) throw Exception("No Prabhu source files found in this zip.")
        val cfg = cfg(c)
        ui.log("Zip has ${fresh.size} source files. Comparing with your repo ${cfg.repo}…")
        val snap = snapshot(cfg)
        val changes = LinkedHashMap<String, String?>()
        val originals = LinkedHashMap<String, String?>()
        for ((rel, b) in fresh) {
            val old = snap.files.firstOrNull { it.path == rel }
            if (old != null && old.sha == gitSha(b)) continue
            changes[rel] = String(b, Charsets.UTF_8)
        }
        // never go backwards in version number
        val bg = "app/build.gradle.kts"
        val zipG = changes[bg]
        var zipName = ""
        if (zipG != null) {
            val repoG = snap.files.firstOrNull { it.path == bg }?.let { blob(cfg, it.sha) } ?: zipG
            zipName = nameOf(zipG)
            val rc = codeOf(repoG)
            val fixed = if (codeOf(zipG) <= rc)
                Regex("versionCode\\s*=\\s*\\d+").replace(zipG) { "versionCode = $rc" } else zipG
            if (fixed == repoG) changes.remove(bg) else changes[bg] = fixed
        }
        if (changes.isEmpty()) throw Exception("Nothing new in this zip: every file is already in your repo.")
        val list = changes.keys.toList()
        val shown = list.take(12).joinToString("\n") { "• $it" } + (if (list.size > 12) "\n… and ${list.size - 12} more" else "")
        if (!ui.confirm("Update from zip${if (zipName.isNotEmpty()) " (v$zipName)" else ""}: ${list.size} file(s) changed.\n\n$shown\n\nSave to GitHub and build the new app?")) {
            throw Exception("Cancelled. Nothing was changed.")
        }
        ui.status("Saving…")
        for (p in list) originals[p] = snap.files.firstOrNull { it.path == p }?.let { blob(cfg, it.sha) }
        val sha = commit(cfg, snap, changes, "Update from uploaded zip")
        saveUndo(c, originals)
        Store.setStr(c, "dev_pending", sha + "|Apply the uploaded update. Fix only build errors.")
        Store.setStr(c, "dev_notes", "Updated from a zip (${list.size} files).")
        ui.log("Saved to GitHub (${sha.take(7)}). Building the new app…")
        return finish(c, cfg, sha, "Apply the uploaded update. Fix only build errors and keep the update's intent.", ui)
    }

    /** A direct APK/zip link, or a github.com/owner/repo link (its code is downloaded and built through your repo). */
    fun fromLink(c: Context, link: String, ui: UI): File {
        val u = link.trim()
        if (!u.startsWith("https://")) throw Exception("Paste a full https:// link.")
        val cfg = try { cfg(c) } catch (e: Exception) { null }
        val m = Regex("^https://github\\.com/([^/]+)/([^/]+?)(?:\\.git)?/?(?:tree/([^/]+))?$").find(u)
        val target = if (m != null) {
            "https://api.github.com/repos/${m.groupValues[1]}/${m.groupValues[2]}/zipball" +
                (if (m.groupValues[3].isNotEmpty()) "/${m.groupValues[3]}" else "")
        } else u
        ui.log("Downloading from the link…")
        val bytes = download(target, cfg, ui)
        return fromBytes(c, bytes, ui)
    }

    // ---------------------------------------------------------------- install

    fun canInstall(c: Context) = c.packageManager.canRequestPackageInstalls()

    fun install(c: Context, apk: File) {
        val pi = c.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apk.inputStream().use { ins ->
                s.openWrite("prabhu.apk", 0, apk.length()).use { out ->
                    ins.copyTo(out)
                    s.fsync(out)
                }
            }
            val i = Intent(c, InstallReceiver::class.java).setAction("com.prabhu.assistant.INSTALL_RESULT")
            val pend = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            s.commit(pend.intentSender)
        }
    }
}

/** Receives the result of the install and opens the system's "Update?" screen. */
class InstallReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try { c.startActivity(confirm) } catch (e: Exception) { }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> { }
            else -> {
                val msg = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "Install failed"
                Toast.makeText(c, "Update not installed: $msg", Toast.LENGTH_LONG).show()
            }
        }
    }
}
