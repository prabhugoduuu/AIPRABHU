package com.prabhu.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.CountDownLatch

private const val DM = ViewGroup.LayoutParams.MATCH_PARENT
private const val DW = ViewGroup.LayoutParams.WRAP_CONTENT

/** Prabhu improves itself: you say what you want, it edits its own code on GitHub, builds and installs the new version. */
class DevActivity : Activity() {

    private lateinit var logTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var request: EditText
    private lateinit var go: TextView
    private lateinit var undoBtn: TextView
    private lateinit var latestBtn: TextView
    private lateinit var stopBtn: TextView
    private lateinit var resumeBtn: TextView

    @Volatile private var working = false
    @Volatile private var stop = false
    private var waitingApk: File? = null
    private val dlgTheme: Int
        get() = if (Theme.isLight()) android.R.style.Theme_Material_Light_Dialog_Alert else android.R.style.Theme_Material_Dialog_Alert

    private fun tv(s: CharSequence, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun btn(label: String, filled: Boolean, f: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setTextColor(if (filled) Color.WHITE else cText)
        background = if (filled) accentGrad(false, dp(12).toFloat()) else rounded(cSurface, cLine, 12)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnClickListener { f() }
    }

    private fun lpm(top: Int, bottom: Int = 0) =
        LinearLayout.LayoutParams(DM, DW).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun saved(hint: String, key: String, def: String, secret: Boolean): EditText = EditText(this).apply {
        this.hint = hint
        setText(Store.str(this@DevActivity, key, def))
        setHintTextColor(cMute)
        setTextColor(cText)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
        if (secret) transformationMethod = android.text.method.PasswordTransformationMethod.getInstance()
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = rounded(cSurface, cLine, 12)
        addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                Store.setStr(this@DevActivity, key, s?.toString()?.trim() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Theme.load(this)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Theme.isLight()) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cBg) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        bar.addView(tv("←", 22f, cText).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { finish() }
        })
        bar.addView(tv("🧬  Self-improve", 18f, cText, true))
        root.addView(bar, LinearLayout.LayoutParams(DM, DW))
        root.addView(View(this).apply { background = accentGrad() }, LinearLayout.LayoutParams(DM, dp(2)))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(32))
        }
        body.addView(tv(
            "Tell Prabhu what to improve in itself. It reads its own code from your GitHub repo, writes the change, " +
                "GitHub builds the new app, and Prabhu installs it over this one. If the build fails, it reads the errors and fixes them. " +
                "Every change can be undone.", 13f, cMute), lpm(0, 8))

        body.addView(tv("Update Prabhu", 13f, cAccent, true), lpm(8, 6))
        body.addView(tv(
            "Put the new Prabhu zip (or APK) here and it updates itself. A zip is built on GitHub (3-6 min), then you tap Install. " +
                "If the internet drops or you close the app, come back and tap Resume. Your chats and settings stay.", 12f, cMute), lpm(0, 8))
        body.addView(btn("📦  Put the new zip / APK here", true) { pickFile() }, lpm(0, 8))
        body.addView(btn("🔗  Update from a link (GitHub or direct)", false) { askLink() }, lpm(0, 12))

        body.addView(tv("GitHub (private repo that holds this project)", 13f, cAccent, true), lpm(8, 6))
        body.addView(saved("Repo, e.g. yourname/prabhu-assistant", "gh_repo", "", false), lpm(0, 8))
        body.addView(saved("Branch (main)", "gh_branch", "main", false), lpm(0, 8))
        body.addView(saved("GitHub token (classic token with 'repo' access)", "gh_token", "", true), lpm(0, 6))
        body.addView(tv(
            "Make a token: GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate → tick “repo”. " +
                "It stays only on this phone.", 12f, cMute), lpm(0, 8))
        body.addView(btn("🔌  Test connection", false) { runTask("Test") { _ -> Dev.check(this) } }, lpm(0, 12))

        body.addView(tv("Or let Prabhu improve itself", 13f, cAccent, true), lpm(8, 6))
        body.addView(tv("What should Prabhu improve?", 12f, cMute), lpm(0, 6))
        request = EditText(this).apply {
            hint = "e.g. Add a dark/light toggle in the chat bar. Or: make the bubble smaller."
            setHintTextColor(cMute)
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            minLines = 3
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(cSurface, cLine, 12)
        }
        body.addView(request, lpm(0, 8))

        body.addView(btn("📋  Paste a build error from the clipboard", false) { pasteError() }, lpm(0, 8))
        val auto = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(cSurface, cLine, 14)
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv("Apply without asking", 15f, cText))
        col.addView(tv("Skips the “Apply this change?” question. The Undo button always works.", 12f, cMute))
        auto.addView(col, LinearLayout.LayoutParams(0, DW, 1f))
        auto.addView(Switch(this).apply {
            isChecked = Store.bool(this@DevActivity, "dev_auto", false)
            setOnCheckedChangeListener { _, v -> Store.setBool(this@DevActivity, "dev_auto", v) }
        })
        body.addView(auto, lpm(0, 8))

        go = btn("🧬  Improve Prabhu", true) { startImprove() }
        body.addView(go, lpm(0, 8))
        undoBtn = btn("↩  Undo last change", false) { startUndo() }
        body.addView(undoBtn, lpm(0, 8))
        latestBtn = btn("⬇  Install newest build from GitHub", false) { startLatest() }
        body.addView(latestBtn, lpm(0, 8))
        resumeBtn = btn("▶  Resume the last build", true) { runTask("Resuming") { u -> Dev.resume(this, u) } }
        body.addView(resumeBtn, lpm(0, 8))
        stopBtn = btn("■  Stop", false) { stop = true; toast("Stopping…") }.apply { visibility = View.GONE }
        body.addView(stopBtn, lpm(0, 8))

        statusTv = tv("", 13f, cAccent, true)
        body.addView(statusTv, lpm(8, 4))
        logTv = tv("", 12f, cText).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(cSurface, cLine, 12)
        }
        body.addView(logTv, lpm(0, 0))

        logScroll = ScrollView(this).apply { addView(body) }
        root.addView(logScroll, LinearLayout.LayoutParams(DM, 0, 1f))
        setContentView(root)
        refreshButtons()
        // started from chat with "/improve ..."
        val pre = intent.getStringExtra("request").orEmpty()
        if (pre.isNotEmpty()) {
            request.setText(pre)
            if (intent.getBooleanExtra("go", false)) {
                intent.removeExtra("go")
                logScroll.post { startImprove() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshButtons()
        // came back from the "allow installs" settings page
        val apk = waitingApk
        if (apk != null && Dev.canInstall(this)) {
            waitingApk = null
            doInstall(apk)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshButtons() {
        if (!::undoBtn.isInitialized) return
        undoBtn.alpha = if (Dev.hasUndo(this)) 1f else 0.4f
        stopBtn.visibility = if (working) View.VISIBLE else View.GONE
        go.alpha = if (working) 0.4f else 1f
        resumeBtn.visibility = if (!working && Dev.pending(this).isNotBlank()) View.VISIBLE else View.GONE
    }

    // ---------------------------------------------------------------- log

    private fun log(s: String) {
        runOnUiThread {
            if (isFinishing) return@runOnUiThread
            logTv.append((if (logTv.text.isEmpty()) "" else "\n\n") + s)
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun status(s: String) {
        runOnUiThread { if (!isFinishing) statusTv.text = s }
    }

    private fun ui() = Dev.UI(
        { log(it) }, { status(it) }, { text -> confirm(text) }, { stop }
    )

    /** Blocks the worker thread until the person answers the dialog. */
    private fun confirm(text: String): Boolean {
        if (Store.bool(this, "dev_auto", false)) return true
        val latch = CountDownLatch(1)
        var ok = false
        runOnUiThread {
            AlertDialog.Builder(this, dlgTheme)
                .setTitle("Apply this change?")
                .setMessage(text)
                .setCancelable(false)
                .setPositiveButton("Yes, build it") { _, _ -> ok = true; latch.countDown() }
                .setNegativeButton("Cancel") { _, _ -> latch.countDown() }
                .show()
        }
        latch.await()
        return ok
    }

    // ---------------------------------------------------------------- tasks

    private fun runTask(name: String, job: (Dev.UI) -> Any?) {
        if (working) { toast("Already working…"); return }
        working = true
        stop = false
        refreshButtons()
        status("$name…")
        // keep the phone awake while the build runs, even if the screen turns off
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val wl = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "prabhu:dev")
        try { wl.acquire(30 * 60 * 1000L) } catch (e: Exception) { }
        Thread {
            try {
                val r = job(ui())
                if (r is File) {
                    status("New version ready")
                    runOnUiThread { offerInstall(r) }
                } else if (r is String) {
                    status("")
                    log("✓ $r")
                }
            } catch (e: Exception) {
                status("")
                log("✗ " + (e.message ?: "Something went wrong"))
            } finally {
                try { if (wl.isHeld) wl.release() } catch (e: Exception) { }
                working = false
                runOnUiThread { refreshButtons() }
            }
        }.start()
    }

    private fun pasteError() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty().trim()
        if (t.isEmpty()) { toast("Copy the error first"); return }
        request.setText("Fix this build error:\n" + t.take(3000))
    }

    private fun pickFile() {
        try {
            startActivityForResult(
                Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), 301
            )
        } catch (e: Exception) { toast("No file picker found") }
    }

    private fun askLink() {
        val f = EditText(this).apply {
            hint = "https://github.com/you/repo  or  https://…/Prabhu.apk"
            setHintTextColor(cMute)
            setTextColor(cText)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(cSurface, cLine, 12)
        }
        val wrap = android.widget.FrameLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(f) }
        AlertDialog.Builder(this, dlgTheme)
            .setTitle("Update from a link")
            .setView(wrap)
            .setPositiveButton("Update") { _, _ ->
                val l = f.text.toString().trim()
                if (l.isNotEmpty()) runTask("Updating") { u -> Dev.fromLink(this, l, u) }
            }
            .setNegativeButton("Cancel", null).show()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 301 && res == RESULT_OK) {
            val uri = data?.data ?: return
            runTask("Updating") { u ->
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("Couldn't read the file.")
                if (bytes.size > 80_000_000) throw Exception("That file is too big.")
                Dev.fromBytes(this, bytes, u)
            }
        }
    }

    private fun startImprove() {
        val r = request.text.toString().trim()
        if (r.isEmpty()) { toast("Write what Prabhu should improve"); return }
        if (Store.models(this).none { it.key.isNotBlank() }) { toast("Add an API key first (Settings)"); return }
        runTask("Working") { u -> Dev.improve(this, r, u) }
    }

    private fun startUndo() {
        if (!Dev.hasUndo(this)) { toast("Nothing to undo yet"); return }
        runTask("Undoing") { u -> Dev.undo(this, u) }
    }

    private fun startLatest() {
        runTask("Looking") { u -> Dev.latest(this, u) }
    }

    private fun offerInstall(apk: File) {
        if (isFinishing) { waitingApk = apk; return }
        AlertDialog.Builder(this, dlgTheme)
            .setTitle("New Prabhu is ready")
            .setMessage("Install it now? It replaces this app and keeps your chats and settings.")
            .setPositiveButton("Install") { _, _ -> doInstall(apk) }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun doInstall(apk: File) {
        if (!Dev.canInstall(this)) {
            waitingApk = apk
            toast("Allow “Install unknown apps” for Prabhu, then come back")
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            } catch (e: Exception) { }
            return
        }
        try {
            Dev.install(applicationContext, apk)
            log("Installing… confirm the update on the next screen.")
        } catch (e: Exception) {
            log("✗ Couldn't start the install: " + (e.message ?: ""))
        }
    }
}
