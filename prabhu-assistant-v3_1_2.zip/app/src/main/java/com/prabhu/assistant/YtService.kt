package com.prabhu.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Keeps uploads running with the screen off or Prabhu in the background. */
class YtService : Service() {
    companion object {
        @Volatile var running = false

        fun start(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, YtService::class.java)) } catch (e: Exception) { }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("prabhu_yt", "YouTube uploads", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "prabhu_yt")
            .setContentTitle("Prabhu · YouTube")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        running = true
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(3, notif("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else startForeground(3, notif("Starting…"))
        } catch (e: Exception) {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "prabhu:yt")
        try { wl.acquire(3 * 60 * 60 * 1000L) } catch (e: Exception) { }
        Thread {
            try {
                YouTube.processQueue(this) { msg ->
                    try { getSystemService(NotificationManager::class.java).notify(3, notif(msg)) } catch (e: Exception) { }
                }
            } catch (e: Exception) {
            } finally {
                try { if (wl.isHeld) wl.release() } catch (e: Exception) { }
                running = false
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }
}
