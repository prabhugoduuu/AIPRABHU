# Prabhu - AI assistant for Android

Chat app with side menu, chat history, photo/PDF/Word/text attach, voice input.
Add any number of AI APIs (Claude, Gemini, OpenAI, Groq, OpenRouter, custom).

v2.7
- Code files: every code block in an answer gets a Save button (Downloads/Prabhu), plus Save all as zip. Longer answers for Claude (16000 tokens).

v2.6
- Settings: record your voice (or upload a file) inside the app; Prabhu clones it via ElevenLabs and uses it automatically.

v2.5
- Attach ANY file: PDF, Word, Excel, PowerPoint, zip, text/code, audio/video, old .doc, rtf, OpenDocument. Pick several at once.
- Share to Prabhu from any app (WhatsApp, Files, Gmail...).

v2.4
- Voice commands: "WhatsApp open chey", "open YouTube", "search ...", "navigate to ...", "alarm 7 am", "timer 5 minutes" run instantly on the phone.
- AI voice: speak replies in your own cloned voice (ElevenLabs key + Voice ID in Settings).

v2.3
- Streaming: answers appear word by word, in chat and in the screen bubble.
- Faster: Gemini thinking minimal, smaller screenshots, shorter history.
- Fixed signing key (prabhu.jks): new APKs install OVER the old one, no uninstall needed.
- Gemini key is built in (app/gemini.key or GitHub secret GEMINI_API_KEY). Keep the repo PRIVATE.

v2.2
- Switch model inside the same chat when one API hits its limit (error card, last answer, model chip).
- Screen assist: floating P bubble, tap on any screen and Prabhu answers about it right there.
- Default digital assistant: power-button long-press opens Prabhu with a screenshot. No background listening.
- "Hey Prabhu" always-listening is now optional and off by default.


## Prabhu 2.8 upgrade notes
- Updated the app palette to a premium navy / violet visual theme.
- Added an in-app HTML preview action beside Save for generated `.html` / `.htm` files.
- API keys should be entered in app Settings or supplied through the `GEMINI_API_KEY` build environment variable. Do not commit `app/gemini.key`.
- The existing Screen Assistant already provides a movable overlay bubble and screen-aware panel; Android requires user-granted overlay and screen-capture permissions.
- Autonomous self-modification is not enabled. Safe upgrades should be generated as patches, previewed, tested, and explicitly approved before rebuilding/installing.
